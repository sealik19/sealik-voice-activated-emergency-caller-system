async function handler({ message, language = "english" }) {
  try {
    const systemPrompt = `You are Lifesaver, a helpful AI assistant for a safety app. You can communicate in English and Amharic only. Always respond in the same language as the user's message. Focus on safety-related topics and emergency assistance. If the message is not in English or Amharic, respond in English explaining you only speak English and Amharic.`;

    const response = await fetch("/integrations/google-gemini-1-5/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content: systemPrompt,
          },
          {
            role: "user",
            content: message,
          },
        ],
      }),
    });

    const data = await response.json();
    return {
      response: data.choices[0].message.content,
    };
  } catch (error) {
    return {
      error: "Failed to get response from Lifesaver",
    };
  }
}