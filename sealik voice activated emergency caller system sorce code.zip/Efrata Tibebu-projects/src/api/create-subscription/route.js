async function handler({
  user_id,
  plan_id,
  subscription_type,
  payment_status = "pending",
}) {
  if (!user_id) {
    return { error: "User ID is required" };
  }

  if (!plan_id) {
    return { error: "Plan ID is required" };
  }

  if (
    !subscription_type ||
    !["monthly", "yearly"].includes(subscription_type)
  ) {
    return { error: "Valid subscription type (monthly/yearly) is required" };
  }

  try {
    const plans = await sql`
      SELECT * FROM subscription_plans WHERE id = ${plan_id}
    `;

    if (!plans.length) {
      return { error: "Invalid plan selected" };
    }

    const amount =
      subscription_type === "monthly"
        ? plans[0].price_monthly
        : plans[0].price_yearly;
    const end_date = new Date();
    end_date.setMonth(
      end_date.getMonth() + (subscription_type === "monthly" ? 1 : 12)
    );

    const subscriptions = await sql`
      INSERT INTO user_subscriptions (
        user_id,
        plan_id,
        start_date,
        end_date,
        payment_status,
        subscription_type,
        amount_paid
      ) VALUES (
        ${user_id},
        ${plan_id},
        NOW(),
        ${end_date},
        ${payment_status},
        ${subscription_type},
        ${amount}
      )
      RETURNING *
    `;

    return { subscription: subscriptions[0] };
  } catch (error) {
    return { error: "Failed to create subscription" };
  }
}