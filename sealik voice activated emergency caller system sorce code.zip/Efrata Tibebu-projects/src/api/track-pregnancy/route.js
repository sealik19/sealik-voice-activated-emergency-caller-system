async function handler({
  user_id,
  last_period_date,
  symptoms = [],
  checkup_date,
  checkup_notes,
}) {
  if (!user_id || !last_period_date) {
    return { error: "Missing required fields" };
  }

  const dueDate = new Date(last_period_date);
  dueDate.setDate(dueDate.getDate() + 280);

  const today = new Date();
  const pregnancyStart = new Date(last_period_date);
  const weeksDiff = Math.floor(
    (today - pregnancyStart) / (1000 * 60 * 60 * 24 * 7)
  );

  try {
    const result = await sql(
      "INSERT INTO health_tracking (user_id, tracking_type, last_date, expected_due_date, pregnancy_week, pregnancy_symptoms, pregnancy_checkup_dates, last_checkup_notes) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *",
      [
        user_id,
        "pregnancy",
        last_period_date,
        dueDate.toISOString(),
        weeksDiff,
        symptoms,
        checkup_date ? [checkup_date] : [],
        checkup_notes,
      ]
    );

    return {
      success: true,
      tracking: result[0],
      due_date: dueDate,
      current_week: weeksDiff,
    };
  } catch (error) {
    return { error: "Failed to save pregnancy tracking data" };
  }
}