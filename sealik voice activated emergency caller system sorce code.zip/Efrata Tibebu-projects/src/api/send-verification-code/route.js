async function handler({ phone }) {
  if (!phone) {
    return { success: false, error: "Phone number is required" };
  }

  // Generate 6-digit code
  const code = Math.floor(100000 + Math.random() * 900000).toString();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes from now

  try {
    // Create table if not exists
    await sql`
      CREATE TABLE IF NOT EXISTS phone_verification (
        id SERIAL PRIMARY KEY,
        phone TEXT NOT NULL,
        code TEXT NOT NULL,
        expires_at TIMESTAMP NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        verified BOOLEAN DEFAULT FALSE
      )
    `;

    // Insert new verification code
    await sql`
      INSERT INTO phone_verification (phone, code, expires_at)
      VALUES (${phone}, ${code}, ${expiresAt})
    `;

    // TODO: Integrate with SMS service
    // For now, just log the code
    console.log(`Verification code for ${phone}: ${code}`);

    return {
      success: true,
      message: "Verification code sent",
    };
  } catch (error) {
    return {
      success: false,
      error: "Failed to send verification code",
    };
  }
}