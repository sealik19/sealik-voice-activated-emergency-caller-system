async function handler({ message, userId, language = "english" }) {
  try {
    const userRows = await sql(
      "SELECT u.*, json_build_object('high_contrast', uap.high_contrast, 'screen_reader', uap.screen_reader_enabled) as accessibility, json_build_object('safety_alerts', u.health_preferences->>'safety_alerts', 'pregnancy_tracking', u.health_preferences->>'pregnancy_tracking') as health_prefs FROM users u LEFT JOIN user_accessibility_preferences uap ON u.id = uap.user_id WHERE u.id = $1",
      [userId]
    );

    const alertHistory = await sql(
      "SELECT alert_type, status, created_at FROM safety_alerts WHERE user_id = $1 ORDER BY created_at DESC LIMIT 5",
      [userId]
    );

    const userContext = {
      user: userRows[0],
      recentAlerts: alertHistory,
    };

    const safetyTips = await sql(
      "SELECT title_en, content_en, title_am, content_am FROM safety_tips WHERE active = true ORDER BY priority DESC LIMIT 3"
    );

    const systemPrompt = `You are Sealik, a helpful AI assistant for a safety app. You can communicate in English and Amharic only. Always respond in the same language as the user's message. Focus on safety-related topics and emergency assistance. If the message is not in English or Amharic, respond in English explaining you only speak English and Amharic.

User Context: ${JSON.stringify(userContext)}
Available Safety Tips: ${JSON.stringify(safetyTips)}`;

    const response = await fetch("/integrations/google-gemini-1-5/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content: systemPrompt,
          },
          {
            role: "user",
            content: message,
          },
        ],
      }),
    });

    const data = await response.json();
    const aiResponse = data.choices[0].message.content;

    await sql(
      "INSERT INTO ai_chat_history (user_id, message, ai_response, emergency_level) VALUES ($1, $2, $3, 0)",
      [userId, message, aiResponse]
    );

    return {
      response: aiResponse,
      userContext,
    };
  } catch (error) {
    return {
      error: "Failed to get response from Sealik",
    };
  }
}