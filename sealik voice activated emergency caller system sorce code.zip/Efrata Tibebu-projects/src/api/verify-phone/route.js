async function handler({ phone, code }) {
  if (!phone || !code) {
    return {
      success: false,
      error: "Phone number and verification code are required",
    };
  }

  try {
    const now = new Date();

    const [verification] = await sql`
      SELECT * FROM phone_verification 
      WHERE phone = ${phone}
      AND code = ${code}
      AND verified = false
      AND expires_at > ${now}
      ORDER BY created_at DESC
      LIMIT 1
    `;

    if (!verification) {
      return {
        success: false,
        error: "Invalid or expired verification code",
      };
    }

    await sql`
      UPDATE phone_verification
      SET verified = true
      WHERE id = ${verification.id}
    `;

    return {
      success: true,
      message: "Phone number verified successfully",
    };
  } catch (error) {
    return {
      success: false,
      error: "Failed to verify phone number",
    };
  }
}