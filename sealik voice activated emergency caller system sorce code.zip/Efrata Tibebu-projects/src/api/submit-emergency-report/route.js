async function handler({
  user_id,
  report_type,
  description,
  latitude,
  longitude,
  media_urls,
}) {
  try {
    if (!user_id) {
      return { error: "User ID is required" };
    }

    if (!report_type) {
      return { error: "Report type is required" };
    }

    if (!description) {
      return { error: "Description is required" };
    }

    const report = await sql`
      INSERT INTO emergency_reports 
      (user_id, report_type, description, latitude, longitude, media_url, status)
      VALUES 
      (${user_id}, ${report_type}, ${description}, ${latitude}, ${longitude}, ${media_urls}, 'PENDING')
      RETURNING *
    `;

    return { report: report[0] };
  } catch (error) {
    return { error: "Failed to submit report" };
  }
}