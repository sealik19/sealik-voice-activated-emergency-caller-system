async function handler({
  user_id,
  tracking_type,
  date,
  notes,
  cycle_length = 28,
}) {
  if (!user_id || !tracking_type || !date) {
    return { error: "Missing required fields" };
  }

  if (!["pregnancy", "menstruation"].includes(tracking_type)) {
    return { error: "Invalid tracking type" };
  }

  const lastDate = new Date(date);
  let nextDate = new Date(lastDate);

  if (tracking_type === "pregnancy") {
    nextDate.setDate(lastDate.getDate() + 7); // Next weekly checkup
  } else {
    nextDate.setDate(lastDate.getDate() + cycle_length); // Next period
  }

  try {
    const result = await sql`
      INSERT INTO health_tracking 
        (user_id, tracking_type, last_date, next_date, notes, cycle_length)
      VALUES 
        (${user_id}, ${tracking_type}, ${lastDate.toISOString()}, ${nextDate.toISOString()}, ${notes}, ${cycle_length})
      RETURNING *
    `;

    if (result.length === 0) {
      return { error: "Failed to create tracking record" };
    }

    const upcoming = await sql`
      SELECT 
        tracking_type,
        next_date,
        notes
      FROM health_tracking
      WHERE 
        user_id = ${user_id}
        AND next_date > CURRENT_DATE
      ORDER BY next_date ASC
      LIMIT 5
    `;

    return {
      tracking: result[0],
      upcoming_dates: upcoming,
    };
  } catch (error) {
    return { error: "Failed to process health tracking" };
  }
}