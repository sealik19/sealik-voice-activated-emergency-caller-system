async function handler({
  user_id,
  latitude,
  longitude,
  trigger_type,
  emergency_type,
  accessibility_needs,
  offline_queued = false,
  details = null,
}) {
  if (!user_id || !trigger_type) {
    return {
      error: !user_id ? "User ID is required" : "Trigger type is required",
    };
  }

  try {
    const users = await sql("SELECT id FROM users WHERE id = $1 LIMIT 1", [
      user_id,
    ]);

    if (!users.length) {
      return { error: "Invalid user ID" };
    }

    if (offline_queued) {
      const queuedAlert = await sql(
        "INSERT INTO offline_emergency_queue (user_id, latitude, longitude, trigger_type, emergency_type, accessibility_needs) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *",
        [
          user_id,
          latitude,
          longitude,
          trigger_type,
          emergency_type,
          accessibility_needs,
        ]
      );
      return { queued: queuedAlert[0] };
    }

    const insertAlertQuery =
      "INSERT INTO emergency_alerts (user_id, latitude, longitude, trigger_type, status, emergency_type, accessibility_needs, offline_queued, proximity_alert_sent, details) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *";
    const insertResponseQuery =
      "INSERT INTO emergency_responses (alert_id, responder_type, response_status) VALUES (currval(pg_get_serial_sequence($1, $2)), $3, $4) RETURNING *";

    const [alert] = await sql.transaction([
      sql(insertAlertQuery, [
        user_id,
        latitude,
        longitude,
        trigger_type,
        "PENDING",
        emergency_type,
        accessibility_needs,
        offline_queued,
        false,
        details,
      ]),
      sql(insertResponseQuery, [
        "emergency_alerts",
        "id",
        "SYSTEM",
        "INITIATED",
      ]),
    ]);

    const contacts = await sql(
      "SELECT * FROM emergency_contacts WHERE user_id = $1 AND verified = true ORDER BY priority_level DESC, is_primary DESC",
      [user_id]
    );

    if (contacts.length) {
      const response = await fetch("/api/send-emergency-sms", {
        method: "POST",
        body: JSON.stringify({
          contacts,
          alert: alert[0],
          user_id,
        }),
      });

      if (!response.ok) {
        await sql("UPDATE emergency_alerts SET status = $1 WHERE id = $2", [
          "SMS_FAILED",
          alert[0].id,
        ]);
      }
    }

    return {
      alert: alert[0],
      contacts: contacts.length,
      status: "INITIATED",
    };
  } catch (error) {
    if (!offline_queued) {
      await sql(
        "INSERT INTO offline_emergency_queue (user_id, latitude, longitude, trigger_type, emergency_type, accessibility_needs) VALUES ($1, $2, $3, $4, $5, $6)",
        [
          user_id,
          latitude,
          longitude,
          trigger_type,
          emergency_type,
          accessibility_needs,
        ]
      );
    }
    return {
      error: "Emergency alert processing failed",
      queued: true,
    };
  }
}