async function handler({ error, context }) {
  if (!error || !context) {
    return {
      message: "Error and context are required",
      success: false,
    };
  }

  try {
    const errorMessage = error instanceof Error ? error.message : String(error);
    const errorStack = error instanceof Error ? error.stack : null;

    await sql`
      INSERT INTO error_logs 
      (error_message, error_context, error_stack, created_at)
      VALUES 
      (${errorMessage}, ${context}, ${errorStack}, NOW())
    `;

    return {
      message: "An error occurred. Please try again.",
      success: false,
      error: errorMessage,
    };
  } catch (e) {
    return {
      message: "System error",
      success: false,
    };
  }
}