async function handler({ name, home_address, work_address }) {
  if (!name) {
    return { error: "Name is required" };
  }

  const user = await sql`
    INSERT INTO users (name, home_address, work_address)
    VALUES (${name}, ${home_address}, ${work_address})
    RETURNING *
  `;

  return { user: user[0] };
}