async function handler({ category, language = "en" }) {
  try {
    let queryText = `
      SELECT 
        id,
        name_${language} as name,
        category,
        description_${language} as description,
        contact_info,
        website,
        location,
        operating_hours
      FROM government_services
    `;

    const values = [];
    if (category) {
      queryText += ` WHERE category = $1`;
      values.push(category);
    }

    queryText += ` ORDER BY name_${language}`;

    const services = await sql(queryText, values);
    return { services };
  } catch (error) {
    return { error: "Failed to fetch government services" };
  }
}