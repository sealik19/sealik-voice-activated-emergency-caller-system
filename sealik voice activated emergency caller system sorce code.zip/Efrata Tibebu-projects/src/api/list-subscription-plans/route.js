async function handler() {
  try {
    const plans = await sql`
      SELECT * FROM subscription_plans
      ORDER BY price_monthly ASC
    `;
    return { plans };
  } catch (error) {
    return { error: "Failed to fetch subscription plans" };
  }
}