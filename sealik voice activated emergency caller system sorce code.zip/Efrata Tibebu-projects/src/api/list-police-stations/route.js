async function handler({ latitude, longitude, searchQuery }) {
  try {
    const queryLat = latitude || 9.032;
    const queryLong = longitude || 38.752;

    let baseQuery =
      "SELECT *, earth_distance(ll_to_earth($1, $2), ll_to_earth(latitude, longitude)) as distance FROM police_stations";
    let params = [queryLat, queryLong];

    if (searchQuery) {
      baseQuery += " WHERE name_en ILIKE $3 OR name_am ILIKE $3";
      params.push(`%${searchQuery}%`);
    }

    baseQuery += " ORDER BY distance LIMIT 10";

    const stations = await sql(baseQuery, params);
    return { stations };
  } catch (error) {
    return { error: "Failed to fetch police stations" };
  }
}