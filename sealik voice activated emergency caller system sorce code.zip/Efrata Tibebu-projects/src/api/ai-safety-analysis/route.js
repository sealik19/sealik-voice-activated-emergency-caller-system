async function handler({ userId, location, timeOfDay }) {
  try {
    const userRows = await sql(
      "SELECT u.*, json_build_object('high_contrast', uap.high_contrast, 'screen_reader', uap.screen_reader_enabled) as accessibility FROM users u LEFT JOIN user_accessibility_preferences uap ON u.id = uap.user_id WHERE u.id = $1",
      [userId]
    );

    const recentAlerts = await sql(
      "SELECT alert_type, location, created_at FROM safety_alerts WHERE user_id = $1 ORDER BY created_at DESC LIMIT 5",
      [userId]
    );

    const nearbyPoliceStations = await sql(
      "SELECT name_en, address, latitude, longitude, phone FROM police_stations WHERE (latitude BETWEEN $1 AND $2) AND (longitude BETWEEN $3 AND $4) LIMIT 3",
      [
        location.latitude - 0.1,
        location.latitude + 0.1,
        location.longitude - 0.1,
        location.longitude + 0.1,
      ]
    );

    const safetyScores = await sql(
      "SELECT score, factors FROM safety_scores WHERE location_id IN (SELECT id FROM saved_locations WHERE latitude BETWEEN $1 AND $2 AND longitude BETWEEN $3 AND $4)",
      [
        location.latitude - 0.1,
        location.latitude + 0.1,
        location.longitude - 0.1,
        location.longitude + 0.1,
      ]
    );

    const analysisPrompt = `Analyze the safety of a location with the following context:
Location: ${JSON.stringify(location)}
Time of Day: ${timeOfDay}
Recent User Alerts: ${JSON.stringify(recentAlerts)}
Nearby Police Stations: ${JSON.stringify(nearbyPoliceStations)}
Historical Safety Scores: ${JSON.stringify(safetyScores)}`;

    const response = await fetch("/integrations/google-gemini-1-5/", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content:
              "You are a safety analysis AI. Analyze location safety and provide actionable recommendations.",
          },
          {
            role: "user",
            content: analysisPrompt,
          },
        ],
        json_schema: {
          name: "safety_analysis",
          schema: {
            type: "object",
            properties: {
              risk_level: {
                type: "integer",
                minimum: 1,
                maximum: 5,
              },
              risk_factors: {
                type: "array",
                items: {
                  type: "string",
                },
              },
              recommendations: {
                type: "array",
                items: {
                  type: "string",
                },
              },
              safe_routes: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    description: { type: "string" },
                    safety_score: { type: "integer" },
                  },
                  required: ["description", "safety_score"],
                  additionalProperties: false,
                },
              },
            },
            required: [
              "risk_level",
              "risk_factors",
              "recommendations",
              "safe_routes",
            ],
            additionalProperties: false,
          },
        },
      }),
    });

    const aiResponse = await response.json();
    const analysis = JSON.parse(aiResponse.choices[0].message.content);

    await sql(
      "INSERT INTO ai_safety_analysis (user_id, location_data, risk_level, analysis_result) VALUES ($1, $2, $3, $4)",
      [
        userId,
        JSON.stringify(location),
        analysis.risk_level,
        JSON.stringify(analysis),
      ]
    );

    return {
      riskLevel: analysis.risk_level,
      riskFactors: analysis.risk_factors,
      recommendations: analysis.recommendations,
      safeRoutes: analysis.safe_routes,
      nearbyHelp: nearbyPoliceStations,
    };
  } catch (error) {
    return {
      error: "Failed to analyze safety",
    };
  }
}