async function handler({
  userId,
  alertType,
  location,
  emergencyDetails,
  accessibilityNeeds,
}) {
  if (!userId || !alertType || !location) {
    return { error: "Missing required fields" };
  }

  try {
    const [alert] = await sql`
      INSERT INTO safety_alerts 
      (user_id, alert_type, location, priority_level, status, response_time)
      VALUES 
      (${userId}, ${alertType}, ${JSON.stringify(location)}, 1, 'pending', 0)
      RETURNING *
    `;

    const contacts = await sql`
      SELECT * FROM emergency_contacts 
      WHERE user_id = ${userId} 
      ORDER BY is_primary DESC
    `;

    const [emergencyAlert] = await sql`
      INSERT INTO emergency_alerts 
      (user_id, emergency_type, latitude, longitude, trigger_type, status, accessibility_needs)
      VALUES 
      (${userId}, ${alertType}, ${location.latitude}, ${location.longitude}, 
       'automatic', 'active', ${JSON.stringify(accessibilityNeeds || {})})
      RETURNING *
    `;

    const [nearestStation] = await sql`
      SELECT *, 
      (
        6371 * acos(
          cos(radians(${location.latitude})) * cos(radians(latitude)) *
          cos(radians(longitude) - radians(${location.longitude})) +
          sin(radians(${location.latitude})) * sin(radians(latitude))
        )
      ) AS distance
      FROM police_stations
      ORDER BY distance
      LIMIT 1
    `;

    const [response] = await sql`
      INSERT INTO emergency_responses 
      (alert_id, responder_type, response_status, notes)
      VALUES 
      (${alert.id}, 'police', 'dispatched', ${JSON.stringify({
      station: nearestStation.name_en,
      distance: nearestStation.distance,
    })})
      RETURNING *
    `;

    await sql`
      UPDATE safety_alerts
      SET status = 'active',
          response_time = EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - created_at))::integer
      WHERE id = ${alert.id}
    `;

    return {
      alertId: alert.id,
      emergencyId: emergencyAlert.id,
      responseId: response.id,
      status: "active",
      nearestStation: {
        name: nearestStation.name_en,
        distance: nearestStation.distance,
        phone: nearestStation.phone,
      },
      contacts: contacts.map((c) => ({
        name: c.name,
        phone: c.phone,
        isPrimary: c.is_primary,
      })),
    };
  } catch (error) {
    return { error: "Failed to process alert" };
  }
}