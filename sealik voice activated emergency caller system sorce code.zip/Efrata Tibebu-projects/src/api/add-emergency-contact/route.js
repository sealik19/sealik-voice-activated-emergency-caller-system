async function handler({ user_id, name, phone, relationship }) {
  if (!user_id) {
    return { error: "User ID is required" };
  }
  if (!name) {
    return { error: "Name is required" };
  }
  if (!phone) {
    return { error: "Phone number is required" };
  }

  const contact = await sql`
    INSERT INTO emergency_contacts 
    (user_id, name, phone, relationship)
    VALUES 
    (${user_id}, ${name}, ${phone}, ${relationship})
    RETURNING *
  `;

  return { contact: contact[0] };
}