async function handler({ subscriptionType }) {
  if (!subscriptionType || !["monthly", "yearly"].includes(subscriptionType)) {
    return {
      error: 'Invalid subscription type. Must be "monthly" or "yearly"',
    };
  }

  const plan = await sql`
    SELECT 
      price_monthly,
      price_yearly,
      currency
    FROM subscription_plans 
    LIMIT 1
  `;

  if (!plan || !plan[0]) {
    return {
      error: "No subscription plan found",
    };
  }

  const { price_monthly, price_yearly, currency } = plan[0];
  const basePrice =
    subscriptionType === "monthly" ? price_monthly : price_monthly * 12;
  const discountedPrice =
    subscriptionType === "monthly" ? price_monthly : price_yearly;
  const savingsAmount = basePrice - discountedPrice;
  const savingsPercentage = (savingsAmount / basePrice) * 100;

  const formatter = new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: currency || "ETB",
  });

  return {
    basePrice,
    discountedPrice,
    savings: {
      amount: savingsAmount,
      percentage: savingsPercentage,
    },
    display: {
      original: formatter.format(basePrice),
      final: formatter.format(discountedPrice),
      savings: formatter.format(savingsAmount),
    },
  };
}