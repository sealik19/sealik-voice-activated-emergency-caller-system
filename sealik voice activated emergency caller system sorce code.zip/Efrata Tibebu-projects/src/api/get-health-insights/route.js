async function handler({ user_id, tracking_type }) {
  if (!user_id || !tracking_type) {
    return { error: "Missing required fields" };
  }

  try {
    const tracking = await sql(
      "SELECT * FROM health_tracking WHERE user_id = $1 AND tracking_type = $2 ORDER BY created_at DESC LIMIT 6",
      [user_id, tracking_type]
    );

    let insights = {};

    if (tracking_type === "menstruation" && tracking.length > 0) {
      const cycleLengths = [];
      for (let i = 0; i < tracking.length - 1; i++) {
        const diff =
          new Date(tracking[i].last_date) - new Date(tracking[i + 1].last_date);
        cycleLengths.push(diff);
      }

      const avgCycle =
        cycleLengths.length > 0
          ? Math.round(
              cycleLengths.reduce((a, b) => a + b, 0) /
                cycleLengths.length /
                (1000 * 60 * 60 * 24)
            )
          : 0;

      const symptomCount = {};
      tracking.forEach((record) => {
        if (record.symptoms) {
          record.symptoms.forEach((symptom) => {
            symptomCount[symptom] = (symptomCount[symptom] || 0) + 1;
          });
        }
      });

      insights = {
        average_cycle: avgCycle,
        common_symptoms: symptomCount,
      };
    }

    if (tracking_type === "pregnancy" && tracking.length > 0) {
      const latest = tracking[0];
      insights = {
        due_date: latest.expected_due_date,
        current_week: latest.pregnancy_week,
        next_checkup: latest.pregnancy_checkup_dates?.at(-1),
        recent_symptoms: latest.pregnancy_symptoms,
      };
    }

    return {
      success: true,
      tracking,
      insights,
    };
  } catch (error) {
    return { error: "Failed to get health insights" };
  }
}