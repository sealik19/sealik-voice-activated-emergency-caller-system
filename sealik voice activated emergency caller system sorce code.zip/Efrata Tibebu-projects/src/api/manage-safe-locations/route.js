async function handler({
  user_id,
  action,
  location_id,
  name,
  address,
  latitude,
  longitude,
  place_id,
  category,
  is_medical,
  operating_hours,
  contact_info,
}) {
  if (!user_id) {
    return { error: "Missing user ID" };
  }

  try {
    switch (action) {
      case "create": {
        const newLocation = await sql(
          "INSERT INTO saved_locations (user_id, name, address, latitude, longitude, place_id, category, is_medical, operating_hours, contact_info) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *",
          [
            user_id,
            name,
            address,
            latitude,
            longitude,
            place_id,
            category,
            is_medical,
            operating_hours,
            contact_info,
          ]
        );
        return { success: true, location: newLocation[0] };
      }

      case "update": {
        const updatedLocation = await sql(
          "UPDATE saved_locations SET name = $1, address = $2, latitude = $3, longitude = $4, place_id = $5, category = $6, is_medical = $7, operating_hours = $8, contact_info = $9 WHERE id = $10 AND user_id = $11 RETURNING *",
          [
            name,
            address,
            latitude,
            longitude,
            place_id,
            category,
            is_medical,
            operating_hours,
            contact_info,
            location_id,
            user_id,
          ]
        );
        return { success: true, location: updatedLocation[0] };
      }

      case "delete": {
        await sql(
          "DELETE FROM saved_locations WHERE id = $1 AND user_id = $2",
          [location_id, user_id]
        );
        return { success: true };
      }

      case "list": {
        const locations = await sql(
          "SELECT * FROM saved_locations WHERE user_id = $1 ORDER BY created_at DESC",
          [user_id]
        );
        return { success: true, locations };
      }

      default:
        return { error: "Invalid action" };
    }
  } catch (error) {
    return { error: "Failed to manage locations" };
  }
}