async function handler({ latitude, longitude, language = "en" }) {
  try {
    // Get nearby support centers and healthcare facilities within 50km radius
    const facilities = await sql`
      WITH locations AS (
        SELECT 
          id,
          name_${language} as name,
          address,
          category,
          contact_info,
          operating_hours,
          latitude,
          longitude,
          (
            6371 * acos(
              cos(radians(${latitude})) * cos(radians(latitude)) *
              cos(radians(longitude) - radians(${longitude})) +
              sin(radians(${latitude})) * sin(radians(latitude))
            )
          ) AS distance
        FROM government_services
        WHERE category IN ('women_support', 'healthcare')
      )
      SELECT *
      FROM locations
      WHERE distance <= 50
      ORDER BY distance
      LIMIT 20
    `;

    // Get emergency hotlines
    const hotlines = await sql`
      SELECT 
        name_${language} as name,
        contact_info,
        description_${language} as description
      FROM government_services
      WHERE category = 'hotline'
      AND name_${language} ILIKE '%women%'
      OR name_${language} ILIKE '%emergency%'
    `;

    // Get safety guidelines
    const guidelines = await sql`
      SELECT 
        name_${language} as title,
        description_${language} as content
      FROM government_services
      WHERE category = 'safety_guideline'
      AND (
        name_${language} ILIKE '%women%'
        OR description_${language} ILIKE '%women%'
      )
    `;

    return {
      support_centers: facilities.filter((f) => f.category === "women_support"),
      healthcare_facilities: facilities.filter(
        (f) => f.category === "healthcare"
      ),
      hotlines,
      safety_guidelines: guidelines,
      timestamp: new Date().toISOString(),
    };
  } catch (error) {
    return {
      error: "Failed to fetch safety resources",
      details: error.message,
    };
  }
}