async function handler({ phone_number }) {
  if (!phone_number) {
    return {
      success: false,
      error: "Phone number is required",
    };
  }

  try {
    const [contact] = await sql`
      SELECT ec.*, u.* 
      FROM emergency_contacts ec
      JOIN users u ON u.id = ec.user_id
      WHERE ec.phone = ${phone_number}
      LIMIT 1
    `;

    if (!contact) {
      return {
        success: false,
        error: "User not found",
      };
    }

    const verificationResponse = await fetch("/api/send-verification-code", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ phone: phone_number }),
    });

    const verificationResult = await verificationResponse.json();

    if (!verificationResult.success) {
      return {
        success: false,
        error: "Failed to send verification code",
      };
    }

    return {
      success: true,
      data: {
        user_id: contact.user_id,
        name: contact.name,
        phone: contact.phone,
        requires_verification: true,
      },
    };
  } catch (error) {
    return {
      success: false,
      error: "Login failed",
    };
  }
}