async function handler({
  userId,
  trackingType,
  lastPeriodDate,
  cycleLength,
  pregnancyStartDate,
  language = "en",
}) {
  if (!userId || !trackingType || !(lastPeriodDate || pregnancyStartDate)) {
    return {
      error:
        language === "am" ? "የተሟላ መረጃ አላቀረቡም" : "Missing required information",
    };
  }

  if (trackingType === "menstrual") {
    if (!lastPeriodDate || !cycleLength) {
      return {
        error:
          language === "am"
            ? "የወር አበባ ቀን እና የዑደት ርዝመት ያስፈልጋል"
            : "Last period date and cycle length required",
      };
    }

    const lastDate = new Date(lastPeriodDate);
    const nextPeriodDate = new Date(lastDate);
    nextPeriodDate.setDate(lastDate.getDate() + cycleLength);

    const ovulationDate = new Date(lastDate);
    ovulationDate.setDate(lastDate.getDate() + Math.floor(cycleLength / 2));

    const fertilityStart = new Date(ovulationDate);
    fertilityStart.setDate(ovulationDate.getDate() - 5);

    const fertilityEnd = new Date(ovulationDate);
    fertilityEnd.setDate(ovulationDate.getDate() + 2);

    await sql`
      INSERT INTO health_tracking 
      (user_id, tracking_type, last_date, next_date, cycle_length, fertility_window)
      VALUES 
      (${userId}, 'menstrual', ${lastPeriodDate}, ${
      nextPeriodDate.toISOString().split("T")[0]
    }, 
       ${cycleLength}, ${`[${fertilityStart.toISOString().split("T")[0]},${
      fertilityEnd.toISOString().split("T")[0]
    }]`})
    `;

    return {
      nextPeriod: nextPeriodDate.toISOString().split("T")[0],
      ovulation: ovulationDate.toISOString().split("T")[0],
      fertilityWindow: {
        start: fertilityStart.toISOString().split("T")[0],
        end: fertilityEnd.toISOString().split("T")[0],
      },
      message:
        language === "am"
          ? "የወር አበባ መረጃ በተሳካ ሁኔታ ተሰልቷል"
          : "Menstrual cycle data calculated successfully",
    };
  } else if (trackingType === "pregnancy") {
    if (!pregnancyStartDate) {
      return {
        error:
          language === "am"
            ? "የእርግዝና መጀመሪያ ቀን ያስፈልጋል"
            : "Pregnancy start date required",
      };
    }

    const startDate = new Date(pregnancyStartDate);
    const currentDate = new Date();
    const dueDate = new Date(startDate);
    dueDate.setDate(startDate.getDate() + 280); // 40 weeks

    const weeksDiff = Math.floor(
      (currentDate - startDate) / (1000 * 60 * 60 * 24 * 7)
    );
    const currentWeek = Math.min(Math.max(weeksDiff, 1), 40);

    const checkups = [
      {
        week: 8,
        description: language === "am" ? "የመጀመሪያ ምርመራ" : "First prenatal visit",
      },
      {
        week: 12,
        description: language === "am" ? "የመጀመሪያ ስካን" : "First ultrasound",
      },
      {
        week: 20,
        description: language === "am" ? "ሁለተኛ ስካን" : "Anatomy scan",
      },
      {
        week: 28,
        description: language === "am" ? "የስኳር ምርመራ" : "Glucose test",
      },
      {
        week: 36,
        description:
          language === "am" ? "የወሊድ ዝግጅት ምርመራ" : "Birth prep checkup",
      },
    ];

    await sql`
      INSERT INTO health_tracking 
      (user_id, tracking_type, pregnancy_week, expected_due_date)
      VALUES 
      (${userId}, 'pregnancy', ${currentWeek}, ${
      dueDate.toISOString().split("T")[0]
    })
    `;

    return {
      dueDate: dueDate.toISOString().split("T")[0],
      currentWeek,
      trimester: currentWeek <= 13 ? 1 : currentWeek <= 26 ? 2 : 3,
      upcomingCheckups: checkups.filter((c) => c.week >= currentWeek),
      message:
        language === "am"
          ? "የእርግዝና መረጃ በተሳካ ሁኔታ ተሰልቷል"
          : "Pregnancy tracking data calculated successfully",
    };
  }

  return {
    error:
      language === "am" ? "የማይደገፍ የክትትል አይነት" : "Unsupported tracking type",
  };
}