async function handler({
  user_id,
  date,
  flow_intensity,
  symptoms = [],
  mood,
  physical_symptoms = [],
  medication_notes,
}) {
  if (!user_id || !date) {
    return { error: "Missing required fields" };
  }

  try {
    const result = await sql(
      "INSERT INTO health_tracking (user_id, tracking_type, last_date, flow_intensity, symptoms, mood, physical_symptoms, medication_notes) VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *",
      [
        user_id,
        "menstruation",
        date,
        flow_intensity,
        symptoms,
        mood,
        physical_symptoms,
        medication_notes,
      ]
    );

    return { success: true, tracking: result[0] };
  } catch (error) {
    return { error: "Failed to save tracking data" };
  }
}