async function handler({
  user_id,
  alert_type,
  latitude,
  longitude,
  voice_call = false,
}) {
  if (!user_id || !alert_type) {
    return { error: "Missing required fields" };
  }

  try {
    // Get emergency contacts for user
    const contacts = await sql`
      SELECT id, name, phone 
      FROM emergency_contacts 
      WHERE user_id = ${user_id} 
      ORDER BY is_primary DESC`;

    if (contacts.length === 0) {
      return { error: "No emergency contacts found" };
    }

    // Create emergency alert record
    const [alert] = await sql`
      INSERT INTO emergency_alerts 
        (user_id, latitude, longitude, trigger_type, status, emergency_type)
      VALUES 
        (${user_id}, ${latitude}, ${longitude}, ${
      voice_call ? "voice" : "sms"
    }, 'pending', ${alert_type})
      RETURNING id`;

    // Send messages to all contacts
    const results = [];
    for (const contact of contacts) {
      try {
        const message = `Emergency Alert: ${alert_type}. Location: ${latitude},${longitude}`;

        // Make external SMS API call
        const response = await fetch(
          "https://api.twilio.com/2010-04-01/Accounts/ACCOUNT_SID/Messages.json",
          {
            method: "POST",
            headers: {
              Authorization: `Basic ${Buffer.from(
                `${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`
              ).toString("base64")}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: new URLSearchParams({
              To: contact.phone,
              From: process.env.TWILIO_PHONE_NUMBER,
              Body: message,
            }),
          }
        );

        if (voice_call) {
          // Make voice call API request
          await fetch(
            "https://api.twilio.com/2010-04-01/Accounts/ACCOUNT_SID/Calls.json",
            {
              method: "POST",
              headers: {
                Authorization: `Basic ${Buffer.from(
                  `${process.env.TWILIO_ACCOUNT_SID}:${process.env.TWILIO_AUTH_TOKEN}`
                ).toString("base64")}`,
                "Content-Type": "application/x-www-form-urlencoded",
              },
              body: new URLSearchParams({
                To: contact.phone,
                From: process.env.TWILIO_PHONE_NUMBER,
                Url: `${
                  process.env.BASE_URL
                }/emergency-voice?message=${encodeURIComponent(message)}`,
              }),
            }
          );
        }

        results.push({
          contact_id: contact.id,
          status: "sent",
        });
      } catch (error) {
        results.push({
          contact_id: contact.id,
          status: "failed",
          error: error.message,
        });
      }
    }

    // Update alert status
    await sql`
      UPDATE emergency_alerts 
      SET status = ${
        results.every((r) => r.status === "sent") ? "sent" : "partial"
      }
      WHERE id = ${alert.id}`;

    return {
      alert_id: alert.id,
      notifications: results,
    };
  } catch (error) {
    return { error: "Failed to send emergency notifications" };
  }
}