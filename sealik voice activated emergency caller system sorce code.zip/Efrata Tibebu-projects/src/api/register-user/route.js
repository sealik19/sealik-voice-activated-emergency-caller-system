async function handler({ name, phone_number, emergency_contact_phone }) {
  if (!name || !phone_number || !emergency_contact_phone) {
    return {
      success: false,
      error: "Name, phone number, and emergency contact phone are required",
    };
  }

  try {
    // Check phone verification
    const [verification] = await sql`
      SELECT * FROM phone_verification 
      WHERE phone = ${phone_number}
      AND verified = true
      ORDER BY created_at DESC
      LIMIT 1
    `;

    if (!verification) {
      return {
        success: false,
        error: "Phone number not verified",
      };
    }

    // Create user and emergency contact in a transaction
    const [user, emergencyContact] = await sql.transaction([
      sql`
        INSERT INTO users (name)
        VALUES (${name})
        RETURNING *
      `,
      sql`
        INSERT INTO emergency_contacts (user_id, name, phone, is_primary)
        VALUES ((SELECT currval(pg_get_serial_sequence('users', 'id'))), 'Primary Contact', ${emergency_contact_phone}, true)
        RETURNING *
      `,
    ]);

    return {
      success: true,
      data: {
        user,
        emergency_contact: emergencyContact,
      },
    };
  } catch (error) {
    return {
      success: false,
      error: "Failed to create user",
    };
  }
}