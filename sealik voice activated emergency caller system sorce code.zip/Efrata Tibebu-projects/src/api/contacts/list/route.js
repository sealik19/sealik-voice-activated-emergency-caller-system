async function handler({
  user_id,
  search = "",
  page = 1,
  limit = 10,
  sort_by = "created_at",
  sort_order = "DESC",
  category = null,
  status = null,
  export_format = null,
}) {
  if (!user_id) {
    return { error: "User ID is required" };
  }

  try {
    const offset = (page - 1) * limit;
    let queryValues = [user_id];
    let paramCount = 1;

    // Build base query
    let queryString = `
      SELECT 
        ec.*,
        COUNT(*) OVER() as total_count
      FROM emergency_contacts ec
      WHERE ec.user_id = $${paramCount}
    `;

    // Add search filter
    if (search) {
      paramCount++;
      queryValues.push(`%${search}%`);
      queryString += ` AND (
        LOWER(name) LIKE LOWER($${paramCount}) OR 
        LOWER(phone) LIKE LOWER($${paramCount}) OR 
        LOWER(relationship) LIKE LOWER($${paramCount})
      )`;
    }

    // Add category filter
    if (category) {
      paramCount++;
      queryValues.push(category);
      queryString += ` AND category = $${paramCount}`;
    }

    // Add status filter
    if (status) {
      paramCount++;
      queryValues.push(status);
      queryString += ` AND verified = $${paramCount}`;
    }

    // Add sorting
    const validColumns = [
      "name",
      "created_at",
      "priority_level",
      "relationship",
    ];
    const validOrders = ["ASC", "DESC"];

    const sanitizedColumn = validColumns.includes(sort_by)
      ? sort_by
      : "created_at";
    const sanitizedOrder = validOrders.includes(sort_order.toUpperCase())
      ? sort_order.toUpperCase()
      : "DESC";

    queryString += ` ORDER BY ${sanitizedColumn} ${sanitizedOrder}`;

    // Add pagination
    queryString += ` LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    queryValues.push(limit, offset);

    // Execute query
    const result = await sql(queryString, queryValues);

    const totalCount = result[0]?.total_count || 0;
    const totalPages = Math.ceil(totalCount / limit);

    // Handle export request
    if (export_format === "csv") {
      const exportData = result.map((contact) => ({
        name: contact.name,
        phone: contact.phone,
        relationship: contact.relationship,
        category: contact.category,
        priority_level: contact.priority_level,
        created_at: contact.created_at,
      }));

      return {
        export: true,
        format: "csv",
        data: exportData,
        filename: `emergency-contacts-${
          new Date().toISOString().split("T")[0]
        }.csv`,
      };
    }

    return {
      contacts: result.map((r) => {
        const { total_count, ...contact } = r;
        return contact;
      }),
      pagination: {
        current_page: page,
        total_pages: totalPages,
        total_items: totalCount,
        items_per_page: limit,
      },
    };
  } catch (error) {
    console.error("Error fetching contacts:", error);
    return {
      error: "Failed to fetch contacts",
      details: error.message,
    };
  }
}