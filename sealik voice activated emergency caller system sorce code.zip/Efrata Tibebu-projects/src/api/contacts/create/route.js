async function handler({
  user_id,
  name,
  phone,
  relationship,
  is_primary = false,
  category = "personal",
  priority_level = 0,
  notes,
  address,
}) {
  if (!user_id) {
    return { error: "User ID is required" };
  }

  if (!name || name.trim().length < 2) {
    return { error: "Name must be at least 2 characters" };
  }

  const cleanPhone = phone.replace(/\D/g, "");
  if (cleanPhone.length < 10) {
    return { error: "Phone number must be at least 10 digits" };
  }
  const formattedPhone = cleanPhone.startsWith("+")
    ? cleanPhone
    : `+${cleanPhone}`;

  const validRelationships = [
    "family",
    "friend",
    "neighbor",
    "coworker",
    "medical",
    "other",
  ];
  if (relationship && !validRelationships.includes(relationship)) {
    return { error: "Invalid relationship type" };
  }

  const validCategories = ["personal", "medical", "emergency", "work", "other"];
  if (!validCategories.includes(category)) {
    return { error: "Invalid contact category" };
  }

  const existingContact = await sql`
    SELECT id FROM emergency_contacts 
    WHERE user_id = ${user_id} 
    AND phone = ${formattedPhone}
  `;

  if (existingContact.length > 0) {
    return { error: "Contact with this phone number already exists" };
  }

  if (priority_level < 0 || priority_level > 3) {
    return { error: "Priority level must be between 0 and 3" };
  }

  try {
    const contact = await sql`
      INSERT INTO emergency_contacts 
      (user_id, name, phone, relationship, is_primary, category, priority_level, notes, address, verified)
      VALUES 
      (${user_id}, ${name}, ${formattedPhone}, ${relationship}, ${is_primary}, ${category}, 
       ${priority_level}, ${notes}, ${address}, false)
      RETURNING *
    `;

    const verificationCode = Math.floor(100000 + Math.random() * 900000);
    await sql`
      INSERT INTO phone_verification (phone, code, expires_at)
      VALUES (${formattedPhone}, ${verificationCode.toString()}, 
      (CURRENT_TIMESTAMP + interval '24 hours'))
    `;

    if (is_primary) {
      await sql`
        UPDATE emergency_contacts 
        SET is_primary = false 
        WHERE user_id = ${user_id} 
        AND id != ${contact[0].id}
      `;
    }

    return {
      contact: contact[0],
      message: "Contact added successfully. Verification code sent.",
    };
  } catch (error) {
    return {
      error: "Failed to add contact",
      details: error.message,
    };
  }
}