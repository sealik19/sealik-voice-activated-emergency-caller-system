"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({
  contacts = [],
  onAddContact,
  onUpdateContact,
  onDeleteContact,
  onTestContact,
  onQuickDial,
  userId = "12345",
  language = "en"
}) {
  const [selectedContact, setSelectedContact] = useState(null);
  const [error, setError] = useState(null);
  const [locationEnabled, setLocationEnabled] = useState(false);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGroup, setSelectedGroup] = useState("all");

  const contactGroups = [
    { id: "all", name: "All Contacts" },
    { id: "family", name: "Family" },
    { id: "medical", name: "Medical" },
    { id: "emergency", name: "Emergency Services" },
    { id: "friends", name: "Friends" },
    { id: "work", name: "Work" }
  ];

  const priorityLevels = [
    { value: "critical", label: "Critical (Immediate Response)", color: "red" },
    { value: "high", label: "High Priority", color: "orange" },
    { value: "medium", label: "Medium Priority", color: "yellow" },
    { value: "low", label: "Low Priority", color: "blue" }
  ];

  useEffect(() => {
    if ('geolocation' in navigator) {
      navigator.permissions.query({ name: 'geolocation' }).then(result => {
        setLocationEnabled(result.state === 'granted');
      });
    }
  }, []);

  const formatPhoneNumber = (phone) => {
    const cleaned = phone.replace(/\D/g, '');
    const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
    if (match) {
      return `(${match[1]}) ${match[2]}-${match[3]}`;
    }
    return phone;
  };

  const validateContact = (contact) => {
    const errors = [];
    if (!contact.name?.trim()) errors.push("Name is required");
    if (!contact.phone?.match(/^\+?[\d\s-()]{10,}$/)) errors.push("Invalid phone number format");
    if (!contact.group) errors.push("Contact group is required");
    if (!contact.priority) errors.push("Priority level is required");
    return errors;
  };

  const handleTestContact = async (contact) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/send-emergency-sms", {
        method: "POST",
        body: JSON.stringify({
          user_id: userId,
          latitude: 0,
          longitude: 0,
          alert_type: "test",
          voice_call: false
        })
      });

      if (!response.ok) {
        throw new Error(`Failed to test contact: ${response.statusText}`);
      }
    } catch (err) {
      setError(`Failed to test contact: ${err.message}`);
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filteredContacts = contacts
    .filter(contact => 
      (selectedGroup === "all" || contact.group === selectedGroup) &&
      (contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
       contact.phone.includes(searchQuery))
    )
    .sort((a, b) => {
      const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
      return priorityOrder[a.priority] - priorityOrder[b.priority];
    });

  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-xl max-w-4xl mx-auto">
      <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-8">
        <h1 className="text-3xl font-bold text-white">Emergency Contacts</h1>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Search contacts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="px-4 py-2 bg-gray-800 text-white rounded border border-gray-700 focus:border-purple-500 focus:outline-none"
          />
          <button
            onClick={onAddContact}
            className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 transition-colors"
          >
            <i className="fas fa-plus mr-2"></i>Add Contact
          </button>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex flex-wrap gap-2">
          {contactGroups.map(group => (
            <button
              key={group.id}
              onClick={() => setSelectedGroup(group.id)}
              className={`px-3 py-1 rounded-full text-sm ${
                selectedGroup === group.id
                  ? "bg-purple-600 text-white"
                  : "bg-gray-800 text-gray-300 hover:bg-gray-700"
              }`}
            >
              {group.name}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {filteredContacts.map((contact) => (
          <div
            key={contact.id}
            className="bg-gray-800 p-4 rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4"
          >
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-white font-semibold">{contact.name}</span>
                <span className={`text-xs px-2 py-1 rounded bg-${priorityLevels.find(p => p.value === contact.priority)?.color}-600`}>
                  {contact.priority}
                </span>
                {contact.group && (
                  <span className="bg-gray-700 text-xs text-gray-300 px-2 py-1 rounded">
                    {contact.group}
                  </span>
                )}
              </div>
              <p className="text-gray-400">{formatPhoneNumber(contact.phone)}</p>
            </div>

            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => onQuickDial(contact)}
                className="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700 transition-colors"
              >
                <i className="fas fa-phone mr-2"></i>Quick Dial
              </button>
              <button
                onClick={() => handleTestContact(contact)}
                disabled={loading}
                className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700 transition-colors disabled:opacity-50"
              >
                <i className="fas fa-vial mr-2"></i>Test
              </button>
              <button
                onClick={() => setSelectedContact(contact)}
                className="bg-gray-700 text-white px-3 py-1 rounded hover:bg-gray-600 transition-colors"
              >
                <i className="fas fa-cog mr-2"></i>Settings
              </button>
              <button
                onClick={() => onDeleteContact(contact.id)}
                className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 transition-colors"
              >
                <i className="fas fa-trash mr-2"></i>Delete
              </button>
            </div>
          </div>
        ))}

        {filteredContacts.length === 0 && (
          <div className="text-center text-gray-400 py-8">
            {searchQuery ? "No contacts found matching your search" : "No emergency contacts added yet"}
          </div>
        )}
      </div>

      {selectedContact && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-gray-800 p-6 rounded-lg max-w-md w-full">
            <h2 className="text-2xl font-bold text-white mb-4">Contact Settings</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-white mb-2">Group</label>
                <select
                  value={selectedContact.group}
                  onChange={(e) => onUpdateContact({
                    ...selectedContact,
                    group: e.target.value
                  })}
                  className="w-full bg-gray-700 text-white rounded p-2"
                >
                  {contactGroups.filter(g => g.id !== "all").map(group => (
                    <option key={group.id} value={group.id}>{group.name}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-white mb-2">Priority Level</label>
                <select
                  value={selectedContact.priority}
                  onChange={(e) => onUpdateContact({
                    ...selectedContact,
                    priority: e.target.value
                  })}
                  className="w-full bg-gray-700 text-white rounded p-2"
                >
                  {priorityLevels.map(level => (
                    <option key={level.value} value={level.value}>{level.label}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-white mb-2">Notification Preferences</label>
                <div className="space-y-2">
                  <label className="flex items-center text-gray-300">
                    <input
                      type="checkbox"
                      checked={selectedContact.sms_enabled}
                      onChange={(e) => onUpdateContact({
                        ...selectedContact,
                        sms_enabled: e.target.checked
                      })}
                      className="mr-2"
                    />
                    SMS Notifications
                  </label>
                  <label className="flex items-center text-gray-300">
                    <input
                      type="checkbox"
                      checked={selectedContact.voice_enabled}
                      onChange={(e) => onUpdateContact({
                        ...selectedContact,
                        voice_enabled: e.target.checked
                      })}
                      className="mr-2"
                    />
                    Voice Calls
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-white mb-2">Location Sharing</label>
                <div className="bg-gray-700 p-3 rounded">
                  <p className="text-gray-300 text-sm">
                    {locationEnabled 
                      ? "Location sharing is enabled"
                      : "Location sharing is disabled. Enable it in your browser settings."
                    }
                  </p>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 mt-6">
              <button
                onClick={() => setSelectedContact(null)}
                className="bg-gray-700 text-white px-4 py-2 rounded hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const errors = validateContact(selectedContact);
                  if (errors.length > 0) {
                    setError(errors.join(", "));
                    return;
                  }
                  onUpdateContact(selectedContact);
                  setSelectedContact(null);
                }}
                className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 transition-colors"
              >
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}

      {error && (
        <div className="fixed bottom-4 right-4 bg-red-600 text-white px-4 py-2 rounded shadow-lg">
          {error}
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  const [contacts, setContacts] = useState([
    {
      id: 1,
      name: "Sarah Johnson",
      phone: "+1234567890",
      group: "family",
      priority: "critical",
      sms_enabled: true,
      voice_enabled: true
    },
    {
      id: 2,
      name: "Dr. Smith",
      phone: "+0987654321",
      group: "medical",
      priority: "high",
      sms_enabled: true,
      voice_enabled: false
    },
    {
      id: 3,
      name: "Local Police",
      phone: "911",
      group: "emergency",
      priority: "critical",
      sms_enabled: false,
      voice_enabled: true
    }
  ]);

  const handleAddContact = () => {
    console.log("Add contact clicked");
  };

  const handleUpdateContact = (updatedContact) => {
    setContacts(contacts.map(contact => 
      contact.id === updatedContact.id ? updatedContact : contact
    ));
  };

  const handleDeleteContact = (contactId) => {
    setContacts(contacts.filter(contact => contact.id !== contactId));
  };

  const handleTestContact = (contact) => {
    console.log("Testing contact:", contact);
  };

  const handleQuickDial = (contact) => {
    console.log("Quick dialing:", contact);
  };

  return (
    <div className="min-h-screen bg-gray-950 p-8 space-y-8">
      <div>
        <h2 className="text-xl text-white mb-4">With Contacts</h2>
        <MainComponent
          contacts={contacts}
          onAddContact={handleAddContact}
          onUpdateContact={handleUpdateContact}
          onDeleteContact={handleDeleteContact}
          onTestContact={handleTestContact}
          onQuickDial={handleQuickDial}
        />
      </div>

      <div>
        <h2 className="text-xl text-white mb-4">Empty State</h2>
        <MainComponent
          contacts={[]}
          onAddContact={handleAddContact}
          onUpdateContact={handleUpdateContact}
          onDeleteContact={handleDeleteContact}
          onTestContact={handleTestContact}
          onQuickDial={handleQuickDial}
        />
      </div>
    </div>
  );
});
}