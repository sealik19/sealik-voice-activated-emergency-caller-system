"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({ userId = "12345", language = "en" }) {
  const [activeTab, setActiveTab] = useState("menstruation");
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [healthData, setHealthData] = useState(null);
  const [highContrast, setHighContrast] = useState(false);

  const [menstruationForm, setMenstruationForm] = useState({
    flow_intensity: 1,
    symptoms: [],
    mood: "neutral",
    physical_symptoms: [],
    medication_notes: ""
  });

  const [pregnancyForm, setPregnancyForm] = useState({
    last_period_date: "",
    symptoms: [],
    checkup_date: "",
    checkup_notes: ""
  });

  const fetchHealthInsights = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/get-health-insights", {
        method: "POST",
        body: JSON.stringify({
          user_id: userId,
          tracking_type: activeTab
        })
      });
      if (!response.ok) throw new Error("Failed to fetch health insights");
      const data = await response.json();
      setHealthData(data);
    } catch (err) {
      setError(err.message);
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const trackMenstruation = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/track-menstruation", {
        method: "POST",
        body: JSON.stringify({
          user_id: userId,
          date: selectedDate.toISOString(),
          ...menstruationForm
        })
      });
      if (!response.ok) throw new Error("Failed to track menstruation");
      await fetchHealthInsights();
    } catch (err) {
      setError(err.message);
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const trackPregnancy = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/track-pregnancy", {
        method: "POST",
        body: JSON.stringify({
          user_id: userId,
          ...pregnancyForm
        })
      });
      if (!response.ok) throw new Error("Failed to track pregnancy");
      await fetchHealthInsights();
    } catch (err) {
      setError(err.message);
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHealthInsights();
  }, [activeTab]);

  const containerClasses = `min-h-screen p-6 ${
    highContrast ? "bg-[#000000] text-[#ffffff]" : "bg-[#f8f5ff] text-[#2d1b4e]"
  }`;

  const tabClasses = (isActive) =>
    `px-6 py-3 rounded-t-lg font-medium transition-colors ${
      isActive
        ? "bg-[#6b46c1] text-white"
        : "bg-[#e9d8fd] text-[#553c9a] hover:bg-[#805ad5] hover:text-white"
    }`;

  const buttonClasses = `px-4 py-2 bg-[#6b46c1] text-white rounded-lg hover:bg-[#553c9a] transition-colors disabled:opacity-50`;

  return (
    <div className={containerClasses}>
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Women's Health Tracker</h1>
          <button
            onClick={() => setHighContrast(!highContrast)}
            className={buttonClasses}
            aria-label="Toggle high contrast mode"
          >
            {highContrast ? "Standard Mode" : "High Contrast Mode"}
          </button>
        </div>

        <div role="tablist" className="flex gap-2 mb-6">
          <button
            role="tab"
            aria-selected={activeTab === "menstruation"}
            className={tabClasses(activeTab === "menstruation")}
            onClick={() => setActiveTab("menstruation")}
          >
            Menstruation Tracking
          </button>
          <button
            role="tab"
            aria-selected={activeTab === "pregnancy"}
            className={tabClasses(activeTab === "pregnancy")}
            onClick={() => setActiveTab("pregnancy")}
          >
            Pregnancy Tracking
          </button>
        </div>

        {error && (
          <div
            role="alert"
            className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4"
          >
            {error}
          </div>
        )}

        {loading ? (
          <div
            role="status"
            className="flex items-center justify-center p-12"
          >
            <div className="animate-spin rounded-full h-12 w-12 border-4 border-[#6b46c1] border-t-transparent"></div>
            <span className="sr-only">Loading...</span>
          </div>
        ) : (
          <div role="tabpanel" className="bg-white rounded-lg shadow-lg p-6">
            {activeTab === "menstruation" ? (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Track Period</h2>
                    <input
                      type="date"
                      className="w-full p-2 border rounded"
                      value={selectedDate.toISOString().split('T')[0]}
                      onChange={(e) => setSelectedDate(new Date(e.target.value))}
                      aria-label="Select date"
                    />
                    <div className="mt-4">
                      <label className="block mb-2">Flow Intensity (1-5)</label>
                      <input
                        type="range"
                        min="1"
                        max="5"
                        value={menstruationForm.flow_intensity}
                        onChange={(e) => setMenstruationForm(prev => ({
                          ...prev,
                          flow_intensity: parseInt(e.target.value)
                        }))}
                        className="w-full"
                      />
                    </div>
                    <button
                      onClick={trackMenstruation}
                      className={buttonClasses + " mt-4"}
                    >
                      Save Period Data
                    </button>
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Cycle Insights</h2>
                    {healthData?.insights && (
                      <div className="space-y-2">
                        <p>Average Cycle: {healthData.insights.average_cycle} days</p>
                        <p>Common Symptoms:</p>
                        <ul className="list-disc pl-5">
                          {Object.entries(healthData.insights.common_symptoms || {}).map(([symptom, count]) => (
                            <li key={symptom}>{symptom}: {count} times</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Pregnancy Progress</h2>
                    <input
                      type="date"
                      className="w-full p-2 border rounded"
                      value={pregnancyForm.last_period_date}
                      onChange={(e) => setPregnancyForm(prev => ({
                        ...prev,
                        last_period_date: e.target.value
                      }))}
                      aria-label="Last period date"
                    />
                    <div className="mt-4">
                      <label className="block mb-2">Symptoms</label>
                      <select
                        multiple
                        className="w-full p-2 border rounded"
                        value={pregnancyForm.symptoms}
                        onChange={(e) => setPregnancyForm(prev => ({
                          ...prev,
                          symptoms: Array.from(e.target.selectedOptions, option => option.value)
                        }))}
                      >
                        <option value="nausea">Nausea</option>
                        <option value="fatigue">Fatigue</option>
                        <option value="cravings">Cravings</option>
                        <option value="mood_swings">Mood Swings</option>
                      </select>
                    </div>
                    <button
                      onClick={trackPregnancy}
                      className={buttonClasses + " mt-4"}
                    >
                      Save Pregnancy Data
                    </button>
                  </div>
                  <div>
                    <h2 className="text-xl font-semibold mb-4">Pregnancy Insights</h2>
                    {healthData?.insights && (
                      <div className="space-y-2">
                        <p>Due Date: {new Date(healthData.insights.due_date).toLocaleDateString()}</p>
                        <p>Current Week: {healthData.insights.current_week}</p>
                        <p>Next Checkup: {healthData.insights.next_checkup}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function StoryComponent() {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-4">Default View</h2>
        <MainComponent userId="12345" language="en" />
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-4">High Contrast Mode</h2>
        <MainComponent userId="12345" language="en" initialHighContrast={true} />
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-4">Loading State</h2>
        <MainComponent userId="12345" language="en" initialLoading={true} />
      </div>
      <div>
        <h2 className="text-2xl font-bold mb-4">Error State</h2>
        <MainComponent userId="12345" language="en" initialError="Failed to load data" />
      </div>
    </div>
  );
});
}