"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({
  language = "en",
  onContactAction,
  pageSize = 10,
  initialContacts = []
}) {
  const [contacts, setContacts] = useState(initialContacts);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [sortField, setSortField] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [filter, setFilter] = useState("all");
  const [hasMore, setHasMore] = useState(true);
  const [isOnline, setIsOnline] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const observerTarget = useRef(null);
  const searchTimeout = useRef(null);

  const translations = {
    en: {
      title: "Emergency Contacts",
      search: "Search contacts...", 
      noContacts: "No emergency contacts found",
      error: "Error loading contacts",
      retry: "Retry",
      offline: "You are offline",
      syncing: "Syncing contacts...",
      sortBy: "Sort by",
      filter: "Filter",
      loadMore: "Load more",
      relationships: ["All", "Family", "Friend", "Neighbor", "Coworker", "Doctor", "Other"],
      sortOptions: {
        name: "Name",
        relationship: "Relationship", 
        priority: "Priority",
        recent: "Recently Added"
      },
      actions: {
        call: "Call",
        edit: "Edit",
        delete: "Delete",
        share: "Share Location"
      }
    },
    am: {
      title: "የአደጋ ጊዜ ተጠሪዎች",
      search: "ተጠሪዎችን ይፈልጉ...",
      noContacts: "የአደጋ ጊዜ ተጠሪዎች አልተገኙም",
      error: "ተጠሪዎችን መጫን አልተሳካም", 
      retry: "እንደገና ይሞክሩ",
      offline: "ከመስመር ውጪ ነዎት",
      sortBy: "አስተካክል በ",
      filter: "አጣራ",
      loadMore: "ተጨማሪ ጫን",
      relationships: ["ሁሉም", "ቤተሰብ", "ጓደኛ", "ጎረቤት", "የስራ ባልደረባ", "ሀኪም", "ሌላ"],
      actions: {
        call: "ደውል",
        edit: "አስተካክል", 
        delete: "ሰርዝ"
      }
    }
  };

  const t = translations[language];

  useEffect(() => {
    const handleOnlineStatus = () => {
      const isOnlineNow = navigator.onLine;
      setIsOnline(isOnlineNow);
      if (isOnlineNow) {
        syncOfflineChanges();
      }
    };
    
    window.addEventListener('online', handleOnlineStatus);
    window.addEventListener('offline', handleOnlineStatus);
    
    return () => {
      window.removeEventListener('online', handleOnlineStatus);
      window.removeEventListener('offline', handleOnlineStatus);
    };
  }, []);

  useEffect(() => {
    const observer = new IntersectionObserver(
      entries => {
        if (entries[0].isIntersecting && hasMore && !loading) {
          loadMoreContacts();
        }
      },
      { threshold: 0.5, rootMargin: '100px' }
    );

    if (observerTarget.current) {
      observer.observe(observerTarget.current);
    }

    return () => observer.disconnect();
  }, [hasMore, loading, sortField, sortOrder, filter, searchQuery]);

  const syncOfflineChanges = async () => {
    try {
      setIsSyncing(true);
      const offlineActions = JSON.parse(localStorage.getItem('offlineActions') || '[]');
      
      for (const action of offlineActions) {
        await processOfflineAction(action);
      }
      
      localStorage.removeItem('offlineActions');
      await loadMoreContacts(true);
    } catch (err) {
      console.error('Sync failed:', err);
    } finally {
      setIsSyncing(false);
    }
  };

  const processOfflineAction = async (action) => {
    try {
      const response = await fetch(`/api/contacts/${action.type}`, {
        method: action.method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(action.data)
      });
      
      if (!response.ok) throw new Error(`Failed to sync ${action.type}`);
    } catch (err) {
      console.error(`Failed to process offline action:`, err);
    }
  };

  const loadMoreContacts = async (reset = false) => {
    if ((loading || !hasMore) && !reset) return;

    setLoading(true);
    setError(null);

    try {
      const queryParams = new URLSearchParams({
        page: reset ? 1 : page,
        size: pageSize,
        sort: sortField,
        order: sortOrder,
        filter,
        search: searchQuery
      });

      const response = await fetch(`/api/contacts?${queryParams}`);
      
      if (!response.ok) {
        throw new Error(`Error: ${response.status}`);
      }

      const data = await response.json();
      
      if (reset) {
        setContacts(data.contacts);
        setPage(2);
      } else {
        setContacts(prev => [...prev, ...data.contacts]);
        setPage(prev => prev + 1);
      }
      
      setHasMore(data.contacts.length === pageSize);
      
      localStorage.setItem('cachedContacts', JSON.stringify({
        contacts: reset ? data.contacts : [...contacts, ...data.contacts],
        timestamp: Date.now()
      }));
    } catch (err) {
      setError(err.message);
      const cached = localStorage.getItem('cachedContacts');
      if (cached) {
        const { contacts: cachedContacts, timestamp } = JSON.parse(cached);
        if (Date.now() - timestamp < 24 * 60 * 60 * 1000) {
          setContacts(cachedContacts);
        }
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSort = (field) => {
    setSortField(field);
    setSortOrder(current => current === 'asc' ? 'desc' : 'asc');
    loadMoreContacts(true);
  };

  const handleFilter = (value) => {
    setFilter(value);
    loadMoreContacts(true);
  };

  const handleSearch = (value) => {
    setSearchQuery(value);
    if (searchTimeout.current) {
      clearTimeout(searchTimeout.current);
    }
    searchTimeout.current = setTimeout(() => {
      loadMoreContacts(true);
    }, 300);
  };

  const handleContactAction = async (action, contact) => {
    if (!isOnline) {
      const offlineActions = JSON.parse(localStorage.getItem('offlineActions') || '[]');
      offlineActions.push({
        type: action,
        method: action === 'delete' ? 'DELETE' : 'PUT',
        data: contact,
        timestamp: Date.now()
      });
      localStorage.setItem('offlineActions', JSON.stringify(offlineActions));
      return;
    }

    try {
      await onContactAction(action, contact);
      if (action === 'delete') {
        setContacts(prev => prev.filter(c => c.id !== contact.id));
      }
    } catch (err) {
      setError(`Failed to ${action} contact`);
    }
  };

  const filteredAndSortedContacts = useMemo(() => {
    return contacts
      .filter(contact => {
        const matchesSearch = !searchQuery || 
          contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          contact.phone.includes(searchQuery);
        const matchesFilter = filter === "all" || contact.relationship.toLowerCase() === filter;
        return matchesSearch && matchesFilter;
      })
      .sort((a, b) => {
        const modifier = sortOrder === 'asc' ? 1 : -1;
        if (sortField === 'recent') {
          return (new Date(b.created_at) - new Date(a.created_at)) * modifier;
        }
        return a[sortField].localeCompare(b[sortField]) * modifier;
      });
  }, [contacts, searchQuery, filter, sortField, sortOrder]);

  return (
    <div className="bg-gray-800 rounded-xl shadow-lg overflow-hidden">
      <div className="p-6 border-b border-gray-700">
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-white">{t.title}</h2>
          {(isSyncing || !isOnline) && (
            <div className="flex items-center gap-2 text-sm">
              {isSyncing ? (
                <span className="text-blue-400">
                  <i className="fas fa-sync fa-spin mr-2"></i>{t.syncing}
                </span>
              ) : (
                <span className="text-amber-400">
                  <i className="fas fa-wifi-slash mr-2"></i>{t.offline}
                </span>
              )}
            </div>
          )}
        </div>

        <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
          <input
            type="text"
            placeholder={t.search}
            className="p-2 rounded-lg bg-gray-700 text-white border border-gray-600 focus:border-blue-500 focus:outline-none"
            onChange={(e) => handleSearch(e.target.value)}
          />
          
          <select
            className="p-2 rounded-lg bg-gray-700 text-white border border-gray-600 focus:border-blue-500 focus:outline-none"
            onChange={(e) => handleFilter(e.target.value)}
            value={filter}
          >
            {t.relationships.map(rel => (
              <option key={rel} value={rel.toLowerCase()}>{rel}</option>
            ))}
          </select>

          <select
            className="p-2 rounded-lg bg-gray-700 text-white border border-gray-600 focus:border-blue-500 focus:outline-none"
            onChange={(e) => handleSort(e.target.value)}
            value={sortField}
          >
            {Object.entries(t.sortOptions).map(([value, label]) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-500/10 border-l-4 border-red-500 text-red-500">
          <p>{error}</p>
          <button
            onClick={() => loadMoreContacts(true)}
            className="mt-2 text-sm underline hover:no-underline"
          >
            {t.retry}
          </button>
        </div>
      )}

      <div className="divide-y divide-gray-700">
        {filteredAndSortedContacts.map(contact => (
          <div
            key={contact.id}
            className="p-4 hover:bg-gray-700/50 transition-colors"
          >
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-white font-medium flex items-center gap-2">
                  {contact.name}
                  {contact.is_primary && (
                    <span className="text-xs bg-yellow-500/20 text-yellow-400 px-2 py-1 rounded-full">
                      Primary
                    </span>
                  )}
                </h3>
                <p className="text-gray-400 text-sm">{contact.phone}</p>
                <div className="flex gap-2 mt-1">
                  <span className="inline-block px-2 py-1 text-xs rounded-full bg-blue-500/20 text-blue-400">
                    {contact.relationship}
                  </span>
                  {contact.address && (
                    <span className="inline-block px-2 py-1 text-xs rounded-full bg-purple-500/20 text-purple-400">
                      {contact.address}
                    </span>
                  )}
                </div>
              </div>
              
              <div className="flex gap-2">
                <button
                  onClick={() => handleContactAction('call', contact)}
                  className="p-2 text-green-400 hover:bg-green-400/20 rounded-lg transition-colors"
                  aria-label={t.actions.call}
                >
                  <i className="fas fa-phone"></i>
                </button>
                <button
                  onClick={() => handleContactAction('share', contact)}
                  className="p-2 text-blue-400 hover:bg-blue-400/20 rounded-lg transition-colors"
                  aria-label={t.actions.share}
                >
                  <i className="fas fa-share-alt"></i>
                </button>
                <button
                  onClick={() => handleContactAction('edit', contact)}
                  className="p-2 text-yellow-400 hover:bg-yellow-400/20 rounded-lg transition-colors"
                  aria-label={t.actions.edit}
                >
                  <i className="fas fa-edit"></i>
                </button>
                <button
                  onClick={() => handleContactAction('delete', contact)}
                  className="p-2 text-red-400 hover:bg-red-400/20 rounded-lg transition-colors"
                  aria-label={t.actions.delete}
                >
                  <i className="fas fa-trash"></i>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {loading && (
        <div className="p-4 text-center text-gray-400">
          <div className="animate-spin inline-block w-6 h-6 border-2 border-current border-t-transparent rounded-full"></div>
        </div>
      )}

      {!loading && filteredAndSortedContacts.length === 0 && (
        <div className="p-8 text-center text-gray-400">
          {t.noContacts}
        </div>
      )}

      <div ref={observerTarget} className="h-4"></div>
    </div>
  );
}

function StoryComponent() {
  const [language, setLanguage] = useState("en");
  
  const mockContacts = [
    {
      id: 1, 
      name: "John Doe",
      phone: "+1234567890",
      relationship: "family",
      is_primary: true,
      address: "123 Main St",
      created_at: "2025-01-01T00:00:00Z"
    },
    {
      id: 2,
      name: "Jane Smith", 
      phone: "+0987654321",
      relationship: "friend",
      is_primary: false,
      address: "456 Oak Ave",
      created_at: "2025-01-02T00:00:00Z"
    },
    {
      id: 3,
      name: "Dr. Wilson",
      phone: "+1122334455", 
      relationship: "doctor",
      is_primary: false,
      created_at: "2025-01-03T00:00:00Z"
    }
  ];

  const handleContactAction = async (action, contact) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log(`Action: ${action}`, contact);
  };

  return (
    <div className="p-8 space-y-8 bg-gray-900">
      <div className="mb-4 flex justify-end">
        <button
          onClick={() => setLanguage(language === "en" ? "am" : "en")}
          className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600"
        >
          {language === "en" ? "Switch to Amharic" : "Switch to English"}
        </button>
      </div>

      <div className="max-w-3xl mx-auto">
        <MainComponent
          language={language}
          initialContacts={mockContacts}
          onContactAction={handleContactAction}
        />
      </div>
    </div>
  );
});
}