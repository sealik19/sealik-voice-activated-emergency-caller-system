"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({ 
  value = '', 
  onChange, 
  onResend, 
  language = 'en',
  error = null,
  disabled = false,
  resendDelay = 60
}) {
  const [digits, setDigits] = useState(Array.from({length: 6}).fill(''));
  const [countdown, setCountdown] = useState(0);
  const inputRefs = useRef([...Array.from({length: 6})].map(() => React.createRef()));

  const text = {
    en: {
      resend: 'Resend code',
      resendIn: 'Resend code in',
      seconds: 'seconds',
      invalid: 'Please enter a valid verification code'
    },
    am: {
      resend: 'ኮድ እንደገና ላክ',
      resendIn: 'ኮድ እንደገና ለመላክ',
      seconds: 'ሰከንዶች',
      invalid: 'እባክዎ ትክክለኛ የማረጋገጫ ኮድ ያስገቡ'
    }
  };

  useEffect(() => {
    if (value) {
      const valueArray = value.split('').slice(0, 6);
      setDigits(valueArray.concat(Array(6 - valueArray.length).fill('')));
    }
  }, [value]);

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown]);

  const handleDigitChange = (index, digit) => {
    if (!/^\d*$/.test(digit)) return;

    const newDigits = [...digits];
    newDigits[index] = digit;
    setDigits(newDigits);
    onChange?.(newDigits.join(''));

    if (digit && index < 5) {
      inputRefs.current[index + 1].current.focus();
    }
  };

  const handleKeyDown = (index, e) => {
    if (e.key === 'Backspace' && !digits[index] && index > 0) {
      inputRefs.current[index - 1].current.focus();
    }
  };

  const handlePaste = (e) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData('text').replace(/[^\d]/g, '').slice(0, 6);
    const newDigits = [...Array.from({length: 6})].map((_, index) => pastedData[index] || '');
    setDigits(newDigits);
    onChange?.(newDigits.join(''));
  };

  const handleResend = () => {
    onResend?.();
    setCountdown(resendDelay);
  };

  return (
    <div className="w-full max-w-md mx-auto">
      <div className="flex justify-between gap-2">
        {digits.map((digit, index) => (
          <input
            key={index}
            ref={inputRefs.current[index]}
            type="text"
            maxLength={1}
            value={digit}
            onChange={(e) => handleDigitChange(index, e.target.value)}
            onKeyDown={(e) => handleKeyDown(index, e)}
            onPaste={index === 0 ? handlePaste : undefined}
            disabled={disabled}
            className={`
              w-12 h-12 text-center text-2xl rounded-lg
              border-2 focus:outline-none focus:ring-2
              ${error ? 'border-red-500 focus:ring-red-200' : 'border-gray-300 focus:ring-blue-200'}
              ${disabled ? 'bg-gray-100' : 'bg-white'}
            `}
          />
        ))}
      </div>
      
      {error && (
        <p className="mt-2 text-sm text-red-500">
          {text[language].invalid}
        </p>
      )}

      <div className="mt-4 text-center">
        {countdown > 0 ? (
          <p className="text-gray-500">
            {text[language].resendIn} {countdown} {text[language].seconds}
          </p>
        ) : (
          <button
            onClick={handleResend}
            disabled={disabled}
            className="text-blue-600 hover:text-blue-800 disabled:text-gray-400"
          >
            {text[language].resend}
          </button>
        )}
      </div>
    </div>
  );
}

function StoryComponent() {
  const [code1, setCode1] = useState('');
  const [code2, setCode2] = useState('123');
  const [code3, setCode3] = useState('');
  const [error3, setError3] = useState('Invalid code');
  
  return (
    <div className="p-8 space-y-12">
      <div>
        <h2 className="text-xl font-bold mb-4">Default (English)</h2>
        <MainComponent
          value={code1}
          onChange={setCode1}
          onResend={() => console.log('Resend requested')}
        />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">With Initial Value</h2>
        <MainComponent
          value={code2}
          onChange={setCode2}
          onResend={() => console.log('Resend requested')}
        />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">With Error State</h2>
        <MainComponent
          value={code3}
          onChange={setCode3}
          error={error3}
          onResend={() => console.log('Resend requested')}
        />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Amharic Version</h2>
        <MainComponent
          value={code3}
          onChange={setCode3}
          language="am"
          onResend={() => console.log('Resend requested')}
        />
      </div>

      <div>
        <h2 className="text-xl font-bold mb-4">Disabled State</h2>
        <MainComponent
          value="123456"
          onChange={() => {}}
          disabled
          onResend={() => console.log('Resend requested')}
        />
      </div>
    </div>
  );
});
}