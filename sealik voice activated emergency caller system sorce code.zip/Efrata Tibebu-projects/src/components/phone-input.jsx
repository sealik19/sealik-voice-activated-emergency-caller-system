"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({
  language = "en",
  onLanguageChange,
  isAuthenticated = false,
  onLogin,
  onRegister,
  onLogout,
  onEmergency,
  onSearch,
  notifications = [],
  userName = "",
  userAvatar = "",
  isOnline = true,
  loading = false
}) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);

  const menuRef = useRef(null);
  const searchRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) {
        setIsUserMenuOpen(false);
      }
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setSearchResults([]);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = async (e) => {
    e.preventDefault();
    setIsSearching(true);
    try {
      const response = await fetch(`/integrations/google-place-autocomplete/autocomplete/json?input=${searchQuery}&radius=500`);
      if (!response.ok) throw new Error('Search failed');
      const data = await response.json();
      setSearchResults(data.predictions || []);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const content = {
    en: {
      nav: {
        home: "Home",
        safety: "Safety",
        health: "Health",
        resources: "Resources"
      },
      auth: {
        login: "Login",
        register: "Register",
        logout: "Logout"
      },
      search: {
        placeholder: "Search locations...",
        noResults: "No results found"
      },
      notifications: {
        title: "Notifications",
        empty: "No new notifications",
        markRead: "Mark all as read"
      },
      status: {
        online: "Online",
        offline: "Offline"
      },
      emergency: "Emergency"
    },
    am: {
      nav: {
        home: "መነሻ",
        safety: "ደህንነት",
        health: "ጤና",
        resources: "ሀብቶች"
      },
      auth: {
        login: "ግባ",
        register: "ተመዝገብ",
        logout: "ውጣ"
      },
      search: {
        placeholder: "ቦታዎችን ፈልግ...",
        noResults: "ምንም ውጤት አልተገኘም"
      },
      notifications: {
        title: "ማሳወቂያዎች",
        empty: "አዲስ ማሳወቂያ የለም",
        markRead: "ሁሉንም እንደተነበበ ምልክት አድርግ"
      },
      status: {
        online: "መስመር ላይ",
        offline: "ከመስመር ውጪ"
      },
      emergency: "አደጋ"
    }
  };

  const t = content[language];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-gray-900 via-purple-900/20 to-gray-800 border-b border-purple-500/20 backdrop-blur-sm">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" role="navigation">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <img
                className="h-8 w-auto"
                src="https://ucarecdn.com/17d8d49b-c56c-4af1-b41f-19579e9d34e5/-/format/auto/"
                alt="Sealik Logo"
              />
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {Object.entries(t.nav).map(([key, value]) => (
                  <a
                    key={key}
                    href={`/${key}`}
                    className="text-gray-300 hover:bg-gray-700 hover:text-white px-3 py-2 rounded-md text-sm font-medium"
                  >
                    {value}
                  </a>
                ))}
              </div>
            </div>
          </div>

          <div className="hidden md:flex items-center space-x-4">
            <div ref={searchRef} className="relative">
              <form onSubmit={handleSearch} className="relative">
                <input
                  type="search"
                  placeholder={t.search.placeholder}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-64 px-4 py-2 rounded-lg bg-gray-800 text-white border border-gray-700 focus:outline-none focus:border-purple-500"
                  aria-label="Search"
                />
                {isSearching && (
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                    <div className="animate-spin h-5 w-5 border-2 border-purple-500 rounded-full border-t-transparent"></div>
                  </div>
                )}
              </form>
              {searchResults.length > 0 && (
                <div className="absolute top-full mt-2 w-full bg-gray-800 rounded-lg shadow-xl border border-gray-700">
                  {searchResults.map((result, index) => (
                    <button
                      key={index}
                      onClick={() => {
                        onSearch?.(result);
                        setSearchResults([]);
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-gray-700 text-white"
                    >
                      {result.description}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="relative">
              <button
                onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                className="flex items-center space-x-2 text-white"
                aria-expanded={isUserMenuOpen}
                aria-haspopup="true"
              >
                <div className={`h-2 w-2 rounded-full ${isOnline ? 'bg-green-500' : 'bg-red-500'}`}></div>
                <span>{isOnline ? t.status.online : t.status.offline}</span>
              </button>
            </div>

            <button
              onClick={onEmergency}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
              aria-label={t.emergency}
            >
              {t.emergency}
            </button>

            {isAuthenticated ? (
              <div ref={menuRef} className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-2"
                  aria-expanded={isUserMenuOpen}
                >
                  <img
                    src={userAvatar || "https://via.placeholder.com/32"}
                    alt={userName}
                    className="h-8 w-8 rounded-full"
                  />
                  <span className="text-white">{userName}</span>
                </button>

                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-gray-800 rounded-lg shadow-xl">
                    <div className="py-1">
                      <button
                        onClick={onLogout}
                        className="block w-full text-left px-4 py-2 text-white hover:bg-gray-700"
                      >
                        {t.auth.logout}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  onClick={onLogin}
                  className="text-white hover:bg-gray-700 px-3 py-2 rounded-md text-sm font-medium"
                >
                  {t.auth.login}
                </button>
                <button
                  onClick={onRegister}
                  className="bg-purple-600 text-white px-3 py-2 rounded-md text-sm font-medium hover:bg-purple-700"
                >
                  {t.auth.register}
                </button>
              </div>
            )}

            <button
              onClick={() => onLanguageChange?.(language === "en" ? "am" : "en")}
              className="text-white hover:bg-gray-700 px-3 py-2 rounded-md text-sm font-medium"
              aria-label="Switch language"
            >
              {language === "en" ? "አማርኛ" : "English"}
            </button>
          </div>

          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white"
              aria-expanded={isMenuOpen}
            >
              <i className={`fas fa-${isMenuOpen ? 'times' : 'bars'}`}></i>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
              {Object.entries(t.nav).map(([key, value]) => (
                <a
                  key={key}
                  href={`/${key}`}
                  className="text-gray-300 hover:bg-gray-700 hover:text-white block px-3 py-2 rounded-md text-base font-medium"
                >
                  {value}
                </a>
              ))}
            </div>
          </div>
        )}
      </nav>

      {loading && (
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-purple-500/20">
          <div className="h-full w-1/3 bg-purple-500 animate-loading"></div>
        </div>
      )}

      <style jsx global>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(400%); }
        }
        .animate-loading {
          animation: loading 1.5s infinite;
        }
      `}</style>
    </header>
  );
}

function StoryComponent() {
  const [language, setLanguage] = useState("en");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isOnline, setIsOnline] = useState(true);
  const [loading, setLoading] = useState(false);

  return (
    <div className="space-y-32 bg-gray-900 min-h-screen pt-20">
      <div>
        <h2 className="text-xl text-white mb-4">Default Header</h2>
        <MainComponent
          language={language}
          onLanguageChange={setLanguage}
          isAuthenticated={isAuthenticated}
          onLogin={() => setIsAuthenticated(true)}
          onRegister={() => setIsAuthenticated(true)}
          onLogout={() => setIsAuthenticated(false)}
          isOnline={isOnline}
          loading={loading}
        />
      </div>

      <div>
        <h2 className="text-xl text-white mb-4">Authenticated Header</h2>
        <MainComponent
          language={language}
          onLanguageChange={setLanguage}
          isAuthenticated={true}
          userName="Jane Doe"
          userAvatar="https://via.placeholder.com/32"
          notifications={[
            { id: 1, message: "New safety alert in your area" },
            { id: 2, message: "Emergency contact updated" }
          ]}
          isOnline={isOnline}
          loading={loading}
        />
      </div>

      <div>
        <h2 className="text-xl text-white mb-4">Offline State</h2>
        <MainComponent
          language={language}
          onLanguageChange={setLanguage}
          isAuthenticated={true}
          userName="Jane Doe"
          userAvatar="https://via.placeholder.com/32"
          isOnline={false}
          loading={loading}
        />
      </div>

      <div>
        <h2 className="text-xl text-white mb-4">Loading State</h2>
        <MainComponent
          language={language}
          onLanguageChange={setLanguage}
          isAuthenticated={true}
          userName="Jane Doe"
          userAvatar="https://via.placeholder.com/32"
          isOnline={true}
          loading={true}
        />
      </div>
    </div>
  );
});
}