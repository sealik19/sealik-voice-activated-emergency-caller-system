"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({
  currentLocation = { lat: 9.0320, lng: 38.7520 },
  safeLocations = [],
  emergencyContacts = [],
  hospitals = [],
  dangerZones = [],
  meetupPoints = [],
  crowdAlerts = [], 
  customMarkers = [],
  onSaveLocation,
  onSelectLocation,
  onShareLocation,
  onEmergency,
  onAddMarker,
  onUpdateRoute,
  onToggleNightMode,
  onVoiceNavigation,
  language = "en",
  isOffline = false,
  nightMode = false,
  accessibilityMode = false
}) {
  const [searchInput, setSearchInput] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showSOS, setShowSOS] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const [activeTab, setActiveTab] = useState('map');
  const [userLocation, setUserLocation] = useState(currentLocation);
  const [isTracking, setIsTracking] = useState(false);
  const [showLegend, setShowLegend] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState(null);
  const [voiceEnabled, setVoiceEnabled] = useState(false);

  useEffect(() => {
    if (isTracking) {
      const watchId = navigator.geolocation.watchPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude
          });
        },
        (error) => console.error(error),
        { enableHighAccuracy: true }
      );
      return () => navigator.geolocation.clearWatch(watchId);
    }
  }, [isTracking]);

  const handleSearch = async (input) => {
    setSearchInput(input);
    if (!input) {
      setSearchResults([]);
      return;
    }

    if (isOffline) {
      setError(language === "en" ? "Search unavailable offline" : "ፍለጋ ከመስመር ውጪ አይገኝም");
      return;
    }

    try {
      setLoading(true);
      const response = await fetch(`/integrations/google-place-autocomplete/autocomplete/json?input=${input}&radius=500`);
      if (!response.ok) throw new Error("Search failed");
      const data = await response.json();
      setSearchResults(data.predictions);
    } catch (err) {
      setError(language === "en" ? "Failed to search locations" : "ቦታዎችን ለመፈለግ አልተሳካም");
    } finally {
      setLoading(false);
    }
  };

  const handleLocationSelect = (location) => {
    setSelectedLocation(location);
    onSelectLocation?.(location);
    setSearchInput("");
    setSearchResults([]);
    if (voiceEnabled) {
      const message = `Selected location: ${location.description}`;
      const utterance = new SpeechSynthesisUtterance(message);
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleShareLocation = () => {
    setIsSharing(true);
    onShareLocation?.();
    setTimeout(() => setIsSharing(false), 2000);
  };

  const renderMapControls = () => (
    <div className="absolute bottom-20 right-4 z-20 flex flex-col gap-2">
      <button
        onClick={() => setIsTracking(!isTracking)}
        className={`p-4 ${isTracking ? 'bg-green-500' : 'bg-gray-500'} text-white rounded-full shadow-lg transition-all`}
        aria-label={isTracking ? "Stop tracking" : "Start tracking"}
      >
        <i className="fas fa-location-arrow"></i>
      </button>
      <button
        onClick={() => onToggleNightMode?.(!nightMode)}
        className={`p-4 ${nightMode ? 'bg-purple-500' : 'bg-gray-500'} text-white rounded-full shadow-lg transition-all`}
        aria-label={nightMode ? "Day mode" : "Night mode"}
      >
        <i className={`fas fa-${nightMode ? 'sun' : 'moon'}`}></i>
      </button>
      <button
        onClick={() => setVoiceEnabled(!voiceEnabled)}
        className={`p-4 ${voiceEnabled ? 'bg-blue-500' : 'bg-gray-500'} text-white rounded-full shadow-lg transition-all`}
        aria-label={voiceEnabled ? "Disable voice" : "Enable voice"}
      >
        <i className={`fas fa-${voiceEnabled ? 'volume-up' : 'volume-mute'}`}></i>
      </button>
      <button
        onClick={() => setShowLegend(!showLegend)}
        className="p-4 bg-gray-500 text-white rounded-full shadow-lg transition-all"
        aria-label="Show legend"
      >
        <i className="fas fa-info"></i>
      </button>
    </div>
  );

  const renderLegend = () => (
    <div className="absolute bottom-4 left-4 z-20 bg-black/80 p-4 rounded-lg text-white text-sm">
      <h4 className="font-bold mb-2">{language === "en" ? "Map Legend" : "የካርታ ምልክቶች"}</h4>
      <div className="space-y-2">
        <div className="flex items-center gap-2">
          <i className="fas fa-shield-alt text-green-500"></i>
          <span>{language === "en" ? "Safe Zone" : "ደህንነት ዞን"}</span>
        </div>
        <div className="flex items-center gap-2">
          <i className="fas fa-exclamation-triangle text-red-500"></i>
          <span>{language === "en" ? "Danger Zone" : "አደገኛ ዞን"}</span>
        </div>
        <div className="flex items-center gap-2">
          <i className="fas fa-hospital text-blue-500"></i>
          <span>{language === "en" ? "Emergency Services" : "የድንገተኛ አገልግሎቶች"}</span>
        </div>
        <div className="flex items-center gap-2">
          <i className="fas fa-users text-yellow-500"></i>
          <span>{language === "en" ? "Meetup Point" : "የመገናኛ ቦታ"}</span>
        </div>
      </div>
    </div>
  );

  return (
    <div className={`relative w-full h-[600px] md:h-[800px] rounded-xl overflow-hidden ${
      nightMode ? 'bg-[#121212]' : 'bg-gradient-to-br from-gray-900 to-[#1a1a2e]'
    }`}>
      <div className="absolute top-4 left-4 right-4 z-20">
        <div className="relative backdrop-blur-lg bg-white/10 rounded-2xl p-1 shadow-lg border border-purple-500/20">
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-purple-500/20 to-blue-500/20 animate-pulse"></div>
          <input
            type="text"
            value={searchInput}
            onChange={(e) => handleSearch(e.target.value)}
            placeholder={language === "en" ? "Search safe locations..." : "ደህንነት ያለው ቦታዎችን ይፈልጉ..."}
            className="w-full px-6 py-3 bg-transparent text-white rounded-xl focus:outline-none placeholder-white/70"
          />
          {loading && (
            <div className="absolute right-4 top-1/2 transform -translate-y-1/2">
              <div className="animate-spin rounded-full h-6 w-6 border-2 border-purple-500 border-t-transparent"></div>
            </div>
          )}
        </div>

        {searchResults.length > 0 && (
          <div className="absolute w-full mt-2 backdrop-blur-lg bg-white/10 rounded-xl shadow-lg border border-purple-500/20 overflow-hidden">
            {searchResults.map((result, index) => (
              <button
                key={index}
                onClick={() => handleLocationSelect(result)}
                className="w-full px-6 py-3 text-left text-white hover:bg-white/20 transition-all"
              >
                <div className="flex items-center gap-3">
                  <i className="fas fa-map-marker-alt text-purple-400"></i>
                  <span>{result.description}</span>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>

      <div className="absolute top-20 right-4 z-20 flex flex-col gap-2">
        <button
          onClick={() => setShowSOS(!showSOS)}
          className="p-4 bg-red-500 text-white rounded-full shadow-lg hover:bg-red-600 transition-all transform hover:scale-105"
        >
          <i className="fas fa-exclamation-triangle text-2xl"></i>
        </button>
        <button
          onClick={handleShareLocation}
          className={`p-4 bg-purple-500 text-white rounded-full shadow-lg hover:bg-purple-600 transition-all transform hover:scale-105 ${
            isSharing ? 'animate-ping' : ''
          }`}
        >
          <i className="fas fa-share-alt text-2xl"></i>
        </button>
      </div>

      {renderMapControls()}

      {showLegend && renderLegend()}

      <div className="absolute bottom-4 left-4 z-20 flex flex-col gap-2">
        <button
          onClick={() => setActiveTab('map')}
          className={`p-4 backdrop-blur-lg ${
            activeTab === 'map' ? 'bg-purple-500' : 'bg-white/10'
          } text-white rounded-full shadow-lg transition-all`}
        >
          <i className="fas fa-map text-xl"></i>
        </button>
        <button
          onClick={() => setActiveTab('safety')}
          className={`p-4 backdrop-blur-lg ${
            activeTab === 'safety' ? 'bg-purple-500' : 'bg-white/10'
          } text-white rounded-full shadow-lg transition-all`}
        >
          <i className="fas fa-shield-alt text-xl"></i>
        </button>
      </div>

      {showSOS && (
        <div className="absolute inset-0 z-30 bg-black/80 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-gradient-to-br from-red-500 to-red-700 p-8 rounded-2xl max-w-md w-full mx-4 transform animate-slideIn">
            <h3 className="text-2xl font-bold text-white mb-6">
              {language === "en" ? "Emergency Services" : "የድንገተኛ አገልግሎቶች"}
            </h3>
            <div className="grid grid-cols-2 gap-4">
              <button className="bg-white/20 p-4 rounded-xl text-white hover:bg-white/30 transition-all">
                <i className="fas fa-ambulance text-2xl mb-2"></i>
                <div>Ambulance</div>
              </button>
              <button className="bg-white/20 p-4 rounded-xl text-white hover:bg-white/30 transition-all">
                <i className="fas fa-police-box text-2xl mb-2"></i>
                <div>Police</div>
              </button>
            </div>
            <button
              onClick={() => setShowSOS(false)}
              className="mt-6 w-full bg-white/20 py-2 rounded-lg text-white hover:bg-white/30 transition-all"
            >
              {language === "en" ? "Close" : "ዝጋ"}
            </button>
          </div>
        </div>
      )}

      <div className={`w-full h-full rounded-xl relative overflow-hidden ${
        nightMode ? 'brightness-75' : ''
      }`}>
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/40"></div>
        <div className="w-full h-full flex items-center justify-center text-gray-400">
          <div className="text-center">
            <div className="animate-pulse mb-4">
              <i className="fas fa-map-marked-alt text-4xl text-purple-500"></i>
            </div>
            <p>{language === "en" ? "Loading safe locations..." : "ደህንነት ያላቸው ቦታዎችን በመጫን ላይ..."}</p>
          </div>
        </div>
      </div>

      <style jsx global>{`
        @keyframes slideIn {
          from { transform: translateY(100%); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .animate-slideIn {
          animation: slideIn 0.3s ease-out forwards;
        }
      `}</style>
    </div>
  );
}

function StoryComponent() {
  const mockSafeLocations = [
    { id: 1, name: "Home", lat: 9.0320, lng: 38.7520, safetyScore: 95 },
    { id: 2, name: "Work", lat: 9.0340, lng: 38.7540, safetyScore: 88 }
  ];

  const mockEmergencyContacts = [
    { id: 1, name: "Police Station", lat: 9.0330, lng: 38.7530, type: "police" },
    { id: 2, name: "Hospital", lat: 9.0310, lng: 38.7510, type: "hospital" }
  ];

  const mockDangerZones = [
    { id: 1, name: "Construction Site", lat: 9.0350, lng: 38.7550, risk: "high" },
    { id: 2, name: "Flood Risk Area", lat: 9.0360, lng: 38.7560, risk: "medium" }
  ];

  const mockMeetupPoints = [
    { id: 1, name: "City Hall", lat: 9.0370, lng: 38.7570 },
    { id: 2, name: "Central Park", lat: 9.0380, lng: 38.7580 }
  ];

  return (
    <div className="p-4 bg-gray-900 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        <h2 className="text-2xl font-bold text-white mb-4">Safety Map (Standard)</h2>
        <MainComponent
          safeLocations={mockSafeLocations}
          emergencyContacts={mockEmergencyContacts}
          dangerZones={mockDangerZones}
          meetupPoints={mockMeetupPoints}
          language="en"
        />

        <h2 className="text-2xl font-bold text-white mb-4">Safety Map (Night Mode)</h2>
        <MainComponent
          safeLocations={mockSafeLocations}
          emergencyContacts={mockEmergencyContacts}
          dangerZones={mockDangerZones}
          meetupPoints={mockMeetupPoints}
          language="en"
          nightMode={true}
        />

        <h2 className="text-2xl font-bold text-white mb-4">Safety Map (Offline)</h2>
        <MainComponent
          safeLocations={mockSafeLocations}
          emergencyContacts={mockEmergencyContacts}
          dangerZones={mockDangerZones}
          meetupPoints={mockMeetupPoints}
          language="en"
          isOffline={true}
        />

        <h2 className="text-2xl font-bold text-white mb-4">Safety Map (Amharic)</h2>
        <MainComponent
          safeLocations={mockSafeLocations}
          emergencyContacts={mockEmergencyContacts}
          dangerZones={mockDangerZones}
          meetupPoints={mockMeetupPoints}
          language="am"
        />
      </div>
    </div>
  );
});
}