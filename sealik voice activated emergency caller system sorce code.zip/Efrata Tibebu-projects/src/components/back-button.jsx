"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({ onClick, showText = true, language = "en" }) {
  const buttonText = {
    en: "Back",
    am: "ተመለስ",
  };

  return (
    <button
      onClick={onClick}
      aria-label={buttonText[language]}
      className="inline-flex items-center px-4 py-2 text-white bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors focus:outline-none focus:ring-2 focus:ring-gray-600 focus:ring-offset-2 focus:ring-offset-gray-900"
    >
      <span className="text-xl mr-2">←</span>
      {showText && <span className="font-medium">{buttonText[language]}</span>}
    </button>
  );
}

function StoryComponent() {
  const handleClick = () => console.log("Back button clicked");

  return (
    <div className="p-8 bg-gray-900 min-h-screen space-y-8">
      <div className="space-y-4">
        <h2 className="text-white text-xl mb-4">English Variants</h2>
        <div className="space-x-4">
          <MainComponent onClick={handleClick} language="en" showText={true} />
          <MainComponent onClick={handleClick} language="en" showText={false} />
        </div>
      </div>

      <div className="space-y-4">
        <h2 className="text-white text-xl mb-4">Amharic Variants</h2>
        <div className="space-x-4">
          <MainComponent onClick={handleClick} language="am" showText={true} />
          <MainComponent onClick={handleClick} language="am" showText={false} />
        </div>
      </div>
    </div>
  );
});
}