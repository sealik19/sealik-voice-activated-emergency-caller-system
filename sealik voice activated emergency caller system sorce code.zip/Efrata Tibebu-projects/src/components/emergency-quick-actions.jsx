"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({
  language = "en",
  onEmergency,
  onLocationShare,
  onCallContact,
  contacts = [],
  accessibilityMode = "standard", 
  isOnline = true
}) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isSharing, setIsSharing] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filter, setFilter] = useState("all");
  const [pendingActions, setPendingActions] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('pendingEmergencyActions') || '[]');
    } catch {
      return [];
    }
  });

  const sortedContacts = useMemo(() => {
    return [...contacts].sort((a, b) => {
      if (a.isPriority && !b.isPriority) return -1;
      if (!a.isPriority && b.isPriority) return 1;
      
      if (a.type === 'emergency' && b.type !== 'emergency') return -1;
      if (a.type !== 'emergency' && b.type === 'emergency') return 1;
      
      return a.name.localeCompare(b.name, language === 'en' ? 'en-US' : 'am-ET');
    });
  }, [contacts, language]);

  const filteredContacts = useMemo(() => {
    const normalizedQuery = searchQuery.toLowerCase().replace(/[^0-9a-z]/g, '');
    return sortedContacts.filter(contact => {
      const normalizedName = contact.name.toLowerCase().replace(/[^0-9a-z]/g, '');
      const normalizedPhone = contact.phone.replace(/[^0-9+]/g, '');
      
      const matchesSearch = 
        normalizedName.includes(normalizedQuery) ||
        normalizedPhone.includes(normalizedQuery) ||
        (contact.type && contact.type.toLowerCase().includes(normalizedQuery));
        
      const matchesFilter = filter === "all" || contact.type === filter;
      
      return matchesSearch && matchesFilter;
    });
  }, [sortedContacts, searchQuery, filter]);

  const formatPhoneNumber = (phone) => {
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.startsWith('251')) {
      return `+251 ${cleaned.slice(3, 5)} ${cleaned.slice(5, 8)} ${cleaned.slice(8)}`;
    }
    return phone;
  };

  const handleError = async (error, action, retryCount = 0) => {
    console.error(error);
    if (!isOnline && retryCount < 3) {
      const pendingAction = { action, timestamp: Date.now(), retryCount };
      setPendingActions(prev => [...prev, pendingAction]);
      localStorage.setItem('pendingEmergencyActions', JSON.stringify(pendingActions));
      setSuccess(labels[language].offlineSaved);
    } else {
      setError(labels[language][`error${action.charAt(0).toUpperCase() + action.slice(1)}`]);
    }
  };

  useEffect(() => {
    if (isOnline && pendingActions.length > 0) {
      const processPendingActions = async () => {
        for (const action of pendingActions) {
          try {
            switch (action.action) {
              case 'emergency':
                await handleEmergency(action.type, action.retryCount + 1);
                break;
              case 'shareLocation':
                await handleShareLocation(action.retryCount + 1);
                break;
            }
          } catch (error) {
            handleError(error, action.action, action.retryCount + 1);
          }
        }
        setPendingActions([]);
        localStorage.removeItem('pendingEmergencyActions');
      };
      processPendingActions();
    }
  }, [isOnline]);

  const handleEmergency = async (type, retryCount = 0) => {
    if (!onEmergency || !type) return;
    
    setLoading(true);
    setError(null);
    try {
      if (!isOnline) {
        handleError(new Error('Offline'), 'emergency', retryCount);
      } else {
        await onEmergency(type);
        navigator.vibrate?.(200);
        setSuccess(labels[language].alertSent);
      }
    } catch (err) {
      handleError(err, 'emergency', retryCount);
    } finally {
      setLoading(false);
    }
  };

  const handleShareLocation = async () => {
    if (!onLocationShare) return;
    
    setLoading(true);
    setError(null);
    try {
      if (!isOnline) {
        setError(labels[language].offlineShare);
        return;
      }
      setIsSharing(true);
      await onLocationShare();
      navigator.vibrate?.(100);
      setSuccess(labels[language].locationShared);
      setTimeout(() => setIsSharing(false), 2000);
    } catch (err) {
      console.error(err);
      setError(labels[language].errorSharing);
    } finally {
      setLoading(false);
    }
  };

  const handleCallContact = async (contact) => {
    if (!onCallContact || !contact) return;
    
    try {
      await onCallContact(contact);
      navigator.vibrate?.(100);
    } catch (err) {
      console.error(err);
      setError(labels[language].errorCalling);
    }
  };

  const labels = {
    en: {
      sos: "SOS",
      medical: "Medical", 
      police: "Police",
      fire: "Fire",
      share: "Share Location",
      call: "Call Contact",
      quickActions: "Quick Actions",
      errorSending: "Failed to send alert",
      errorSharing: "Failed to share location", 
      errorCalling: "Failed to initiate call",
      offlineSaved: "Alert saved for when you're back online",
      offlineShare: "Cannot share location while offline",
      alertSent: "Emergency alert sent successfully",
      locationShared: "Location shared successfully",
      search: "Search contacts...",
      loading: "Processing...",
      offline: "Offline Mode"
    },
    am: {
      sos: "SOS",
      medical: "ሕክምና",
      police: "ፖሊስ", 
      fire: "እሳት",
      share: "አካባቢን አጋራ",
      call: "እውቂያ ደውል",
      quickActions: "ፈጣን እርምጃዎች",
      errorSending: "ማንቂያ መላክ አልተሳካም",
      errorSharing: "አካባቢን ማጋራት አልተሳካም",
      errorCalling: "ጥሪ ማድረግ አልተሳካም",
      offlineSaved: "ማንቂያ ከመስመር ውጪ ተቀምጧል",
      offlineShare: "ከመስመር ውጪ አካባቢን ማጋራት አይቻልም",
      alertSent: "የአደጋ ጊዜ ማንቂያ በተሳካ ሁኔታ ተልኳል",
      locationShared: "አካባቢ በተሳካ ሁኔታ ተጋርቷል",
      search: "እውቂያዎችን ፈልግ...", 
      loading: "በመስራት ላይ...",
      offline: "ከመስመር ውጪ ሁነታ"
    }
  };

  return (
    <div 
      className="fixed bottom-8 right-8 z-50"
      role="region"
      aria-label={labels[language].quickActions}
    >
      {(error || success) && (
        <div 
          role="alert"
          className={`absolute bottom-full right-0 mb-4 p-4 rounded-lg ${
            error ? 'bg-red-500' : 'bg-green-500'
          } text-white text-sm font-medium shadow-lg transition-opacity duration-300`}
        >
          {error || success}
        </div>
      )}

      <div className={`relative ${isExpanded ? 'w-[300px]' : 'w-16'} transition-all duration-300`}>
        {isExpanded && (
          <div 
            className="absolute bottom-20 right-0 w-full space-y-3 transform-gpu transition-all duration-300 scale-100 opacity-100"
            role="menu"
          >
            {!isOnline && (
              <div className="text-amber-400 text-sm font-medium px-2 py-1 rounded-lg bg-amber-400/20 mb-2">
                <i className="fas fa-wifi-slash mr-2"></i>
                {labels[language].offline}
              </div>
            )}

            <button
              onClick={() => handleEmergency('sos')}
              disabled={loading}
              aria-label={labels[language].sos}
              className={`w-full px-6 py-4 rounded-2xl bg-gradient-to-r from-red-500 to-red-600 text-white shadow-lg hover:shadow-xl transition-all hover:scale-105 flex items-center gap-4 group relative overflow-hidden ${
                loading ? 'opacity-75 cursor-not-allowed' : ''
              }`}
              role="menuitem"
            >
              <div className="absolute inset-0 bg-white/20 transform scale-0 group-hover:scale-100 transition-transform duration-500 rounded-full origin-center"></div>
              <i className="fas fa-exclamation-triangle text-2xl"></i>
              <span>{loading ? labels[language].loading : labels[language].sos}</span>
            </button>

            <button
              onClick={() => handleEmergency('medical')}
              className="w-full px-6 py-4 rounded-2xl bg-gradient-to-r from-blue-500 to-blue-600 text-white shadow-lg hover:shadow-xl transition-all hover:scale-105 flex items-center gap-4"
            >
              <i className="fas fa-ambulance text-2xl"></i>
              <span>{labels[language].medical}</span>
            </button>

            <button
              onClick={() => handleEmergency('police')}
              className="w-full px-6 py-4 rounded-2xl bg-gradient-to-r from-indigo-500 to-indigo-600 text-white shadow-lg hover:shadow-xl transition-all hover:scale-105 flex items-center gap-4"
            >
              <i className="fas fa-shield-alt text-2xl"></i>
              <span>{labels[language].police}</span>
            </button>

            <button
              onClick={() => handleEmergency('fire')}
              className="w-full px-6 py-4 rounded-2xl bg-gradient-to-r from-orange-500 to-orange-600 text-white shadow-lg hover:shadow-xl transition-all hover:scale-105 flex items-center gap-4"
            >
              <i className="fas fa-fire text-2xl"></i>
              <span>{labels[language].fire}</span>
            </button>

            <button
              onClick={handleShareLocation}
              className={`w-full px-6 py-4 rounded-2xl bg-gradient-to-r from-purple-500 to-purple-600 text-white shadow-lg hover:shadow-xl transition-all hover:scale-105 flex items-center gap-4 ${isSharing ? 'animate-pulse' : ''}`}
            >
              <i className="fas fa-share-alt text-2xl"></i>
              <span>{labels[language].share}</span>
            </button>

            <button
              onClick={handleCallContact}
              className="w-full px-6 py-4 rounded-2xl bg-gradient-to-r from-green-500 to-green-600 text-white shadow-lg hover:shadow-xl transition-all hover:scale-105 flex items-center gap-4"
            >
              <i className="fas fa-phone-alt text-2xl"></i>
              <span>{labels[language].call}</span>
            </button>
          </div>
        )}

        <button
          onClick={() => setIsExpanded(!isExpanded)}
          aria-expanded={isExpanded}
          aria-label={isExpanded ? "Close menu" : "Open menu"}
          className={`w-16 h-16 rounded-full shadow-lg transition-all duration-300 flex items-center justify-center ${
            isExpanded
              ? 'bg-gradient-to-r from-gray-600 to-gray-700 rotate-45'
              : 'bg-gradient-to-r from-red-500 to-red-600 hover:scale-110'
          }`}
        >
          <i className={`fas ${isExpanded ? 'fa-times' : 'fa-plus'} text-2xl text-white`}></i>
        </button>
      </div>

      <style jsx global>{`
        @keyframes ripple {
          0% { transform: scale(0); opacity: 1; }
          100% { transform: scale(4); opacity: 0; }
        }
      `}</style>
    </div>
  );
}

function StoryComponent() {
  const mockContacts = [
    { id: 1, name: "Emergency Contact 1", phone: "+1234567890", isPriority: true, type: "family" },
    { id: 2, name: "Emergency Contact 2", phone: "+0987654321", isPriority: false, type: "medical" }
  ];

  const handleEmergency = async (type) => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log("Emergency:", type);
  };

  const handleLocationShare = async () => {
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log("Sharing location");
  };

  const handleCallContact = async (contact) => {
    await new Promise(resolve => setTimeout(resolve, 500));
    console.log("Calling contact:", contact);
  };

  return (
    <div className="min-h-screen bg-gray-900 p-8">
      <div className="max-w-md mx-auto space-y-8">
        <h2 className="text-2xl font-bold text-white mb-4">Emergency Quick Actions (Online)</h2>
        <MainComponent
          language="en"
          onEmergency={handleEmergency}
          onLocationShare={handleLocationShare}
          onCallContact={handleCallContact}
          contacts={mockContacts}
          isOnline={true}
        />

        <h2 className="text-2xl font-bold text-white mb-4">Emergency Quick Actions (Offline)</h2>
        <MainComponent
          language="en"
          onEmergency={handleEmergency}
          onLocationShare={handleLocationShare}
          onCallContact={handleCallContact}
          contacts={mockContacts}
          isOnline={false}
        />

        <h2 className="text-2xl font-bold text-white mb-4">Emergency Quick Actions (Amharic)</h2>
        <MainComponent
          language="am"
          onEmergency={handleEmergency}
          onLocationShare={handleLocationShare}
          onCallContact={handleCallContact}
          contacts={mockContacts}
          isOnline={true}
        />

        <h2 className="text-2xl font-bold text-white mb-4">Emergency Quick Actions (High Contrast)</h2>
        <MainComponent
          language="en"
          onEmergency={handleEmergency}
          onLocationShare={handleLocationShare}
          onCallContact={handleCallContact}
          contacts={mockContacts}
          accessibilityMode="high-contrast"
          isOnline={true}
        />
      </div>
    </div>
  );
});
}