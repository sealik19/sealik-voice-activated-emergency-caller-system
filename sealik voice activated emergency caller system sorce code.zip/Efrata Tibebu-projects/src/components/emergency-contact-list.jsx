"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({
  language = "en",
  contacts = [],
  onEdit,
  onDelete,
  onRefresh,
  loading = false,
  error = null, 
  isOnline = true
}) {
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState("priority");
  const [filterBy, setFilterBy] = useState("all");
  const [quickDialNumber, setQuickDialNumber] = useState(null);

  const translations = {
    en: {
      title: "Emergency Contacts",
      noContacts: "No emergency contacts added yet",
      primary: "Primary Contact", 
      call: "Call",
      message: "Message",
      share: "Share Location",
      edit: "Edit",
      delete: "Delete",
      search: "Search contacts...",
      sortBy: "Sort by",
      filterBy: "Filter by",
      refresh: "Refresh",
      offline: "Offline Mode",
      error: "Error loading contacts",
      retry: "Retry",
      quickDial: "Quick Dial",
      status: {
        online: "Online",
        offline: "Offline",
        busy: "Busy"
      }
    },
    am: {
      title: "የአደጋ ጊዜ ተጠሪዎች",
      noContacts: "እስካሁን የአደጋ ጊዜ ተጠሪዎች አልታከሉም",
      primary: "ዋና ተጠሪ",
      call: "ይደውሉ",
      message: "መልእክት", 
      share: "አካባቢዎን ያጋሩ",
      edit: "ያስተካክሉ",
      delete: "ይሰርዙ",
      search: "ተጠሪዎችን ይፈልጉ...",
      sortBy: "አስተካክል በ",
      filterBy: "አጣራ በ",
      refresh: "አድስ",
      offline: "ከመስመር ውጪ ሁነታ",
      error: "ተጠሪዎችን በመጫን ላይ ስህተት",
      retry: "እንደገና ሞክር",
      quickDial: "ፈጣን ጥሪ",
      status: {
        online: "መስመር ላይ",
        offline: "ከመስመር ውጪ", 
        busy: "ባተሌ"
      }
    }
  };

  const t = translations[language];

  const handleCall = useCallback((phone) => {
    if (quickDialNumber) {
      clearTimeout(quickDialNumber);
    }
    window.location.href = `tel:${phone}`;
  }, [quickDialNumber]);

  const handleMessage = useCallback((phone) => {
    window.location.href = `sms:${phone}`;
  }, []);

  const handleShare = useCallback(async (contact) => {
    if (!navigator.geolocation || !navigator.share) {
      console.error("Sharing not supported");
      return;
    }

    try {
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject);
      });

      await navigator.share({
        title: "My Location",
        text: `Emergency: My current location`,
        url: `https://maps.google.com/?q=${position.coords.latitude},${position.coords.longitude}`
      });
    } catch (err) {
      console.error("Error sharing:", err); 
    }
  }, []);

  const handleQuickDial = useCallback((contact) => {
    const timer = setTimeout(() => {
      handleCall(contact.phone);
    }, 1500);
    setQuickDialNumber(timer);
    return () => clearTimeout(timer);
  }, [handleCall]);

  const sortedAndFilteredContacts = useMemo(() => {
    let filtered = [...contacts];

    if (searchQuery) {
      filtered = filtered.filter(contact => 
        contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        contact.phone.includes(searchQuery) ||
        contact.relationship?.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    if (filterBy !== "all") {
      filtered = filtered.filter(contact => contact.relationship === filterBy);
    }

    return filtered.sort((a, b) => {
      if (sortBy === "priority") {
        if (a.is_primary) return -1;
        if (b.is_primary) return 1;
      }
      return a.name.localeCompare(b.name);
    });
  }, [contacts, searchQuery, filterBy, sortBy]);

  const contactGroups = useMemo(() => 
    ["all", ...new Set(contacts.map(c => c.relationship))],
    [contacts]
  );

  if (error) {
    return (
      <div className="bg-gray-800 rounded-xl p-6 text-center">
        <p className="text-red-400 mb-4">{t.error}</p>
        <button 
          onClick={onRefresh}
          className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700"
        >
          {t.retry}
        </button>
      </div>
    );
  }

  return (
    <div className="bg-gray-800 rounded-xl p-6">
      <div className="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <h2 className="text-2xl font-bold text-white">{t.title}</h2>
        
        <div className="flex flex-wrap gap-2 items-center">
          <input
            type="text"
            placeholder={t.search}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="px-4 py-2 bg-gray-700 text-white rounded-lg border border-gray-600 focus:border-purple-500 focus:outline-none"
          />
          
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="px-4 py-2 bg-gray-700 text-white rounded-lg border border-gray-600"
          >
            <option value="priority">Priority</option>
            <option value="name">Name</option>
          </select>

          <select
            value={filterBy}
            onChange={(e) => setFilterBy(e.target.value)}
            className="px-4 py-2 bg-gray-700 text-white rounded-lg border border-gray-600"
          >
            {contactGroups.map(group => (
              <option key={group} value={group}>{group}</option>
            ))}
          </select>

          <button
            onClick={onRefresh}
            disabled={loading}
            className="p-2 text-white rounded-lg hover:bg-gray-700"
          >
            <i className={`fas fa-sync ${loading ? 'animate-spin' : ''}`}></i>
          </button>
        </div>
      </div>

      {!isOnline && (
        <div className="bg-yellow-600/20 text-yellow-200 px-4 py-2 rounded-lg mb-4">
          {t.offline}
        </div>
      )}

      {sortedAndFilteredContacts.length === 0 ? (
        <p className="text-gray-400 text-center py-8">{t.noContacts}</p>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {sortedAndFilteredContacts.map((contact) => (
            <div
              key={contact.id}
              className={`bg-gray-700 rounded-lg p-4 ${
                contact.is_primary ? "border-2 border-yellow-500" : ""
              }`}
            >
              <div className="flex justify-between items-start mb-3">
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-semibold text-white">
                    {contact.name}
                  </h3>
                  {contact.is_primary && (
                    <span className="text-xs bg-yellow-500 text-black px-2 py-1 rounded-full">
                      {t.primary}
                    </span>
                  )}
                  <span className={`w-2 h-2 rounded-full ${
                    contact.status === 'online' ? 'bg-green-500' :
                    contact.status === 'busy' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></span>
                </div>
                <div className="flex space-x-2">
                  <button
                    onClick={() => onEdit(contact)}
                    className="text-gray-400 hover:text-white"
                  >
                    <i className="fas fa-edit"></i>
                  </button>
                  <button
                    onClick={() => onDelete(contact.id)}
                    className="text-gray-400 hover:text-red-500"
                  >
                    <i className="fas fa-trash"></i>
                  </button>
                </div>
              </div>

              <div className="text-gray-300 space-y-1 mb-4">
                <p>{contact.phone}</p>
                {contact.address && (
                  <p className="text-sm">{contact.address}</p>
                )}
                {contact.relationship && (
                  <p className="text-sm text-gray-400">
                    {contact.relationship}
                  </p>
                )}
              </div>

              <div className="flex space-x-2">
                <button
                  onMouseDown={() => handleQuickDial(contact)}
                  onMouseUp={() => clearTimeout(quickDialNumber)}
                  className="flex-1 bg-green-600 text-white py-2 rounded-lg hover:bg-green-700 transition-colors"
                >
                  {t.call}
                </button>
                <button
                  onClick={() => handleMessage(contact.phone)}
                  className="flex-1 bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  {t.message}
                </button>
                <button
                  onClick={() => handleShare(contact)}
                  className="flex-1 bg-purple-600 text-white py-2 rounded-lg hover:bg-purple-700 transition-colors"
                >
                  {t.share}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StoryComponent() {
  const [language, setLanguage] = useState("en");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isOnline, setIsOnline] = useState(true);
  const [contacts, setContacts] = useState([
    {
      id: 1,
      name: "John Doe",
      phone: "+251911234567",
      address: "Addis Ababa, Ethiopia",
      relationship: "Family",
      is_primary: true,
      status: "online"
    },
    {
      id: 2,
      name: "Jane Smith", 
      phone: "+251922345678",
      address: "Bole, Addis Ababa",
      relationship: "Friend",
      is_primary: false,
      status: "busy"
    },
    {
      id: 3,
      name: "Dr. Michael Johnson",
      phone: "+251933456789",
      relationship: "Doctor",
      is_primary: false,
      status: "offline"
    }
  ]);

  const handleEdit = (contact) => {
    console.log("Edit contact:", contact);
  };

  const handleDelete = (contactId) => {
    setContacts(contacts.filter(c => c.id !== contactId));
  };

  const handleRefresh = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 1000);
  };

  return (
    <div className="p-8 bg-gray-900 min-h-screen space-y-8">
      <div className="flex justify-end gap-4">
        <button
          onClick={() => setIsOnline(!isOnline)}
          className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600"
        >
          Toggle Online Status
        </button>
        <button
          onClick={() => setError(error ? null : "Sample error")}
          className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600"
        >
          Toggle Error
        </button>
        <button
          onClick={() => setLanguage(language === "en" ? "am" : "en")}
          className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600"
        >
          {language === "en" ? "Switch to Amharic" : "Switch to English"}
        </button>
      </div>

      <div className="max-w-4xl mx-auto">
        <MainComponent
          language={language}
          contacts={contacts}
          onEdit={handleEdit}
          onDelete={handleDelete}
          onRefresh={handleRefresh}
          loading={loading}
          error={error}
          isOnline={isOnline}
        />
      </div>

      <div className="max-w-4xl mx-auto">
        <MainComponent
          language={language}
          contacts={[]}
          onEdit={handleEdit}
          onDelete={handleDelete}
          onRefresh={handleRefresh}
          loading={loading}
          error={null}
          isOnline={isOnline}
        />
      </div>
    </div>
  );
});
}