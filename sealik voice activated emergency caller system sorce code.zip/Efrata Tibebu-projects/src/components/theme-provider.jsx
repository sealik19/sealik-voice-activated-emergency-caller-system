"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({ children, initialTheme }) {
  const [theme, setTheme] = useState(initialTheme || "system");
  const [systemTheme, setSystemTheme] = useState("light");

  useEffect(() => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme) {
      setTheme(savedTheme);
    }

    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
    const handleChange = (e) => setSystemTheme(e.matches ? "dark" : "light");

    handleChange(mediaQuery);
    mediaQuery.addEventListener("change", handleChange);

    return () => mediaQuery.removeEventListener("change", handleChange);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    const effectiveTheme = theme === "system" ? systemTheme : theme;

    if (effectiveTheme === "dark") {
      root.style.setProperty("--color-bg-primary", "#1a1a1a");
      root.style.setProperty("--color-bg-secondary", "#2d2d2d");
      root.style.setProperty("--color-text-primary", "#ffffff");
      root.style.setProperty("--color-text-secondary", "#e0e0e0");
      root.style.setProperty("--color-border", "#404040");
      root.style.setProperty("--color-accent", "#3b82f6");
      root.style.setProperty("--color-accent-hover", "#2563eb");
      root.style.setProperty("--color-success", "#22c55e");
      root.style.setProperty("--color-error", "#ef4444");
      root.style.setProperty("--color-warning", "#f59e0b");
    } else {
      root.style.setProperty("--color-bg-primary", "#ffffff");
      root.style.setProperty("--color-bg-secondary", "#f3f4f6");
      root.style.setProperty("--color-text-primary", "#111827");
      root.style.setProperty("--color-text-secondary", "#4b5563");
      root.style.setProperty("--color-border", "#e5e7eb");
      root.style.setProperty("--color-accent", "#2563eb");
      root.style.setProperty("--color-accent-hover", "#1d4ed8");
      root.style.setProperty("--color-success", "#16a34a");
      root.style.setProperty("--color-error", "#dc2626");
      root.style.setProperty("--color-warning", "#d97706");
    }

    localStorage.setItem("theme", theme);
  }, [theme, systemTheme]);

  const toggleTheme = useCallback(() => {
    setTheme((current) => {
      if (current === "light") return "dark";
      if (current === "dark") return "system";
      return "light";
    });
  }, []);

  const value = {
    theme,
    effectiveTheme: theme === "system" ? systemTheme : theme,
    toggleTheme,
  };

  return (
    <div className={`theme-${theme === "system" ? systemTheme : theme}`}>
      {children}
    </div>
  );
}

function StoryComponent() {
  return (
    <div className="p-8 space-y-8">
      <div>
        <h2 className="text-2xl font-bold mb-4">Light Theme</h2>
        <MainComponent initialTheme="light">
          <div className="p-6 bg-[var(--color-bg-secondary)] rounded-lg">
            <h3 className="text-[var(--color-text-primary)] text-xl font-bold mb-2">
              Sample Content
            </h3>
            <p className="text-[var(--color-text-secondary)]">
              This is how content looks in light mode.
            </p>
            <button className="mt-4 bg-[var(--color-accent)] hover:bg-[var(--color-accent-hover)] text-white px-4 py-2 rounded">
              Sample Button
            </button>
          </div>
        </MainComponent>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">Dark Theme</h2>
        <MainComponent initialTheme="dark">
          <div className="p-6 bg-[var(--color-bg-secondary)] rounded-lg">
            <h3 className="text-[var(--color-text-primary)] text-xl font-bold mb-2">
              Sample Content
            </h3>
            <p className="text-[var(--color-text-secondary)]">
              This is how content looks in dark mode.
            </p>
            <button className="mt-4 bg-[var(--color-accent)] hover:bg-[var(--color-accent-hover)] text-white px-4 py-2 rounded">
              Sample Button
            </button>
          </div>
        </MainComponent>
      </div>

      <div>
        <h2 className="text-2xl font-bold mb-4">System Theme</h2>
        <MainComponent initialTheme="system">
          <div className="p-6 bg-[var(--color-bg-secondary)] rounded-lg">
            <h3 className="text-[var(--color-text-primary)] text-xl font-bold mb-2">
              Sample Content
            </h3>
            <p className="text-[var(--color-text-secondary)]">
              This is how content looks in system mode.
            </p>
            <button className="mt-4 bg-[var(--color-accent)] hover:bg-[var(--color-accent-hover)] text-white px-4 py-2 rounded">
              Sample Button
            </button>
          </div>
        </MainComponent>
      </div>
    </div>
  );
});
}