"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";


export default function Index() {
  return (function MainComponent({
  language = "en",
  onLanguageChange,
  accessibilityMode = "standard",
  onAccessibilityModeChange,
  isAuthenticated = false,
  onLogin,
  onRegister,
  onLogout,
  onEmergency,
  onSearch,
  notifications = [],
  userName = "",
  userAvatar = "",
  isOnline = true
}) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);

  const content = {
    en: {
      nav: {
        home: "Home",
        safety: "Safety",
        health: "Health",
        resources: "Resources"
      },
      search: "Search",
      emergency: "Emergency",
      notifications: "Notifications",
      noNotifications: "No notifications",
      offline: "You're offline",
      online: "You're online",
      userMenu: {
        profile: "Profile",
        settings: "Settings",
        help: "Help",
        logout: "Logout"
      },
      login: "Login",
      register: "Register",
      accessibility: {
        standard: "Standard Mode",
        blind: "Blind Mode",
        deaf: "Deaf Mode",
      },
      quickActions: {
        contacts: "Emergency Contacts",
        tracker: "Health Tracker",
        resources: "Safety Resources"
      }
    },
    am: {
      nav: {
        home: "መነሻ",
        safety: "ደህንነት",
        health: "ጤና",
        resources: "ሀብቶች"
      },
      search: "ፈልግ",
      emergency: "አደጋ",
      notifications: "ማሳወቂያዎች",
      noNotifications: "ምንም ማሳወቂያዎች የሉም",
      offline: "ከመስመር ውጪ ነዎት",
      online: "መስመር ላይ ነዎት",
      userMenu: {
        profile: "መገለጫ",
        settings: "ቅንብሮች",
        help: "እርዳታ",
        logout: "ውጣ"
      },
      login: "ግባ",
      register: "ተመዝገብ",
      accessibility: {
        standard: "መደበኛ ሁነታ",
        blind: "የዕውር ሁነታ",
        deaf: "የመስማት ችግር ሁነታ",
      },
      quickActions: {
        contacts: "የአደጋ ጊዜ ተጠሪዎች",
        tracker: "የጤና መከታተያ",
        resources: "የደህንነት ሀብቶች"
      }
    }
  };

  const t = content[language];
  const accessibilityModes = ["standard", "blind", "deaf"];

  const handleSearch = (e) => {
    e.preventDefault();
    onSearch?.(searchQuery);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-gradient-to-r from-gray-900 via-purple-900/20 to-gray-800 border-b border-purple-500/20 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-8">
            <a href="/" className="flex items-center space-x-2">
              <img
                src="https://ucarecdn.com/17d8d49b-c56c-4af1-b41f-19579e9d34e5/-/format/auto/"
                alt="Sealik Lifesaver Logo"
                className="w-10 h-10 object-contain"
              />
              <span className="text-xl font-bold bg-gradient-to-r from-red-500 via-purple-500 to-blue-500 text-transparent bg-clip-text">
                Sealik
              </span>
            </a>

            <nav className="hidden md:flex items-center space-x-6">
              {Object.entries(t.nav).map(([key, value]) => (
                <a
                  key={key}
                  href={`/${key}`}
                  className="text-white hover:text-purple-400 transition-colors"
                >
                  {value}
                </a>
              ))}
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            <form onSubmit={handleSearch} className="hidden md:flex">
              <input
                type="search"
                placeholder={t.search}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-gray-800 text-white px-4 py-1 rounded-l-lg border-l border-y border-purple-500/20 focus:outline-none focus:border-purple-500"
              />
              <button
                type="submit"
                className="bg-gray-800 text-white px-4 py-1 rounded-r-lg border-r border-y border-purple-500/20 hover:bg-gray-700"
              >
                <i className="fas fa-search"></i>
              </button>
            </form>

            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="text-white p-2 rounded-lg hover:bg-gray-700"
              >
                <i className="fas fa-bell"></i>
                {notifications.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-xs w-5 h-5 flex items-center justify-center rounded-full">
                    {notifications.length}
                  </span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-gray-800 rounded-lg shadow-xl border border-purple-500/20">
                  <div className="p-4">
                    <h3 className="text-white font-semibold mb-2">{t.notifications}</h3>
                    {notifications.length === 0 ? (
                      <p className="text-gray-400">{t.noNotifications}</p>
                    ) : (
                      <div className="space-y-2">
                        {notifications.map((notification, index) => (
                          <div key={index} className="p-2 hover:bg-gray-700 rounded">
                            {notification}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={onEmergency}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors font-bold"
            >
              {t.emergency}
            </button>

            <div className="relative">
              <div className="flex items-center space-x-2">
                <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-green-500' : 'bg-red-500'}`}></span>
                <span className="text-sm text-gray-400 hidden md:inline">
                  {isOnline ? t.online : t.offline}
                </span>
              </div>
            </div>

            <select
              value={accessibilityMode}
              onChange={(e) => onAccessibilityModeChange?.(e.target.value)}
              className="bg-gray-800 text-white px-3 py-1 rounded-lg border border-purple-500/20 focus:border-purple-500 focus:outline-none hidden md:inline-block"
            >
              {accessibilityModes.map((mode) => (
                <option key={mode} value={mode}>
                  {t.accessibility[mode]}
                </option>
              ))}
            </select>

            <button
              onClick={() => onLanguageChange?.(language === "en" ? "am" : "en")}
              className="px-3 py-1 text-white bg-gray-800 rounded-lg hover:bg-gray-700 transition-colors border border-purple-500/20"
            >
              {language === "en" ? "አማርኛ" : "English"}
            </button>

            {isAuthenticated ? (
              <div className="relative">
                <button
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  className="flex items-center space-x-2"
                >
                  <img
                    src={userAvatar || "https://via.placeholder.com/32"}
                    alt={userName}
                    className="w-8 h-8 rounded-full"
                  />
                  <span className="text-white hidden md:inline">{userName}</span>
                </button>

                {isUserMenuOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-gray-800 rounded-lg shadow-xl border border-purple-500/20">
                    {Object.entries(t.userMenu).map(([key, value]) => (
                      <button
                        key={key}
                        onClick={() => {
                          if (key === 'logout') onLogout?.();
                          setIsUserMenuOpen(false);
                        }}
                        className="block w-full text-left px-4 py-2 text-white hover:bg-gray-700"
                      >
                        {value}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="hidden md:flex items-center space-x-2">
                <button
                  onClick={onLogin}
                  className="px-4 py-2 text-white bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors border border-purple-500/20"
                >
                  {t.login}
                </button>
                <button
                  onClick={onRegister}
                  className="px-4 py-2 text-white bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-lg transition-colors"
                >
                  {t.register}
                </button>
              </div>
            )}

            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden text-white"
            >
              <i className={`fas fa-${isMenuOpen ? 'times' : 'bars'}`}></i>
            </button>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden mt-4 space-y-4">
            <nav className="flex flex-col space-y-2">
              {Object.entries(t.nav).map(([key, value]) => (
                <a
                  key={key}
                  href={`/${key}`}
                  className="text-white hover:text-purple-400 transition-colors"
                >
                  {value}
                </a>
              ))}
            </nav>

            <form onSubmit={handleSearch} className="flex">
              <input
                type="search"
                placeholder={t.search}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-gray-800 text-white px-4 py-1 rounded-l-lg border-l border-y border-purple-500/20 focus:outline-none focus:border-purple-500"
              />
              <button
                type="submit"
                className="bg-gray-800 text-white px-4 py-1 rounded-r-lg border-r border-y border-purple-500/20 hover:bg-gray-700"
              >
                <i className="fas fa-search"></i>
              </button>
            </form>

            {!isAuthenticated && (
              <div className="flex flex-col space-y-2">
                <button
                  onClick={onLogin}
                  className="px-4 py-2 text-white bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors border border-purple-500/20"
                >
                  {t.login}
                </button>
                <button
                  onClick={onRegister}
                  className="px-4 py-2 text-white bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 rounded-lg transition-colors"
                >
                  {t.register}
                </button>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              {Object.entries(t.quickActions).map(([key, value]) => (
                <button
                  key={key}
                  onClick={() => {}}
                  className="px-4 py-2 text-white bg-gray-800 hover:bg-gray-700 rounded-lg transition-colors border border-purple-500/20"
                >
                  {value}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </header>
  );
}

function StoryComponent() {
  const [language, setLanguage] = useState("en");
  const [accessibilityMode, setAccessibilityMode] = useState("standard");
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isOnline, setIsOnline] = useState(true);

  const mockNotifications = [
    "Emergency alert in your area",
    "New safety tip available",
    "Health tracking reminder"
  ];

  return (
    <div className="p-8 bg-gray-900 min-h-screen space-y-8">
      <div className="space-y-8">
        <h2 className="text-white text-xl mb-4">Default State</h2>
        <MainComponent
          language={language}
          onLanguageChange={setLanguage}
          accessibilityMode={accessibilityMode}
          onAccessibilityModeChange={setAccessibilityMode}
          isAuthenticated={isAuthenticated}
          onLogin={() => console.log("Login clicked")}
          onRegister={() => console.log("Register clicked")}
          onLogout={() => setIsAuthenticated(false)}
          onEmergency={() => console.log("Emergency clicked")}
          onSearch={(query) => console.log("Search:", query)}
          notifications={[]}
          isOnline={isOnline}
        />
      </div>

      <div className="space-y-8 mt-20">
        <h2 className="text-white text-xl mb-4">Authenticated State</h2>
        <MainComponent
          language={language}
          onLanguageChange={setLanguage}
          accessibilityMode={accessibilityMode}
          onAccessibilityModeChange={setAccessibilityMode}
          isAuthenticated={true}
          userName="Jane Doe"
          userAvatar="https://via.placeholder.com/32"
          onLogin={() => console.log("Login clicked")}
          onRegister={() => console.log("Register clicked")}
          onLogout={() => console.log("Logout clicked")}
          onEmergency={() => console.log("Emergency clicked")}
          onSearch={(query) => console.log("Search:", query)}
          notifications={mockNotifications}
          isOnline={isOnline}
        />
      </div>

      <div className="space-y-8">
        <h2 className="text-white text-xl mb-4">Offline State</h2>
        <MainComponent
          language={language}
          onLanguageChange={setLanguage}
          accessibilityMode={accessibilityMode}
          onAccessibilityModeChange={setAccessibilityMode}
          isAuthenticated={true}
          userName="Jane Doe"
          userAvatar="https://via.placeholder.com/32"
          onLogin={() => console.log("Login clicked")}
          onRegister={() => console.log("Register clicked")}
          onLogout={() => console.log("Logout clicked")}
          onEmergency={() => console.log("Emergency clicked")}
          onSearch={(query) => console.log("Search:", query)}
          notifications={mockNotifications}
          isOnline={false}
        />
      </div>

      <div className="space-y-8">
        <h2 className="text-white text-xl mb-4">Amharic Language</h2>
        <MainComponent
          language="am"
          onLanguageChange={setLanguage}
          accessibilityMode={accessibilityMode}
          onAccessibilityModeChange={setAccessibilityMode}
          isAuthenticated={isAuthenticated}
          onLogin={() => console.log("Login clicked")}
          onRegister={() => console.log("Register clicked")}
          onLogout={() => console.log("Logout clicked")}
          onEmergency={() => console.log("Emergency clicked")}
          onSearch={(query) => console.log("Search:", query)}
          notifications={[]}
          isOnline={isOnline}
        />
      </div>
    </div>
  );
});
}