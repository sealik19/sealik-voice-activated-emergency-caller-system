"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [language, setLanguage] = useState("en");

  const content = {
    en: {
      hero: {
        title: "Sealik Lifesaver",
        subtitle: "Your Emergency Response Partner",
        description:
          "24/7 emergency assistance at your fingertips. One tap can save a life.",
        emergencyButton: "Emergency SOS",
        downloadApp: "Get the App",
      },
      emergency: {
        title: "Emergency Services",
        services: [
          {
            title: "Police",
            icon: "🚓",
            action: "Call Police",
          },
          {
            title: "Medical",
            icon: "🚑",
            action: "Medical Help",
          },
          {
            title: "Fire",
            icon: "🚒",
            action: "Fire Emergency",
          },
        ],
      },
      features: {
        title: "Safety Features",
        list: [
          {
            title: "GPS Location Tracking",
            description: "Automatic location sharing with emergency services",
          },
          {
            title: "Offline Mode",
            description: "Works without internet connection",
          },
          {
            title: "Family Circle",
            description: "Keep your loved ones informed",
          },
        ],
      },
      cta: {
        title: "Ready to Stay Safe?",
        description:
          "Download Sealik Lifesaver now and protect yourself and your loved ones",
        button: "Download Now",
      },
    },
    am: {
      hero: {
        title: "ሲሊክ ላይፍሴቨር",
        subtitle: "የእርስዎ የአደጋ ጊዜ ምላሽ አጋር",
        description: "24/7 የአደጋ ጊዜ እርዳታ በእጆዎ ውስጥ። አንድ ንክኪ ሕይወት ሊያድን ይችላል።",
        emergencyButton: "አደጋ ጊዜ SOS",
        downloadApp: "አፕሊኬሽኑን ያግኙ",
      },
      emergency: {
        title: "የአደጋ ጊዜ አገልግሎቶች",
        services: [
          {
            title: "ፖሊስ",
            icon: "🚓",
            action: "ፖሊስ ይደውሉ",
          },
          {
            title: "ሕክምና",
            icon: "🚑",
            action: "የሕክምና እርዳታ",
          },
          {
            title: "እሳት",
            icon: "🚒",
            action: "የእሳት አደጋ",
          },
        ],
      },
      features: {
        title: "የደህንነት ባህሪያት",
        list: [
          {
            title: "GPS አካባቢ መከታተል",
            description: "ራስሰር የአካባቢ ማጋራት ከአደጋ ጊዜ አገልግሎቶች ጋር",
          },
          {
            title: "ከመስመር ውጪ ሁኔታ",
            description: "ያለ ኢንተርነት ግንኙነት ይሰራል",
          },
          {
            title: "የቤተሰብ ክብ",
            description: "ተወዳጆችዎን በመረጃ ይጠብቁ",
          },
        ],
      },
      cta: {
        title: "ለመጠበቅ ዝግጁ ነዎት?",
        description: "አሁኑኑ ሲሊክ ላይፍሴቨርን ያውርዱ እና እራስዎን እና ወዳጆችዎን ይጠብቁ",
        button: "አሁን ያውርዱ",
      },
    },
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="text-center mb-16">
          <h1 className="text-6xl md:text-7xl font-bold text-white mb-4">
            {content[language].hero.title}
          </h1>
          <p className="text-2xl text-gray-300 mb-8">
            {content[language].hero.subtitle}
          </p>
          <p className="text-xl text-gray-400 mb-12">
            {content[language].hero.description}
          </p>
          <div className="flex flex-col md:flex-row justify-center gap-6">
            <button className="bg-red-600 hover:bg-red-700 text-white text-xl px-8 py-4 rounded-xl transform transition-transform hover:scale-105">
              {content[language].hero.emergencyButton}
            </button>
            <button className="bg-gray-700 hover:bg-gray-600 text-white text-xl px-8 py-4 rounded-xl transform transition-transform hover:scale-105">
              {content[language].hero.downloadApp}
            </button>
          </div>
        </div>
        <div className="bg-gray-800 rounded-xl p-8 mb-12">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">
            {content[language].emergency.title}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {content[language].emergency.services.map((service, index) => (
              <button
                key={index}
                className="bg-gray-700 hover:bg-gray-600 rounded-xl p-8 text-center transform transition-transform hover:scale-105"
              >
                <div className="text-5xl mb-4">{service.icon}</div>
                <h3 className="text-xl font-bold text-white mb-2">
                  {service.title}
                </h3>
                <p className="text-gray-300">{service.action}</p>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-8 mb-12">
          <h2 className="text-3xl font-bold text-white mb-8 text-center">
            {content[language].features.title}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {content[language].features.list.map((feature, index) => (
              <div
                key={index}
                className="bg-gray-700 rounded-xl p-6 hover:bg-gray-600 transition-colors"
              >
                <h3 className="text-xl font-bold text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-300">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-8 mb-12">
          <div className="text-center">
            <h2 className="text-4xl font-bold text-white mb-4">
              {content[language].cta.title}
            </h2>
            <p className="text-xl text-gray-300 mb-8">
              {content[language].cta.description}
            </p>
            <button className="bg-green-600 hover:bg-green-700 text-white text-xl px-8 py-4 rounded-xl transform transition-transform hover:scale-105">
              {content[language].cta.button}
            </button>
          </div>
        </div>
        <div className="fixed bottom-8 right-8">
          <button
            onClick={() => setLanguage((lang) => (lang === "en" ? "am" : "en"))}
            className="bg-gray-700 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors"
          >
            {language === "en" ? "አማርኛ" : "English"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;