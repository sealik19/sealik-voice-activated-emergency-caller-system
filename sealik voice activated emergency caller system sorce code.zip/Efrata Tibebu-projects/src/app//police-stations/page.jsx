"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [language, setLanguage] = useState("en");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [location, setLocation] = useState(null);
  const [mapCenter, setMapCenter] = useState({ lat: 9.032, lng: 38.752 });
  const [stations, setStations] = useState([]);
  const [selectedStation, setSelectedStation] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [pricing, setPricing] = useState(null);
  const [pricingError, setPricingError] = useState(false);

  const translations = {
    en: {
      title: "Nearby Police Stations",
      subtitle: "Find and contact the closest police stations to your location",
      search: "Search police stations...",
      loading: "Loading police stations...",
      error: "Could not load police stations",
      noResults: "No police stations found",
      distance: "Distance",
      contact: "Contact",
      directions: "Get Directions",
      switchLanguage: "አማርኛ",
      call: "Call Station",
      back: "Back to Emergency System",
      kmAway: "km away",
      save: "Save",
      monthlyPrice: "That's only",
    },
    am: {
      title: "አቅራቢያ ያሉ የፖሊስ ጣቢያዎች",
      subtitle: "ለእርስዎ ቅርብ የሆኑ የፖሊስ ጣቢያዎችን ያግኙ እና ያግኙዋቸው",
      search: "የፖሊስ ጣቢያዎችን ይፈልጉ...",
      loading: "የፖሊስ ጣቢያዎችን በመጫን ላይ...",
      error: "የፖሊስ ጣቢያዎችን መጫን አልተቻለም",
      noResults: "ምንም የፖሊስ ጣቢያዎች አልተገኙም",
      distance: "ርቀት",
      contact: "አግኙ",
      directions: "አቅጣጫ ያግኙ",
      switchLanguage: "English",
      call: "ጣቢያውን ይደውሉ",
      back: "ወደ የአደጋ ጊዜ ስርዓት ተመለስ",
      kmAway: "ኪሎ ሜትር ርቀት",
      save: "ቁጠባ",
      monthlyPrice: "በወር ብቻ",
    },
  };

  const t = translations[language];

  useEffect(() => {
    const getLocation = () => {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const newLocation = {
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
            };
            setLocation(newLocation);
            setMapCenter({
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            });
            fetchPoliceStations(newLocation);
          },
          (error) => {
            console.error("Error getting location:", error);
            setError(t.error);
            setLoading(false);
          }
        );
      } else {
        setError(t.error);
        setLoading(false);
      }
    };
    getLocation();
  }, [language]);

  useEffect(() => {
    fetchSubscriptionPricing();
  }, [language]);

  const fetchSubscriptionPricing = async () => {
    try {
      const response = await fetch("/api/calculate-subscription-price", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subscriptionType: "yearly" }),
      });

      if (!response.ok) {
        throw new Error("Failed to fetch pricing");
      }

      const data = await response.json();
      setPricing(data);
    } catch (err) {
      console.error("Error fetching pricing:", err);
      setPricingError(true);
    }
  };

  const fetchPoliceStations = async (userLocation) => {
    try {
      const response = await fetch("/api/list-police-stations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          latitude: userLocation.latitude,
          longitude: userLocation.longitude,
        }),
      });

      if (!response.ok) {
        throw new Error(t.error);
      }

      const data = await response.json();
      setStations(data.stations || []);
    } catch (err) {
      console.error("Error fetching police stations:", err);
      setError(t.error);
      setStations([]);
    } finally {
      setLoading(false);
    }
  };
  const filteredStations =
    stations?.filter((station) =>
      station?.name?.toLowerCase().includes(searchQuery.toLowerCase())
    ) || [];

  return (
    <div className="min-h-screen bg-[var(--color-bg-primary)]">
      <header className="fixed w-full z-50 bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <a
                href="/"
                className="flex items-center text-white hover:text-gray-300 transition-colors"
              >
                <svg
                  className="w-6 h-6 mr-2"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10 19l-7-7m0 0l7-7m-7 7h18"
                  />
                </svg>
                {t.back}
              </a>
            </div>
            <button
              onClick={() => setLanguage(language === "en" ? "am" : "en")}
              className="px-4 py-2 rounded-lg bg-gray-700 text-white hover:bg-gray-600 transition-colors"
            >
              {t.switchLanguage}
            </button>
          </div>
        </div>
      </header>

      <main className="pt-20 px-4 pb-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-[var(--color-text-primary)] mb-4">
              {t.title}
            </h1>
            <p className="text-xl text-[var(--color-text-secondary)]">
              {t.subtitle}
            </p>
          </div>
          <div className="mb-6">
            <input
              type="text"
              name="search"
              placeholder={t.search}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full p-4 rounded-lg bg-[var(--color-bg-secondary)] text-[var(--color-text-primary)] border border-[var(--color-border)]"
            />
          </div>

          <div className="mb-8 p-6 bg-[var(--color-bg-secondary)] rounded-lg">
            <div className="text-center">
              <div className="relative inline-block">
                <span className="text-2xl text-[var(--color-text-secondary)] line-through">
                  {pricing?.display?.original}
                </span>
                <div className="absolute -top-4 -right-16 bg-[var(--color-success)] text-white px-2 py-1 rounded-full text-sm">
                  {t.save} {Math.round(pricing?.savings?.percentage)}%
                </div>
              </div>
              <div className="mt-2">
                <span className="text-4xl font-bold text-[var(--color-text-primary)]">
                  {pricing?.display?.final}
                </span>
              </div>
              <p className="mt-2 text-[var(--color-text-secondary)]">
                {t.monthlyPrice} {pricing?.display?.perMonth}
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="h-[600px] bg-[var(--color-bg-secondary)] rounded-lg overflow-hidden">
              <></>
            </div>

            <div className="space-y-4 h-[600px] overflow-y-auto">
              {loading ? (
                <div className="text-center py-8 text-[var(--color-text-secondary)]">
                  {t.loading}
                </div>
              ) : error ? (
                <div className="text-center py-8 text-[var(--color-error)]">
                  {error}
                </div>
              ) : filteredStations.length === 0 ? (
                <div className="text-center py-8 text-[var(--color-text-secondary)]">
                  {t.noResults}
                </div>
              ) : (
                filteredStations.map((station) => (
                  <div
                    key={station.id}
                    className="p-4 bg-[var(--color-bg-secondary)] rounded-lg hover:bg-opacity-80 transition-colors cursor-pointer"
                    onClick={() => {
                      setSelectedStation(station);
                      setMapCenter({
                        lat: station.latitude,
                        lng: station.longitude,
                      });
                    }}
                  >
                    <h3 className="text-lg font-bold text-[var(--color-text-primary)]">
                      {station.name}
                    </h3>
                    <p className="text-[var(--color-text-secondary)] mb-2">
                      {station.address}
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <a
                        href={`tel:${station.phone}`}
                        className="inline-flex items-center px-3 py-1 rounded-full bg-[var(--color-accent)] text-white hover:bg-[var(--color-accent-hover)] transition-colors"
                      >
                        <span className="mr-1">📞</span> {t.call}
                      </a>
                      <a
                        href={`https://www.google.com/maps/dir/?api=1&destination=${station.latitude},${station.longitude}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center px-3 py-1 rounded-full bg-[var(--color-success)] text-white hover:bg-opacity-80 transition-colors"
                      >
                        <span className="mr-1">🗺️</span> {t.directions}
                      </a>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default MainComponent;