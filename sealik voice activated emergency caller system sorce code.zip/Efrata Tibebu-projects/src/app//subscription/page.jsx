"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [billingType, setBillingType] = useState("monthly");
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [language, setLanguage] = useState("en");

  useEffect(() => {
    fetchPlans();
  }, []);

  const fetchPlans = async () => {
    try {
      const response = await fetch("/api/list-subscription-plans", {
        method: "POST",
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error);
      setPlans(data.plans);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  const translations = {
    en: {
      title: "Choose Your Sealik Plan",
      subtitle: "Get premium safety features for you and your loved ones",
      monthly: "Monthly",
      yearly: "Yearly",
      save: "Save 25%",
      currency: "ETB",
      subscribe: "Subscribe Now",
      loading: "Loading plans...",
      yearlyPrice: "/year",
      monthlyPrice: "/month",
      switchLanguage: "አማርኛ",
      error: "Something went wrong. Please try again.",
      back: "Back",
    },
    am: {
      title: "የሲሊክ እቅድዎን ይምረጡ",
      subtitle: "ለእርስዎ እና ለሚወዷቸው ሰዎች 프ሪሚየም የደህንነት ዋስትናዎችን ያግኙ",
      monthly: "ወርሃዊ",
      yearly: "ዓመታዊ",
      save: "25% ይቆጥባሉ",
      currency: "ብር",
      subscribe: "ቀጥል",
      loading: "እቅዶችን በመጫን ላይ...",
      yearlyPrice: "/በዓመት",
      monthlyPrice: "/በወር",
      switchLanguage: "English",
      error: "ችግር ተፈጥሯል። እባክዎ እንደገና ይሞክሩ።",
      back: "ተመለስ",
    },
  };
  const t = translations[language];
  const handleSubscribe = async (planId) => {
    try {
      const response = await fetch("/api/create-subscription", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          plan_id: planId,
          subscription_type: billingType,
          user_id: 1,
        }),
      });
      const data = await response.json();
      if (data.error) throw new Error(data.error);
      window.location.href = "/";
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => window.history.back()}
            className="flex items-center text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition duration-200"
          >
            <svg
              className="w-5 h-5 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 19l-7-7m0 0l7-7m-7 7h18"
              />
            </svg>
            {t.back}
          </button>
          <button
            onClick={() => setLanguage(language === "en" ? "am" : "en")}
            className="px-4 py-2 rounded-md bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700 transition duration-200"
          >
            {t.switchLanguage}
          </button>
        </div>

        <div className="text-center">
          <button
            onClick={() => setLanguage(language === "en" ? "am" : "en")}
            className="mb-8 px-4 py-2 rounded-md bg-gray-100 dark:bg-gray-800 text-gray-900 dark:text-white hover:bg-gray-200 dark:hover:bg-gray-700 transition duration-200"
          >
            {t.switchLanguage}
          </button>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4 font-inter">
            {t.title}
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 font-inter">
            {t.subtitle}
          </p>

          {error && (
            <div className="mb-8 bg-red-100 dark:bg-red-900 text-red-700 dark:text-red-100 p-4 rounded-lg">
              {t.error}
            </div>
          )}

          <div className="flex justify-center mb-8">
            <div className="bg-white dark:bg-gray-800 rounded-lg p-1 flex shadow-md">
              <button
                onClick={() => setBillingType("monthly")}
                className={`px-4 py-2 rounded-md transition duration-200 ${
                  billingType === "monthly"
                    ? "bg-blue-500 text-white"
                    : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}
              >
                {t.monthly}
              </button>
              <button
                onClick={() => setBillingType("yearly")}
                className={`px-4 py-2 rounded-md flex items-center transition duration-200 ${
                  billingType === "yearly"
                    ? "bg-blue-500 text-white"
                    : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}
              >
                {t.yearly}
                <span className="ml-2 bg-green-100 text-green-800 text-xs font-medium px-2 py-1 rounded">
                  {t.save}
                </span>
              </button>
            </div>
          </div>

          {loading ? (
            <p className="text-gray-600 dark:text-gray-300 font-inter">
              {t.loading}
            </p>
          ) : (
            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 max-w-7xl mx-auto">
              {plans.map((plan) => (
                <div
                  key={plan.id}
                  className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-8 transform hover:scale-105 transition duration-200"
                >
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4 font-inter">
                    {language === "en" ? plan.name_en : plan.name_am}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6 font-inter">
                    {language === "en"
                      ? plan.description_en
                      : plan.description_am}
                  </p>
                  <p className="text-4xl font-bold text-gray-900 dark:text-white mb-6 font-inter">
                    {billingType === "monthly" ? (
                      <>
                        {plan.price_monthly} {t.currency}
                        <span className="text-xl font-normal text-gray-600 dark:text-gray-300">
                          {t.monthlyPrice}
                        </span>
                      </>
                    ) : (
                      <>
                        {plan.price_yearly} {t.currency}
                        <span className="text-xl font-normal text-gray-600 dark:text-gray-300">
                          {t.yearlyPrice}
                        </span>
                      </>
                    )}
                  </p>
                  <button
                    onClick={() => handleSubscribe(plan.id)}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg transition duration-200"
                  >
                    {t.subscribe}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;