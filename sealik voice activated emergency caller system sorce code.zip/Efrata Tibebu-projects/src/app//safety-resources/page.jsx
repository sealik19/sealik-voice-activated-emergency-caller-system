"use client";
import React from "react";
import BackButton from "../../components/back-button";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [language, setLanguage] = useState("en");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const content = {
    en: {
      title: "Safety Resources & Emergency Preparedness",
      subtitle: "Access vital safety information and emergency guides",
      categories: {
        all: "All Resources",
        emergency: "Emergency Preparedness",
        medical: "Medical Safety",
        natural: "Natural Disasters",
        personal: "Personal Safety",
        home: "Home Safety",
      },
      search: "Search resources...",
      downloadButton: "Download PDF",
      readMore: "Read More",
      switchLanguage: "አማርኛ",
    },
    am: {
      title: "የደህንነት መረጃዎች እና የአደጋ ዝግጁነት",
      subtitle: "አስፈላጊ የደህንነት መረጃዎችን እና የአደጋ መመሪያዎችን ያግኙ",
      categories: {
        all: "ሁሉም መረጃዎች",
        emergency: "የአደጋ ዝግጁነት",
        medical: "የሕክምና ደህንነት",
        natural: "የተፈጥሮ አደጋዎች",
        personal: "የግል ደህንነት",
        home: "የቤት ደህንነት",
      },
      search: "መረጃዎችን ይፈልጉ...",
      downloadButton: "PDF ያውርዱ",
      readMore: "ተጨማሪ ያንብቡ",
      switchLanguage: "English",
    },
  };

  const resources = {
    emergency: [
      {
        id: 1,
        title: {
          en: "Emergency Kit Checklist",
          am: "የአደጋ ጊዜ መሳሪያዎች ዝርዝር",
        },
        description: {
          en: "Essential items to include in your emergency preparedness kit",
          am: "በእርስዎ የአደጋ ዝግጁነት እቃዎች ውስጥ መካተት ያለባቸው አስፈላጊ ነገሮች",
        },
        icon: "🎒",
        pdfUrl: "/resources/emergency-kit-checklist.pdf",
      },
      {
        id: 2,
        title: {
          en: "Family Emergency Plan Template",
          am: "የቤተሰብ አደጋ ዕቅድ ቅጽ",
        },
        description: {
          en: "Create a comprehensive emergency plan for your family",
          am: "ለቤተሰብዎ ሁሉን አקፍ የአደጋ ዕቅድ ይፍጠሩ",
        },
        icon: "👨‍👩‍👧‍👦",
        pdfUrl: "/resources/family-emergency-plan.pdf",
      },
    ],
    medical: [
      {
        id: 3,
        title: {
          en: "First Aid Guide",
          am: "የመጀመሪያ እርዳታ መመሪያ",
        },
        description: {
          en: "Basic first aid procedures for common emergencies",
          am: "ለተለመዱ አደጋዎች መሰረታዊ የመጀመሪያ እርዳታ ሂደቶች",
        },
        icon: "⚕️",
        pdfUrl: "/resources/first-aid-guide.pdf",
      },
    ],
    natural: [
      {
        id: 4,
        title: {
          en: "Earthquake Safety Protocol",
          am: "የመሬት መንቀጥቀጥ ደህንነት ፕሮቶኮል",
        },
        description: {
          en: "What to do before, during, and after an earthquake",
          am: "በመሬት መንቀጥቀጥ ወቅት፣ በፊት እና በኋላ ምን ማድረግ እንዳለብዎት",
        },
        icon: "🏚️",
        pdfUrl: "/resources/earthquake-safety.pdf",
      },
    ],
    personal: [
      {
        id: 5,
        title: {
          en: "Personal Safety Guidelines",
          am: "የግል ደህንነት መመሪያዎች",
        },
        description: {
          en: "Tips for staying safe in various personal situations",
          am: "በተለያዩ የግል ሁኔታዎች ደህንነትዎን ለመጠበቅ ምክሮች",
        },
        icon: "🛡️",
        pdfUrl: "/resources/personal-safety.pdf",
      },
    ],
    home: [
      {
        id: 6,
        title: {
          en: "Home Safety Checklist",
          am: "የቤት ደህንነት ማረጋገጫ ዝርዝር",
        },
        description: {
          en: "Essential safety measures for your home",
          am: "ለቤትዎ አስፈላጊ የሆኑ የደህንነት እርምጃዎች",
        },
        icon: "🏠",
        pdfUrl: "/resources/home-safety.pdf",
      },
    ],
  };

  const filteredResources = useMemo(() => {
    let filtered = [];
    if (selectedCategory === "all") {
      filtered = Object.values(resources).flat();
    } else {
      filtered = resources[selectedCategory] || [];
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (resource) =>
          resource.title[language].toLowerCase().includes(query) ||
          resource.description[language].toLowerCase().includes(query)
      );
    }

    return filtered;
  }, [selectedCategory, searchQuery, language]);

  const handleDownload = async (pdfUrl, title) => {
    setLoading(true);
    try {
      const response = await fetch(pdfUrl);
      if (!response.ok) throw new Error("Failed to download resource");

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${title}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      setError("Could not download the resource. Please try again later.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleBack = () => {
    window.history.back();
  };

  return (
    <div className="min-h-screen bg-[var(--color-bg-primary)]">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-6">
          <BackButton onClick={handleBack} language={language} />
        </div>

        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-[var(--color-text-primary)] mb-2">
              {content[language].title}
            </h1>
            <p className="text-[var(--color-text-secondary)] text-xl">
              {content[language].subtitle}
            </p>
          </div>
          <button
            onClick={() => setLanguage(language === "en" ? "am" : "en")}
            className="px-4 py-2 bg-[var(--color-accent)] text-white rounded-lg hover:bg-[var(--color-accent-hover)] transition duration-200"
          >
            {content[language].switchLanguage}
          </button>
        </div>
        <div className="mb-8">
          <input
            type="text"
            placeholder={content[language].search}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full p-4 rounded-lg bg-[var(--color-bg-secondary)] text-[var(--color-text-primary)] border border-[var(--color-border)]"
          />
        </div>
        <div className="flex flex-wrap gap-2 mb-8">
          {Object.entries(content[language].categories).map(([key, value]) => (
            <button
              key={key}
              onClick={() => setSelectedCategory(key)}
              className={`px-4 py-2 rounded-lg transition duration-200 ${
                selectedCategory === key
                  ? "bg-[var(--color-accent)] text-white"
                  : "bg-[var(--color-bg-secondary)] text-[var(--color-text-primary)] hover:bg-[var(--color-border)]"
              }`}
            >
              {value}
            </button>
          ))}
        </div>

        {error && (
          <div className="bg-[var(--color-error)] text-white p-4 rounded-lg mb-8">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredResources.map((resource) => (
            <div
              key={resource.id}
              className="bg-[var(--color-bg-secondary)] rounded-xl p-6 shadow-lg hover:shadow-xl transition duration-200"
            >
              <div className="text-4xl mb-4">{resource.icon}</div>
              <h3 className="text-xl font-bold text-[var(--color-text-primary)] mb-2">
                {resource.title[language]}
              </h3>
              <p className="text-[var(--color-text-secondary)] mb-4">
                {resource.description[language]}
              </p>
              <button
                onClick={() =>
                  handleDownload(resource.pdfUrl, resource.title[language])
                }
                disabled={loading}
                className="w-full bg-[var(--color-accent)] text-white py-2 px-4 rounded-lg hover:bg-[var(--color-accent-hover)] transition duration-200 flex items-center justify-center gap-2"
              >
                {loading ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  <>
                    <span>📥</span>
                    {content[language].downloadButton}
                  </>
                )}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;