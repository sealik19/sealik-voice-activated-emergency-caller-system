"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedFilter, setSelectedFilter] = useState("all");
  const [safetyScore, setSafetyScore] = useState(85);
  const [weatherAlert, setWeatherAlert] = useState({
    type: "clear",
    message: "Clear skies",
  });
  const [recentAlerts] = useState([
    {
      id: 1,
      type: "medical",
      message: "Medical assistance requested",
      time: "2 hours ago",
    },
    {
      id: 2,
      type: "security",
      message: "Suspicious activity reported",
      time: "5 hours ago",
    },
  ]);

  const [emergencyContacts] = useState([
    { id: 1, name: "Police", number: "911", status: "active" },
    { id: 2, name: "Ambulance", number: "112", status: "active" },
    { id: 3, name: "Fire Department", number: "101", status: "active" },
  ]);

  const [healthMetrics] = useState({
    lastCheck: "2025-01-15",
    status: "Good",
    nextAppointment: "2025-02-01",
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1a1a2e] to-[#0f0f1a] text-white p-6">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-crimson-text">Safety Dashboard</h1>
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-white/10 backdrop-blur-lg rounded-xl px-6 py-3 w-[300px] focus:outline-none border border-purple-500/20"
              placeholder="Search dashboard..."
            />
            <i className="fas fa-search absolute right-4 top-1/2 transform -translate-y-1/2 text-purple-400"></i>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-2 space-y-6">
            <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-crimson-text">Safety Score</h2>
                <div className="text-3xl font-bold text-purple-400">
                  {safetyScore}%
                </div>
              </div>
              <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-purple-500 to-blue-500 rounded-full transition-all duration-1000"
                  style={{ width: `${safetyScore}%` }}
                ></div>
              </div>
            </div>

            <EmergencyQuickActions
              onEmergency={(type) => console.log("Emergency:", type)}
              onLocationShare={() => console.log("Location shared")}
              onCallContact={(contact) => console.log("Calling:", contact)}
              contacts={emergencyContacts}
            />

            <SafetyMap
              currentLocation={{ lat: 9.032, lng: 38.752 }}
              onSelectLocation={(location) =>
                console.log("Selected:", location)
              }
            />

            <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
              <h2 className="text-xl font-crimson-text mb-4">Recent Alerts</h2>
              <div className="space-y-4">
                {recentAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="flex items-center gap-4 p-4 bg-white/5 rounded-xl"
                  >
                    <i
                      className={`fas fa-${
                        alert.type === "medical" ? "ambulance" : "shield-alt"
                      } text-purple-400`}
                    ></i>
                    <div>
                      <div className="font-semibold">{alert.message}</div>
                      <div className="text-sm text-gray-400">{alert.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
              <h2 className="text-xl font-crimson-text mb-4">Weather Alert</h2>
              <div className="flex items-center gap-4">
                <i className="fas fa-sun text-2xl text-yellow-400"></i>
                <div>{weatherAlert.message}</div>
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
              <h2 className="text-xl font-crimson-text mb-4">
                Health Tracking
              </h2>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Last Check</span>
                  <span>{healthMetrics.lastCheck}</span>
                </div>
                <div className="flex justify-between">
                  <span>Status</span>
                  <span className="text-green-400">{healthMetrics.status}</span>
                </div>
                <div className="flex justify-between">
                  <span>Next Appointment</span>
                  <span>{healthMetrics.nextAppointment}</span>
                </div>
              </div>
            </div>

            <div className="bg-white/5 backdrop-blur-lg rounded-2xl p-6 border border-purple-500/20">
              <h2 className="text-xl font-crimson-text mb-4">
                Emergency Contacts
              </h2>
              <div className="space-y-3">
                {emergencyContacts.map((contact) => (
                  <div
                    key={contact.id}
                    className="flex items-center justify-between p-3 bg-white/5 rounded-xl"
                  >
                    <div className="flex items-center gap-3">
                      <i className="fas fa-phone-alt text-purple-400"></i>
                      <div>
                        <div className="font-semibold">{contact.name}</div>
                        <div className="text-sm text-gray-400">
                          {contact.number}
                        </div>
                      </div>
                    </div>
                    <div
                      className={`w-2 h-2 rounded-full ${
                        contact.status === "active"
                          ? "bg-green-400"
                          : "bg-red-400"
                      }`}
                    ></div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <style jsx global>{`
        @keyframes pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }
      `}</style>
    </div>
  );
}

export default MainComponent;