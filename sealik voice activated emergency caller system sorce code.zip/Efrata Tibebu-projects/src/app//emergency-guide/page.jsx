"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [language, setLanguage] = useState("en");
  const [selectedCategory, setSelectedCategory] = useState("general");
  const [searchQuery, setSearchQuery] = useState("");

  const emergencyGuides = {
    en: {
      title: "Emergency Safety Guide",
      subtitle: "Quick access to life-saving information",
      search: "Search guides...",
      categories: {
        general: "General Safety",
        medical: "Medical Emergencies",
        natural: "Natural Disasters",
        security: "Security Threats",
        fire: "Fire Safety",
        firstAid: "First Aid",
      },
      guides: {
        general: [
          {
            title: "Basic Emergency Kit",
            icon: "🎒",
            steps: [
              "Store 3 days worth of non-perishable food",
              "Keep 3 gallons of water per person",
              "Include first aid supplies",
              "Pack flashlights and batteries",
              "Store important documents",
            ],
          },
          {
            title: "Emergency Contact List",
            icon: "📞",
            steps: [
              "Save local emergency numbers",
              "Add family emergency contacts",
              "Include nearby hospital numbers",
              "List emergency meeting points",
              "Keep physical copies handy",
            ],
          },
        ],
        medical: [
          {
            title: "Heart Attack Response",
            icon: "❤️",
            steps: [
              "Call emergency services immediately",
              "Help person sit or lie down",
              "Loosen tight clothing",
              "Monitor breathing",
              "Be prepared for CPR if needed",
            ],
          },
          {
            title: "Severe Bleeding",
            icon: "🩹",
            steps: [
              "Apply direct pressure to wound",
              "Use clean cloth or gauze",
              "Elevate injured area if possible",
              "Keep pressure until help arrives",
              "Monitor for shock symptoms",
            ],
          },
        ],
        natural: [
          {
            title: "Earthquake Safety",
            icon: "🏃",
            steps: [
              "Drop, Cover, and Hold On",
              "Stay away from windows",
              "If inside, stay inside",
              "If outside, move to open area",
              "Be prepared for aftershocks",
            ],
          },
          {
            title: "Flood Response",
            icon: "🌊",
            steps: [
              "Move to higher ground",
              "Avoid walking in moving water",
              "Don't drive in flood areas",
              "Listen to emergency broadcasts",
              "Follow evacuation orders",
            ],
          },
        ],
      },
    },
    am: {
      title: "የአደጋ ጊዜ ደህንነት መመሪያ",
      subtitle: "ሕይወት አድን መረጃ በቀላሉ ያግኙ",
      search: "መመሪያዎችን ይፈልጉ...",
      categories: {
        general: "አጠቃላይ ደህንነት",
        medical: "የሕክምና አደጋዎች",
        natural: "የተፈጥሮ አደጋዎች",
        security: "የደህንነት ስጋቶች",
        fire: "የእሳት ደህንነት",
        firstAid: "የመጀመሪያ እርዳታ",
      },
      guides: {
        general: [
          {
            title: "መሰረታዊ የአደጋ ጊዜ ዕቃዎች",
            icon: "🎒",
            steps: [
              "ለ3 ቀናት የሚበቃ ምግብ ያስቀምጡ",
              "ለአንድ ሰው 3 ጋሎን ውሃ ያዘጋጁ",
              "የመጀመሪያ እርዳታ እቃዎችን ያካትቱ",
              "ባትሪዎችን እና ባትሪዎችን ያዘጋጁ",
              "አስፈላጊ ሰነዶችን ያስቀምጡ",
            ],
          },
          {
            title: "የአደጋ ጊዜ አድራሻዎች",
            icon: "📞",
            steps: [
              "የአካባቢ የአደጋ ጊዜ ቁጥሮችን ያስቀምጡ",
              "የቤተሰብ የአደጋ ጊዜ አድራሻዎችን ይጨምሩ",
              "የአቅራቢያ ሆስፒታል ቁጥሮችን ያካትቱ",
              "የአደጋ ጊዜ መገናኛ ቦታዎችን ይዘርዝሩ",
              "የወረቀት ቅጂዎችን ያዘጋጁ",
            ],
          },
        ],
        medical: [
          {
            title: "የልብ ድካም ምላሽ",
            icon: "❤️",
            steps: [
              "ወዲያውኑ የአደጋ ጊዜ አገልግሎቶችን ይደውሉ",
              "ሰውየው እንዲቀመጥ ወይም እንዲተኛ ይርዱት",
              "ጠባብ ልብሶችን ያላላቅቁ",
              "አተነፋፈሱን ይከታተሉ",
              "አስፈላጊ ከሆነ ለCPR ዝግጁ ይሁኑ",
            ],
          },
          {
            title: "ከባድ የደም መፍሰስ",
            icon: "🩹",
            steps: [
              "በቁስሉ ላይ ቀጥተኛ ጫና ያድርጉ",
              "ንጹህ ጨርቅ ወይም ጋዝ ይጠቀሙ",
              "ቢቻል የቆስለውን ክፍል ከፍ ያድርጉት",
              "እርዳታ እስኪደርስ ድረስ ጫና ይጠብቁ",
              "የሾክ ምልክቶችን ይከታተሉ",
            ],
          },
        ],
        natural: [
          {
            title: "የመሬት መንቀጥቀጥ ደህንነት",
            icon: "🏃",
            steps: [
              "ወድቅ፣ ተሸፍን እና ያዝ",
              "ከመስኮቶች ይራቁ",
              "ውስጥ ከሆኑ፣ ውስጥ ይቆዩ",
              "ውጭ ከሆኑ፣ ወደ ክፍት ቦታ ይሂዱ",
              "ለድጋሚ መንቀጥቀጥ ዝግጁ ይሁኑ",
            ],
          },
          {
            title: "የጎርፍ ምላሽ",
            icon: "🌊",
            steps: [
              "ወደ ከፍታ ቦታ ይሂዱ",
              "በሚንቀሳቀስ ውሃ ውስጥ አይሂዱ",
              "በጎርፍ አካባቢዎች አይንዱ",
              "የአደጋ ጊዜ ብሮድካስቶችን ያዳምጡ",
              "የማስለቀቂያ ትእዛዞችን ይከተሉ",
            ],
          },
        ],
      },
    },
  };

  const filteredGuides = useMemo(() => {
    const guides = emergencyGuides[language].guides[selectedCategory];
    if (!searchQuery) return guides;
    return guides.filter((guide) =>
      guide.title.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [language, selectedCategory, searchQuery]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={() => window.history.back()}
            className="text-gray-300 hover:text-white transition-colors"
          >
            <span className="flex items-center">
              <i className="fas fa-arrow-left mr-2"></i>
              {language === "en" ? "Back" : "ተመለስ"}
            </span>
          </button>
          <button
            onClick={() => setLanguage(language === "en" ? "am" : "en")}
            className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
          >
            {language === "en" ? "አማርኛ" : "English"}
          </button>
        </div>

        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">
            {emergencyGuides[language].title}
          </h1>
          <p className="text-xl text-gray-300">
            {emergencyGuides[language].subtitle}
          </p>
        </div>

        <div className="mb-8">
          <input
            type="text"
            placeholder={emergencyGuides[language].search}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-4 py-2 bg-gray-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-8">
          {Object.entries(emergencyGuides[language].categories).map(
            ([key, value]) => (
              <button
                key={key}
                onClick={() => setSelectedCategory(key)}
                className={`p-3 rounded-lg transition-all duration-200 ${
                  selectedCategory === key
                    ? "bg-blue-500 text-white"
                    : "bg-gray-700 text-gray-300 hover:bg-gray-600"
                }`}
              >
                {value}
              </button>
            )
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredGuides.map((guide, index) => (
            <div
              key={index}
              className="bg-gray-800 rounded-xl p-6 shadow-lg hover:transform hover:scale-105 transition-all duration-200"
            >
              <div className="flex items-center mb-4">
                <span className="text-4xl mr-4">{guide.icon}</span>
                <h3 className="text-xl font-bold text-white">{guide.title}</h3>
              </div>
              <ul className="space-y-3">
                {guide.steps.map((step, stepIndex) => (
                  <li
                    key={stepIndex}
                    className="flex items-start text-gray-300"
                  >
                    <span className="mr-2">•</span>
                    {step}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default MainComponent;