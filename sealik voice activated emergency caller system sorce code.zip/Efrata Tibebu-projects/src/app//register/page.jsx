"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [step, setStep] = useState(1);
  const [language, setLanguage] = useState("en");
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    emergencyPhone: "",
  });
  const [verificationCode, setVerificationCode] = useState("");

  const text = {
    en: {
      title: "Create Account",
      name: "Full Name",
      phone: "Phone Number",
      emergencyPhone: "Emergency Contact Phone",
      next: "Next",
      verify: "Verify",
      register: "Register",
      login: "Already have an account? Login",
      success: "Registration successful!",
      namePlaceholder: "Enter your full name",
      switchToAm: "አማርኛ",
    },
    am: {
      title: "መለያ ፍጠር",
      name: "ሙሉ ስም",
      phone: "ስልክ ቁጥር",
      emergencyPhone: "የአደጋ ጊዜ ስልክ ቁጥር",
      next: "ቀጣይ",
      verify: "አረጋግጥ",
      register: "ይመዝገቡ",
      login: "መለያ አለዎት? ይግቡ",
      success: "ምዝገባ ተሳክቷል!",
      namePlaceholder: "ሙሉ ስምዎን ያስገቡ",
      switchToEn: "English",
    },
  };

  const handlePhoneVerification = async () => {
    setError(null);
    setLoading(true);
    try {
      const response = await fetch("/api/send-verification-code", {
        method: "POST",
        body: JSON.stringify({ phone: formData.phone }),
      });
      const data = await response.json();
      if (!data.success) throw new Error(data.error);
      setStep(2);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyCode = async () => {
    setError(null);
    setLoading(true);
    try {
      const response = await fetch("/api/verify-phone", {
        method: "POST",
        body: JSON.stringify({
          phone: formData.phone,
          code: verificationCode,
        }),
      });
      const data = await response.json();
      if (!data.success) throw new Error(data.error);
      setStep(3);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async () => {
    setError(null);
    setLoading(true);
    try {
      const response = await fetch("/api/register-user", {
        method: "POST",
        body: JSON.stringify({
          name: formData.name,
          phone_number: formData.phone,
          emergency_contact_phone: formData.emergencyPhone,
        }),
      });
      const data = await response.json();
      if (!data.success) throw new Error(data.error);
      setSuccess(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center py-12 px-4">
      <div className="w-full max-w-md">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            {text[language].title}
          </h1>
          <button
            onClick={() => setLanguage(language === "en" ? "am" : "en")}
            className="text-blue-600 hover:text-blue-800"
          >
            {text[language][language === "en" ? "switchToAm" : "switchToEn"]}
          </button>
        </div>

        {success ? (
          <div className="bg-green-100 p-4 rounded-lg text-green-700">
            {text[language].success}
          </div>
        ) : (
          <div className="bg-white shadow rounded-lg p-6 space-y-6">
            {error && (
              <div className="bg-red-100 p-4 rounded-lg text-red-700">
                {error}
              </div>
            )}

            {step === 1 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {text[language].name}
                  </label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) =>
                      setFormData({ ...formData, name: e.target.value })
                    }
                    placeholder={text[language].namePlaceholder}
                    className="w-full p-3 border rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {text[language].phone}
                  </label>
                  <PhoneInput
                    value={formData.phone}
                    onChange={(value) =>
                      setFormData({ ...formData, phone: value })
                    }
                    language={language}
                  />
                </div>
                <button
                  onClick={handlePhoneVerification}
                  disabled={!formData.name || !formData.phone || loading}
                  className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
                >
                  {loading ? "..." : text[language].next}
                </button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <VerificationCodeInput
                  value={verificationCode}
                  onChange={setVerificationCode}
                  onResend={handlePhoneVerification}
                  language={language}
                />
                <button
                  onClick={handleVerifyCode}
                  disabled={verificationCode.length !== 6 || loading}
                  className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
                >
                  {loading ? "..." : text[language].verify}
                </button>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    {text[language].emergencyPhone}
                  </label>
                  <PhoneInput
                    value={formData.emergencyPhone}
                    onChange={(value) =>
                      setFormData({ ...formData, emergencyPhone: value })
                    }
                    language={language}
                  />
                </div>
                <button
                  onClick={handleRegister}
                  disabled={!formData.emergencyPhone || loading}
                  className="w-full bg-blue-600 text-white p-3 rounded-lg hover:bg-blue-700 disabled:bg-gray-400"
                >
                  {loading ? "..." : text[language].register}
                </button>
              </div>
            )}
          </div>
        )}

        <div className="mt-6 text-center">
          <a href="/login" className="text-blue-600 hover:text-blue-800">
            {text[language].login}
          </a>
        </div>
      </div>
    </div>
  );
}

export default MainComponent;