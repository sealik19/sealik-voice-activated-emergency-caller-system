"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [step, setStep] = useState("phone");
  const [phone, setPhone] = useState("");
  const [code, setCode] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [language, setLanguage] = useState("en");
  const [loading, setLoading] = useState(false);

  const text = {
    en: {
      title: "Login to Sealik",
      phoneLabel: "Enter your phone number",
      codeLabel: "Enter verification code",
      switchLanguage: "🌐 አማርኛ",
      register: "Don't have an account? Register",
      success: "Successfully logged in!",
    },
    am: {
      title: "ወደ ሲሊክ ይግቡ",
      phoneLabel: "ስልክ ቁጥርዎን ያስገቡ",
      codeLabel: "የማረጋገጫ ኮድ ያስገቡ",
      switchLanguage: "🌐 English",
      register: "መለያ የለዎትም? ይመዝገቡ",
      success: "በተሳካ ሁኔታ ገብተዋል!",
    },
  };

  const handlePhoneSubmit = async () => {
    setError("");
    setLoading(true);
    try {
      const response = await fetch("/api/login-user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone_number: phone }),
      });
      const data = await response.json();

      if (data.success) {
        setStep("code");
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError("Failed to send verification code");
    }
    setLoading(false);
  };

  const handleCodeSubmit = async () => {
    setError("");
    setLoading(true);
    try {
      const response = await fetch("/api/verify-phone", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, code }),
      });
      const data = await response.json();

      if (data.success) {
        setSuccess(true);
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError("Failed to verify code");
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-[#f5f5f5] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-xl shadow-lg p-8">
        <div className="flex justify-end mb-6">
          <button
            onClick={() => setLanguage(language === "en" ? "am" : "en")}
            className="text-[#4A90E2] hover:underline"
          >
            {text[language].switchLanguage}
          </button>
        </div>

        <h1 className="text-2xl font-crimson-text text-center mb-8">
          {text[language].title}
        </h1>

        {success ? (
          <div className="text-center text-green-600 font-crimson-text">
            {text[language].success}
          </div>
        ) : (
          <>
            {step === "phone" ? (
              <div className="space-y-6">
                <PhoneInput
                  value={phone}
                  onChange={setPhone}
                  language={language}
                  error={error}
                />
                <button
                  onClick={handlePhoneSubmit}
                  disabled={loading}
                  className="w-full bg-[#4A90E2] text-white py-3 rounded-lg hover:bg-[#357ABD] disabled:bg-gray-400 transition-colors"
                >
                  {loading ? "..." : text[language].phoneLabel}
                </button>
              </div>
            ) : (
              <div className="space-y-6">
                <VerificationCodeInput
                  value={code}
                  onChange={setCode}
                  language={language}
                  error={error}
                  onResend={handlePhoneSubmit}
                />
                <button
                  onClick={handleCodeSubmit}
                  disabled={loading || code.length !== 6}
                  className="w-full bg-[#4A90E2] text-white py-3 rounded-lg hover:bg-[#357ABD] disabled:bg-gray-400 transition-colors"
                >
                  {loading ? "..." : text[language].codeLabel}
                </button>
              </div>
            )}

            <div className="mt-6 text-center">
              <a
                href="/register"
                className="text-[#4A90E2] hover:underline font-crimson-text"
              >
                {text[language].register}
              </a>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default MainComponent;