"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [language, setLanguage] = useState("en");

  const content = {
    en: {
      hero: {
        title: "About Sealik",
        subtitle: "Your Safety Companion in Ethiopia",
        description:
          "Sealik is a revolutionary safety platform designed to protect and empower Ethiopian communities through immediate emergency response and preventive safety measures.",
      },
      quickLinks: {
        title: "Quick Links",
        links: [
          { title: "Emergency Services", icon: "🚑", url: "/emergency" },
          { title: "Safety Tips", icon: "🛡️", url: "/safety-tips" },
          { title: "Contact Support", icon: "📞", url: "/contact" },
          { title: "Download App", icon: "📱", url: "/download" },
          { title: "Privacy Policy", icon: "🔒", url: "/privacy" },
        ],
      },
      footer: {
        company: {
          title: "Company",
          links: ["About Us", "Careers", "Press Kit", "Contact Us"],
        },
        resources: {
          title: "Resources",
          links: ["Blog", "Community", "Help Center", "Safety Guidelines"],
        },
        legal: {
          title: "Legal",
          links: [
            "Terms of Service",
            "Privacy Policy",
            "Cookie Policy",
            "Security",
          ],
        },
        social: {
          title: "Connect With Us",
          links: [
            { name: "Twitter", url: "https://twitter.com/sealiklifesaver" },
            { name: "Facebook", url: "https://facebook.com/sealiklifesaver" },
            {
              name: "LinkedIn",
              url: "https://linkedin.com/company/sealiklifesaver",
            },
            { name: "Instagram", url: "https://instagram.com/sealiklifesaver" },
          ],
        },
        copyright: "© 2024 Sealik Lifesaver. All rights reserved.",
        address: "Addis Ababa, Ethiopia",
        contact: {
          email: "contact@sealik.com",
          phone: "+251 911 123 456",
        },
      },
    },
    am: {
      hero: {
        title: "ስለ ሲሊክ",
        subtitle: "በኢትዮጵያ የእርስዎ የደህንነት ጓደኛ",
        description:
          "ሲሊክ አዲስ የደህንነት መድረክ ሲሆን የኢትዮጵያን ማህበረሰቦች በአስቸኳይ ጊዜ ምላሽ እና በመከላከያ የደህንነት እርምጃዎች አማካኝነት ለመጠበቅ እና ለማብቃት የተዘጋጀ ነው።",
      },
      quickLinks: {
        title: "ፈጣን አገናኞች",
        links: [
          { title: "የአደጋ ጊዜ አገልግሎቶች", icon: "🚑", url: "/emergency" },
          { title: "የደህንነት ምክሮች", icon: "🛡️", url: "/safety-tips" },
          { title: "ድጋፍን አግኙ", icon: "📞", url: "/contact" },
          { title: "መተግበሪያውን ያውርዱ", icon: "📱", url: "/download" },
          { title: "የግላዊነት ፖሊሲ", icon: "🔒", url: "/privacy" },
        ],
      },
      footer: {
        company: {
          title: "ኩባንያ",
          links: ["ስለ እኛ", "ሥራዎች", "የፕሬስ ኪት", "አግኙን"],
        },
        resources: {
          title: "ሀብቶች",
          links: ["ብሎግ", "ማህበረሰብ", "የእርዳታ ማዕከል", "የደህንነት መመሪያዎች"],
        },
        legal: {
          title: "ሕጋዊ",
          links: ["የአገልግሎት ውሎች", "የግላዊነት ፖሊሲ", "የኩኪ ፖሊሲ", "ደህንነት"],
        },
        social: {
          title: "ከእኛ ጋር ይገናኙ",
          links: [
            { name: "ትዊተር", url: "https://twitter.com/sealiklifesaver" },
            { name: "ፌስቡክ", url: "https://facebook.com/sealiklifesaver" },
            {
              name: "ሊንክድኢን",
              url: "https://linkedin.com/company/sealiklifesaver",
            },
            { name: "ኢንስታግራም", url: "https://instagram.com/sealiklifesaver" },
          ],
        },
        copyright: "© 2024 ሲሊክ ላይፍሴቨር። መብቱ በህግ የተጠበቀ ነው።",
        address: "አዲስ አበባ፣ ኢትዮጵያ",
        contact: {
          email: "contact@sealik.com",
          phone: "+251 911 123 456",
        },
      },
    },
  };

  return (
    <div className="min-h-screen bg-gray-900">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex justify-end mb-8">
          <button
            onClick={() => setLanguage(language === "en" ? "am" : "en")}
            className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            {language === "en" ? "አማርኛ" : "English"}
          </button>
        </div>

        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold text-white mb-4">
            {content[language].hero.title}
          </h1>
          <p className="text-2xl text-gray-300 mb-6">
            {content[language].hero.subtitle}
          </p>
          <p className="text-lg text-gray-400 max-w-3xl mx-auto">
            {content[language].hero.description}
          </p>
        </div>

        <div className="bg-gray-800 rounded-lg p-8 mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">
            {content[language].quickLinks.title}
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {content[language].quickLinks.links.map((link, index) => (
              <a
                key={index}
                href={link.url}
                className="flex flex-col items-center p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors text-white"
              >
                <span className="text-3xl mb-2">{link.icon}</span>
                <span className="text-center text-sm">{link.title}</span>
              </a>
            ))}
          </div>
        </div>

        <footer className="bg-gray-800 text-gray-300 rounded-lg py-12">
          <div className="max-w-7xl mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
              <div>
                <h3 className="text-lg font-semibold mb-4">
                  {content[language].footer.company.title}
                </h3>
                <ul className="space-y-2">
                  {content[language].footer.company.links.map((link, index) => (
                    <li key={index}>
                      <a
                        href="#"
                        className="hover:text-white transition-colors"
                      >
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">
                  {content[language].footer.resources.title}
                </h3>
                <ul className="space-y-2">
                  {content[language].footer.resources.links.map(
                    (link, index) => (
                      <li key={index}>
                        <a
                          href="#"
                          className="hover:text-white transition-colors"
                        >
                          {link}
                        </a>
                      </li>
                    )
                  )}
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">
                  {content[language].footer.legal.title}
                </h3>
                <ul className="space-y-2">
                  {content[language].footer.legal.links.map((link, index) => (
                    <li key={index}>
                      <a
                        href="#"
                        className="hover:text-white transition-colors"
                      >
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-4">
                  {content[language].footer.social.title}
                </h3>
                <div className="flex space-x-4">
                  {content[language].footer.social.links.map(
                    (social, index) => (
                      <a
                        key={index}
                        href={social.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-gray-400 hover:text-white transition-colors"
                      >
                        {social.name}
                      </a>
                    )
                  )}
                </div>
                <div className="mt-6">
                  <p className="mb-2">{content[language].footer.address}</p>
                  <p className="mb-1">
                    {content[language].footer.contact.email}
                  </p>
                  <p>{content[language].footer.contact.phone}</p>
                </div>
              </div>
            </div>

            <div className="border-t border-gray-700 pt-8 text-center">
              <p>{content[language].footer.copyright}</p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}

export default MainComponent;