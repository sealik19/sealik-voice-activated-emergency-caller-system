"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [language, setLanguage] = useState("en");
  const [user, setUser] = useState(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [verificationCode, setVerificationCode] = useState("");
  const [showVerification, setShowVerification] = useState(false);
  const [error, setError] = useState(null);

  const content = {
    en: {
      hero: {
        title: "Your Personal Safety Companion",
        subtitle: "24/7 Emergency Response Platform",
        description:
          "Get immediate assistance during emergencies with just one tap. We're here to protect you and your loved ones around the clock.",
      },
      auth: {
        welcome: "Welcome back",
        login: "Login",
        register: "Register",
        logout: "Logout",
        verify: "Verify Phone",
        emergency: "Emergency Contact",
        call: "Quick Call",
        verified: "Verified",
        notVerified: "Not Verified",
      },
      features: {
        title: "Why Choose Sealik Lifesaver",
        items: [
          {
            icon: "🚨",
            title: "Instant Response",
            description:
              "One-tap emergency activation with real-time location tracking",
          },
          {
            icon: "🌍",
            title: "Multilingual Support",
            description:
              "Full support in English and Amharic for broader accessibility",
          },
          {
            icon: "📱",
            title: "Works Offline",
            description:
              "Continued functionality even without internet connection",
          },
        ],
      },
      cta: {
        title: "Start Protecting Yourself Today",
        subtitle: "Join thousands of users who trust Sealik Lifesaver",
        pricing: {
          monthly: "250 ETB/month",
          yearly: "1800 ETB/year",
          savings: "Save 40% with yearly plan",
        },
        button: "Get Started",
        learnMore: "Learn More",
      },
    },
    am: {
      hero: {
        title: "የእርስዎ የግል ደህንነት ተባባሪ",
        subtitle: "24/7 የአስቸኳይ ጊዜ ምላሽ መድረክ",
        description:
          "በአንድ ጠቅታ በድንገተኛ አደጋ ጊዜ ወዲያውኑ እርዳታ ያግኙ። እርስዎንና ወዳጆችዎን 24/7 ለመጠበቅ እዚህ አለን።",
      },
      auth: {
        welcome: "እንኳን ደህና መጡ",
        login: "ግባ",
        register: "ተመዝገብ",
        logout: "ውጣ",
        verify: "ስልክ ያረጋግጡ",
        emergency: "የአስቸኳይ ጊዜ ዝርዝር",
        call: "ፈጣን ጥሪ",
        verified: "የተረጋገጠ",
        notVerified: "አልተረጋገጠም",
      },
      features: {
        title: "ሲሊክ ላይፍሴቨርን ለምን መምረጥ አለብዎት",
        items: [
          {
            icon: "🚨",
            title: "ወዲያውኑ ምላሽ",
            description: "በአንድ ጠቅታ የአስቸኳይ ጊዜ ማንቃት ከእውነተኛ ጊዜ አካባቢ መከታተል ጋር",
          },
          {
            icon: "🌍",
            title: "የብዙ ቋንቋ ድጋፍ",
            description: "ለተሻለ ተደራሽነት በእንግሊዘኛና በአማርኛ ሙሉ ድጋፍ",
          },
          {
            icon: "📱",
            title: "ከመስመር ውጪ ይሰራል",
            description: "ያለ ኢንተርኔት ግንኙነትም እንኳን የማያቋርጥ ተግባራዊነት",
          },
        ],
      },
      cta: {
        title: "ዛሬውኑ ራስዎን መጠበቅ ይጀምሩ",
        subtitle: "ሲሊክ ላይፍሴቨርን የሚያምኑ ሺዎች ተጠቃሚዎችን ይቀላቀሉ",
        pricing: {
          monthly: "250 ብር/በወር",
          yearly: "1800 ብር/በአመት",
          savings: "በአመታዊ እቅድ 40% ይቆጥቡ",
        },
        button: "ይጀምሩ",
        learnMore: "ተጨማሪ ያንብቡ",
      },
    },
  };

  const handleLogin = async () => {
    try {
      const response = await fetch("/api/login-user", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone_number: phoneNumber }),
      });

      if (!response.ok) {
        throw new Error("Login failed");
      }

      const data = await response.json();
      if (data.success) {
        setUser(data.data);
        setShowVerification(true);
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const handleVerify = async () => {
    try {
      const response = await fetch("/api/verify-phone", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          phone: phoneNumber,
          code: verificationCode,
        }),
      });

      if (!response.ok) {
        throw new Error("Verification failed");
      }

      const data = await response.json();
      if (data.success) {
        setUser((prev) => ({ ...prev, verified: true }));
        setShowVerification(false);
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const handleLogout = () => {
    setUser(null);
    setPhoneNumber("");
    setVerificationCode("");
    setShowVerification(false);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800 text-white">
      <header className="fixed w-full z-50 bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10">
                <img
                  src="https://ucarecdn.com/17d8d49b-c56c-4af1-b41f-19579e9d34e5/-/format/auto/"
                  alt="Sealik Lifesaver"
                  className="w-full h-full object-contain"
                />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-red-500 to-gray-700 text-transparent bg-clip-text">
                Sealik Lifesaver
              </span>
            </div>
            <div className="flex items-center space-x-4">
              {user ? (
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-gray-300">
                    {user.name}
                    <span
                      className={`ml-2 px-2 py-1 rounded text-xs ${
                        user.verified ? "bg-green-600" : "bg-yellow-600"
                      }`}
                    >
                      {user.verified
                        ? content[language].auth.verified
                        : content[language].auth.notVerified}
                    </span>
                  </span>
                  <button
                    onClick={handleLogout}
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                  >
                    {content[language].auth.logout}
                  </button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <a
                    href="/login"
                    className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
                  >
                    {content[language].auth.login}
                  </a>
                  <a
                    href="/register"
                    className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                  >
                    {content[language].auth.register}
                  </a>
                </div>
              )}
              <button
                onClick={() =>
                  setLanguage((lang) => (lang === "en" ? "am" : "en"))
                }
                className="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition-colors"
              >
                {language === "en" ? "አማርኛ" : "English"}
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="pt-24 pb-12">
        <div className="max-w-7xl mx-auto px-4">
          <section className="text-center mb-20">
            {user ? (
              <div className="mb-12">
                <h1 className="text-4xl font-bold mb-6">
                  {content[language].auth.welcome}, {user.name}!
                </h1>
                {user.emergency_contact && (
                  <div className="bg-gray-800 rounded-xl p-6 max-w-md mx-auto">
                    <h3 className="text-xl font-bold mb-4">
                      {content[language].auth.emergency}
                    </h3>
                    <p className="text-gray-300 mb-4">
                      {user.emergency_contact.name}
                    </p>
                    <a
                      href={`tel:${user.emergency_contact.phone}`}
                      className="inline-flex items-center px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 transition-colors"
                    >
                      <i className="fas fa-phone-alt mr-2"></i>
                      {content[language].auth.call}
                    </a>
                  </div>
                )}
                {showVerification && (
                  <div className="mt-8">
                    <VerificationCodeInput
                      value={verificationCode}
                      onChange={setVerificationCode}
                      onSubmit={handleVerify}
                      error={error}
                    />
                  </div>
                )}
              </div>
            ) : (
              <>
                <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-red-500 to-gray-300 text-transparent bg-clip-text">
                  {content[language].hero.title}
                </h1>
                <h2 className="text-2xl md:text-3xl text-gray-300 mb-6">
                  {content[language].hero.subtitle}
                </h2>
                <p className="text-xl text-gray-400 max-w-3xl mx-auto mb-12">
                  {content[language].hero.description}
                </p>
                <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
                  <a
                    href="/register"
                    className="px-8 py-4 bg-red-600 hover:bg-red-700 rounded-xl text-lg font-bold transition-colors transform hover:scale-105"
                  >
                    {content[language].auth.register}
                  </a>
                  <a
                    href="/about-sealik"
                    className="px-8 py-4 bg-gray-700 hover:bg-gray-600 rounded-xl text-lg font-bold transition-colors"
                  >
                    {content[language].cta.learnMore}
                  </a>
                </div>
              </>
            )}
          </section>

          <section className="text-center bg-gray-800 rounded-xl p-12 mb-20">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {content[language].cta.title}
            </h2>
            <p className="text-xl text-gray-300 mb-4">
              {content[language].cta.subtitle}
            </p>
            <div className="flex flex-col items-center gap-4 mb-8">
              <div className="flex gap-8 text-2xl font-bold">
                <span>{content[language].cta.pricing.monthly}</span>
                <span>{content[language].cta.pricing.yearly}</span>
              </div>
              <p className="text-red-400">
                {content[language].cta.pricing.savings}
              </p>
            </div>
            <a
              href="/"
              className="inline-block px-8 py-4 bg-red-600 hover:bg-red-700 rounded-xl text-lg font-bold transition-colors transform hover:scale-105"
            >
              {content[language].cta.button}
            </a>
          </section>
        </div>
      </main>

      <footer className="bg-gray-900 border-t border-gray-800 py-6">
        <div className="max-w-4xl mx-auto px-4 text-center text-gray-400">
          <p>
            © 2025 Sealik Lifesaver.{" "}
            {language === "en" ? "All rights reserved." : "መብቱ በህግ የተጠበቀ ነው።"}
          </p>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;