"use client";
import React from "react";
import * as ReactGoogleMaps from "@/libraries/react-google-maps";

const NEXT_PUBLIC_GOOGLE_MAPS_API_KEY =
  process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

function MainComponent() {
  const [accessibilityMode, setAccessibilityMode] = useState("standard");
  const [language, setLanguage] = useState("en");
  const [currentMessage, setCurrentMessage] = useState("");
  const [messages, setMessages] = useState([]);
  const [chatLoading, setChatLoading] = useState(false);
  const [loading, setLoading] = useState(false);
  const [location, setLocation] = useState(null);
  const [mapCenter, setMapCenter] = useState({ lat: 9.032, lng: 38.752 });
  const [error, setError] = useState(null);
  const [emergencyType, setEmergencyType] = useState("general");
  const [isListening, setIsListening] = useState(false);
  const [offlineQueue, setOfflineQueue] = useState([]);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [subscriptionPlans, setSubscriptionPlans] = useState([]);
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [loadingPlans, setLoadingPlans] = useState(false);
  const [subscriptionType, setSubscriptionType] = useState("monthly");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const subscriptionContent = {
    en: {
      title: "Premium Safety Features",
      description: "Unlock advanced safety features with our premium plans",
      features: [
        "24/7 Priority Emergency Response",
        "Live Location Sharing",
        "Advanced AI Safety Predictions",
        "Family Safety Circle",
        "Emergency Contact Auto-Alert",
      ],
      cta: "Upgrade Now",
      period: {
        monthly: "Monthly",
        yearly: "Yearly (Save 20%)",
      },
    },
    am: {
      title: "የከፍተኛ ደረጃ የደህንነት ባህሪያት",
      description: "በከፍተኛ ደረጃ እቅዶቻችን ላይ የላቀ የደህንነት ባህሪያትን ይክፈቱ",
      features: [
        "24/7 የቅድሚያ የአደጋ ምላሽ",
        "የቀጥታ አካባቢ ማጋራት",
        "የላቀ AI የደህንነት ትንበያዎች",
        "የቤተሰብ ደህንነት ክብ",
        "የአስቸኳይ ጊዜ እውቂያ ራስ-ሰር ማስጠንቀቂያ",
      ],
      cta: "አሁን ያሻሽሉ",
      period: {
        monthly: "ወርሃዊ",
        yearly: "ዓመታዊ (20% ይቆጥቡ)",
      },
    },
  };
  const welcomeContent = {
    en: {
      title: "Welcome to Sealik Lifesaver",
      subtitle: "Your Personal Safety Companion",
      description:
        "Get immediate help in emergencies with just one tap. We're here to protect you 24/7.",
      features: [
        { emoji: "🚨", text: "Instant Emergency Alerts" },
        { emoji: "🗺️", text: "Real-time Location Tracking" },
        { emoji: "👥", text: "Emergency Contact System" },
        { emoji: "🌐", text: "Works Offline" },
        { emoji: "🎯", text: "Precise Help Dispatch" },
      ],
    },
    am: {
      title: "እንኳን ወደ ሲሊክ ላይፍሴቨር በደህና መጡ",
      subtitle: "የግል ደህንነትዎ ተባባሪ",
      description: "በአንድ ጠቅታ ወዲያውኑ እርዳታ ያግኙ። 24/7 ለመጠበቅ እዚህ አለን።",
      features: [
        { emoji: "🚨", text: "የአስቸኳይ ማስጠንቀቂያዎች" },
        { emoji: "🗺️", text: "የእውነተኛ ጊዜ አካባቢ መከታተል" },
        { emoji: "👥", text: "የአስቸኳይ ጊዜ የመገናኛ ሥርዓት" },
        { emoji: "🌐", text: "ከመስመር ውጪ ይሰራል" },
        { emoji: "🎯", text: "ትክክለኛ እርዳታ መላክ" },
      ],
    },
  };
  const quickResponses = {
    en: ["Help!", "Medical Emergency", "I need police", "Fire Emergency"],
    am: ["እርዳታ!", "የሕክምና አደጋ", "ፖሊስ ያስፈልገኛል", "የእሳት አደጋ"],
  };
  const emergencyCategories = {
    en: {
      medical: ["Pregnancy", "Chronic Pain", "General Medical"],
      security: ["Theft", "Night Travel", "Personal Safety"],
      disaster: ["Earthquake", "Flood", "Fire"],
      personal: ["Sexual Assault", "Solo Living", "General Help"],
      accessibility: ["Visual", "Hearing", "Mobility"],
    },
    am: {
      medical: ["እርግዝና", "ቋሚ ህመም", "አጠቃላይ ሕክምና"],
      security: ["ስርቆት", "የሌሊት ጉዞ", "የግል ደህንነት"],
      disaster: ["የመሬት መንቀጥቀጥ", "ጎርፍ", "እሳት"],
      personal: ["የወሲባዊ ጥቃት", "ብቸኛ መኖር", "አጠቃላይ እርዳታ"],
      accessibility: ["የእይታ", "የመስማት", "የእንቅስቃሴ"],
    },
  };
  const [contacts, setContacts] = useState([]);
  const [showAddContact, setShowAddContact] = useState(false);
  const [editingContact, setEditingContact] = useState(null);
  const [loadingContacts, setLoadingContacts] = useState(false);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const newLocation = {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          };
          setLocation(newLocation);
          setMapCenter({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  }, []);

  useEffect(() => {
    if ("webkitSpeechRecognition" in window) {
      const recognition = new window.webkitSpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = language === "en" ? "en-US" : "am-ET";

      recognition.onresult = (event) => {
        const transcript =
          event.results[event.results.length - 1][0].transcript.toLowerCase();
        if (transcript.includes("help") || transcript.includes("እርዳታ")) {
          handleEmergencyAlert();
        }
      };

      if (isListening) {
        recognition.start();
      }

      return () => {
        recognition.stop();
      };
    }
  }, [isListening, language]);

  useEffect(() => {
    const fetchPlans = async () => {
      setLoadingPlans(true);
      try {
        const response = await fetch("/api/list-subscription-plans", {
          method: "POST",
        });
        if (!response.ok) {
          throw new Error("Failed to fetch subscription plans");
        }
        const data = await response.json();
        if (data.plans) {
          setSubscriptionPlans(data.plans);
        }
      } catch (error) {
        console.error("Failed to fetch plans:", error);
        setError("Could not load subscription plans");
      } finally {
        setLoadingPlans(false);
      }
    };
    fetchPlans();
  }, []);

  useEffect(() => {
    const fetchContacts = async () => {
      setLoadingContacts(true);
      try {
        const response = await fetch("/api/list-emergency-contacts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ user_id: 1 }),
        });

        if (!response.ok) {
          throw new Error("Failed to fetch contacts");
        }

        const data = await response.json();
        setContacts(data.contacts || []);
      } catch (error) {
        console.error("Error fetching contacts:", error);
      } finally {
        setLoadingContacts(false);
      }
    };
    fetchContacts();
  }, []);

  const handleEmergencyAlert = async () => {
    if (!location) {
      setError("Location not available");
      return;
    }

    setLoading(true);
    try {
      if (!navigator.onLine) {
        setOfflineQueue((prev) => [
          ...prev,
          {
            type: emergencyType,
            location: location,
            timestamp: new Date().toISOString(),
          },
        ]);
        throw new Error("Offline - Alert queued");
      }

      const response = await fetch("/api/create-emergency-alert", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          user_id: 1,
          latitude: location.latitude,
          longitude: location.longitude,
          trigger_type: "SOS",
          emergency_type: emergencyType,
          accessibility_needs: {
            visual: accessibilityMode === "blind",
            hearing: accessibilityMode === "deaf",
          },
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to create emergency alert");
      }

      await fetch("/api/list-police-stations", {
        method: "POST",
        body: JSON.stringify({
          latitude: location.latitude,
          longitude: location.longitude,
        }),
      });

      if (accessibilityMode === "blind") {
        const message =
          language === "en"
            ? "Emergency alert sent. Help is on the way."
            : "የድንገተኛ አደጋ ማስጠንቀቂያ ተልኳል። እርዳታ በመንገድ ላይ ነው።";
        processAccessibilityResponse(message);
      }
    } catch (err) {
      setError(err.message || "Failed to send emergency alert");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };
  const handleSubscribe = async (planId) => {
    try {
      const response = await fetch("/api/create-subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          plan_id: planId,
          user_id: 1,
          subscription_type: subscriptionType,
          payment_status: "pending",
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to create subscription");
      }

      setShowSubscriptionModal(false);
      setSelectedPlan(planId);
    } catch (error) {
      console.error("Subscription failed:", error);
      setError("Could not process subscription");
    }
  };
  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!currentMessage.trim()) return;

    setChatLoading(true);
    const userMessage = currentMessage;
    setCurrentMessage("");

    try {
      const response = await fetch("/api/chat-with-sealik", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: userMessage,
          language: language === "en" ? "english" : "amharic",
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to get response from Sealik");
      }

      const data = await response.json();
      const aiResponse = data.response;

      setMessages((prev) => [
        ...prev,
        { role: "user", content: userMessage },
        { role: "assistant", content: aiResponse },
      ]);

      if (accessibilityMode === "blind") {
        processAccessibilityResponse(aiResponse);
      }
    } catch (err) {
      setError("Failed to send message to Sealik");
      console.error(err);
    } finally {
      setChatLoading(false);
    }
  };
  const processAccessibilityResponse = (response) => {
    if (typeof window !== "undefined" && window.speechSynthesis) {
      const utterance = new SpeechSynthesisUtterance(response);
      utterance.lang = language === "en" ? "en-US" : "am-ET";
      window.speechSynthesis.speak(utterance);
    }
  };
  const handleSaveContact = async (contactData) => {
    try {
      const response = await fetch("/api/add-emergency-contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...contactData, user_id: 1 }),
      });

      if (!response.ok) {
        throw new Error("Failed to save contact");
      }

      const data = await response.json();
      setContacts((prev) => [...prev, data.contact]);
      setShowAddContact(false);
      setEditingContact(null);
    } catch (error) {
      console.error("Error saving contact:", error);
      setError("Failed to save contact");
    }
  };
  const handleEditContact = (contact) => {
    setEditingContact(contact);
    setShowAddContact(true);
  };
  const handleDeleteContact = async (contactId) => {
    try {
      const response = await fetch("/api/delete-emergency-contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contact_id: contactId }),
      });

      if (!response.ok) {
        throw new Error("Failed to delete contact");
      }

      setContacts((prev) => prev.filter((c) => c.id !== contactId));
    } catch (error) {
      console.error("Error deleting contact:", error);
      setError("Failed to delete contact");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 to-gray-800">
      <header className="fixed w-full z-50 bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 border-b border-gray-700">
        <nav className="mb-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center">
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <div className="w-10 h-10">
                    <img
                      src="https://ucarecdn.com/17d8d49b-c56c-4af1-b41f-19579e9d34e5/-/format/auto/"
                      alt="Sealik Lifesaver"
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <span className="text-2xl font-bold bg-gradient-to-r from-red-500 to-gray-700 text-transparent bg-clip-text">
                    Sealik Lifesaver
                  </span>
                </div>
                <a href="/" className="text-white hover:text-gray-300">
                  {language === "en" ? "Home" : "ዋና ገጽ"}
                </a>
                <a href="/about" className="text-white hover:text-gray-300">
                  {language === "en" ? "About" : "ስለ እኛ"}
                </a>
              </div>
              <div className="flex items-center space-x-4">
                <div className="hidden md:flex items-center space-x-2">
                  <button
                    onClick={() =>
                      setAccessibilityMode((mode) =>
                        mode === "deaf" ? "standard" : "deaf"
                      )
                    }
                    className={`p-2 rounded-lg transition-all duration-300 ${
                      accessibilityMode === "deaf"
                        ? "bg-yellow-500 text-black"
                        : "bg-gray-700 text-gray-300 hover:bg-gray-600"
                    }`}
                  >
                    <span className="flex items-center space-x-1">
                      <span>👂</span>
                      <span className="text-sm">
                        {accessibilityMode === "deaf"
                          ? "Standard"
                          : "Deaf Mode"}
                      </span>
                    </span>
                  </button>

                  <button
                    onClick={() =>
                      setAccessibilityMode((mode) =>
                        mode === "blind" ? "standard" : "blind"
                      )
                    }
                    className={`p-2 rounded-lg transition-all duration-300 ${
                      accessibilityMode === "blind"
                        ? "bg-blue-500 text-white"
                        : "bg-gray-700 text-gray-300 hover:bg-gray-600"
                    }`}
                  >
                    <span className="flex items-center space-x-1">
                      <span>👁️</span>
                      <span className="text-sm">
                        {accessibilityMode === "blind"
                          ? "Standard"
                          : "Blind Mode"}
                      </span>
                    </span>
                  </button>

                  <button
                    onClick={() =>
                      setLanguage((lang) => (lang === "en" ? "am" : "en"))
                    }
                    className="px-3 py-2 rounded-lg bg-gray-700 text-gray-300 hover:bg-gray-600 transition-colors"
                  >
                    {language === "en" ? "አማርኛ" : "English"}
                  </button>

                  <button
                    onClick={() => setShowSubscriptionModal(true)}
                    className="px-3 py-2 rounded-lg bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:from-purple-700 hover:to-purple-800 transition-all duration-300 transform hover:scale-105"
                  >
                    <span className="flex items-center space-x-1">
                      <span>⭐</span>
                      <span>Premium</span>
                    </span>
                  </button>
                </div>

                <div className="md:hidden">
                  <button
                    onClick={() => setMobileMenuOpen(true)}
                    className="p-2 rounded-lg bg-gray-700 text-gray-300 hover:bg-gray-600"
                  >
                    <svg
                      className="h-6 w-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M4 6h16M4 12h16M4 18h16"
                      />
                    </svg>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </nav>

        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 md:hidden">
            <div
              className="fixed inset-0 bg-gray-900 bg-opacity-75 transition-opacity"
              onClick={() => setMobileMenuOpen(false)}
            />
            <div className="fixed inset-y-0 right-0 max-w-xs w-full bg-gray-800 shadow-xl">
              <div className="flex flex-col h-full">
                <div className="flex justify-end p-4">
                  <button
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-2 rounded-lg bg-gray-700 text-gray-300 hover:bg-gray-600"
                  >
                    <svg
                      className="h-6 w-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M6 18L18 6M6 6l12 12"
                      />
                    </svg>
                  </button>
                </div>
                <div className="flex-1 px-4 py-6">
                  <nav className="flex flex-col space-y-6">
                    <a
                      href="/"
                      className="text-gray-300 hover:text-white transition-colors text-lg"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {language === "en" ? "Home" : "ዋና ገጽ"}
                    </a>
                    <a
                      href="/about"
                      className="text-gray-300 hover:text-white transition-colors text-lg"
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {language === "en" ? "About" : "ስለ እኛ"}
                    </a>
                  </nav>
                </div>
              </div>
            </div>
          </div>
        )}
      </header>

      {showSubscriptionModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-gray-800 rounded-xl max-w-lg w-full p-6 relative">
            <button
              onClick={() => setShowSubscriptionModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-white"
            >
              ✕
            </button>

            <h2 className="text-2xl font-bold text-white mb-4">
              {subscriptionContent[language].title}
            </h2>

            <p className="text-gray-300 mb-6">
              {subscriptionContent[language].description}
            </p>

            <div className="mb-6">
              <div className="flex justify-center space-x-4 mb-6">
                <button
                  onClick={() => setSubscriptionType("monthly")}
                  className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                    subscriptionType === "monthly"
                      ? "bg-purple-600 text-white"
                      : "bg-gray-700 text-gray-300"
                  }`}
                >
                  {subscriptionContent[language].period.monthly}
                </button>
                <button
                  onClick={() => setSubscriptionType("yearly")}
                  className={`px-4 py-2 rounded-lg transition-all duration-300 ${
                    subscriptionType === "yearly"
                      ? "bg-purple-600 text-white"
                      : "bg-gray-700 text-gray-300"
                  }`}
                >
                  {subscriptionContent[language].period.yearly}
                </button>
              </div>

              <div className="space-y-4 mb-6">
                {subscriptionContent[language].features.map(
                  (feature, index) => (
                    <div
                      key={index}
                      className="flex items-center text-gray-300"
                    >
                      <span className="text-green-500 mr-2">✓</span>
                      {feature}
                    </div>
                  )
                )}
              </div>
            </div>

            <div className="grid gap-4">
              {loadingPlans ? (
                <div className="text-center text-gray-400">
                  Loading plans...
                </div>
              ) : (
                subscriptionPlans.map((plan) => (
                  <button
                    key={plan.id}
                    onClick={() => handleSubscribe(plan.id)}
                    className="w-full p-4 rounded-lg bg-gradient-to-r from-purple-600 to-purple-700 text-white hover:from-purple-700 hover:to-purple-800 transition-all duration-300 transform hover:scale-105"
                  >
                    <div className="font-bold text-lg">
                      {language === "en" ? plan.name_en : plan.name_am}
                    </div>
                    <div className="text-sm opacity-90">
                      {subscriptionType === "yearly"
                        ? `${Math.round(
                            plan.price_monthly * 12 * 0.8
                          )} ETB/year`
                        : `${plan.price_monthly} ETB/month`}
                    </div>
                  </button>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      <main className="pt-20 pb-8 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8 text-center bg-gradient-to-r from-gray-800 to-gray-700 rounded-xl p-8 shadow-2xl">
            <h1 className="text-4xl font-bold text-white mb-4">
              {welcomeContent[language].title}
            </h1>
            <p className="text-xl text-gray-300 mb-6">
              {welcomeContent[language].subtitle}
            </p>
            <p className="text-gray-400 mb-8">
              {welcomeContent[language].description}
            </p>

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {welcomeContent[language].features.map((feature, index) => (
                <div
                  key={index}
                  className="bg-gray-700 p-4 rounded-lg transform hover:scale-105 transition-transform duration-200"
                >
                  <div className="text-3xl mb-2">{feature.emoji}</div>
                  <div className="text-white text-sm">{feature.text}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="mb-4 grid grid-cols-2 md:grid-cols-5 gap-2">
            {Object.entries(emergencyCategories[language]).map(
              ([category, types]) => (
                <div key={category} className="bg-gray-800 p-2 rounded-lg">
                  <h3 className="text-white font-bold mb-2">
                    {language === "en"
                      ? category.charAt(0).toUpperCase() + category.slice(1)
                      : category}
                  </h3>
                  {types.map((type) => (
                    <button
                      key={type}
                      onClick={() => setEmergencyType(type.toLowerCase())}
                      className={`w-full mb-1 p-2 rounded ${
                        emergencyType === type.toLowerCase()
                          ? "bg-red-600 text-white"
                          : "bg-gray-700 text-gray-300 hover:bg-gray-600"
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              )
            )}
          </div>
          <button
            onClick={() => setIsListening(!isListening)}
            className={`mb-4 w-full p-2 rounded-lg ${
              isListening ? "bg-green-600 text-white" : "bg-gray-700 text-white"
            }`}
          >
            🎤{" "}
            {isListening
              ? language === "en"
                ? "Voice Active"
                : "ድምፅ እንቅስቃሴ"
              : language === "en"
              ? "Enable Voice"
              : "ድምፅ አንቃ"}
          </button>
          <div className="mb-8">
            <button
              onClick={handleEmergencyAlert}
              disabled={loading}
              className={`w-full bg-red-600 hover:bg-red-700 text-white font-bold py-8 px-4 rounded-xl text-3xl transition-all duration-200 ${
                loading
                  ? "opacity-50 cursor-not-allowed"
                  : "transform hover:scale-105"
              } ${
                accessibilityMode === "deaf" ? "border-4 border-yellow-400" : ""
              }`}
            >
              {loading ? (
                <div className="flex items-center justify-center">
                  <svg
                    className="animate-spin h-8 w-8 mr-3"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                      fill="none"
                    />
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    />
                  </svg>
                  {language === "en"
                    ? "Sending Alert..."
                    : "ማስጠንቀቂያ በመላክ ላይ..."}
                </div>
              ) : (
                <>🚨 {language === "en" ? "EMERGENCY ALERT" : "የአደጋ ማስጠንቀቂያ"}</>
              )}
            </button>
          </div>
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-white">
                {language === "en" ? "Emergency Contacts" : "የአደጋ ጊዜ ተጠሪዎች"}
              </h2>
              <button
                onClick={() => setShowAddContact(true)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                {language === "en" ? "+ Add Contact" : "+ ተጠሪ ያክሉ"}
              </button>
            </div>

            {showAddContact ? (
              <EmergencyContactForm
                language={language}
                onSave={handleSaveContact}
                onCancel={() => {
                  setShowAddContact(false);
                  setEditingContact(null);
                }}
                editingContact={editingContact}
              />
            ) : (
              <EmergencyContactList
                language={language}
                contacts={contacts}
                onEdit={handleEditContact}
                onDelete={handleDeleteContact}
              />
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-gray-800 rounded-xl p-4 h-[400px]">
              <ReactGoogleMaps.APIProvider
                apiKey={NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}
                libraries={["places"]}
              >
                <ReactGoogleMaps.Map
                  id="map"
                  mapId="map"
                  center={mapCenter}
                  zoom={13}
                  className="w-full h-full rounded-lg"
                >
                  {location && (
                    <ReactGoogleMaps.AdvancedMarker
                      position={{
                        lat: location.latitude,
                        lng: location.longitude,
                      }}
                    >
                      <ReactGoogleMaps.InfoWindow>
                        <div className="p-2">
                          <p className="font-semibold">
                            {language === "en"
                              ? "Current Location"
                              : "አሁን ያሉበት ቦታ"}
                          </p>
                        </div>
                      </ReactGoogleMaps.InfoWindow>
                    </ReactGoogleMaps.AdvancedMarker>
                  )}
                </ReactGoogleMaps.Map>
              </ReactGoogleMaps.APIProvider>
            </div>

            <div className="bg-gray-800 rounded-xl p-4">
              <h2 className="text-xl font-bold mb-4 text-white">
                {language === "en" ? "Chat with Sealik" : "ከሲሊክ ጋር ይወያዩ"}
              </h2>

              <div className="flex flex-wrap gap-2 mb-4">
                {quickResponses[language].map((phrase, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setCurrentMessage(phrase);
                      handleSendMessage({ preventDefault: () => {} });
                    }}
                    className={`px-3 py-1 rounded-full text-sm transition-colors ${
                      accessibilityMode === "deaf"
                        ? "bg-yellow-400 text-black hover:bg-yellow-500"
                        : "bg-gray-700 text-white hover:bg-gray-600"
                    }`}
                  >
                    {phrase}
                  </button>
                ))}
              </div>

              <div
                className={`h-64 overflow-y-auto rounded-lg p-4 mb-4 ${
                  accessibilityMode === "deaf"
                    ? "bg-black text-yellow-400"
                    : "bg-gray-700 text-white"
                }`}
              >
                {messages.map((msg, index) => (
                  <div
                    key={index}
                    className={`mb-2 ${
                      msg.role === "user" ? "text-right" : "text-left"
                    }`}
                  >
                    <div
                      className={`inline-block p-2 rounded-lg ${
                        msg.role === "user"
                          ? "bg-blue-500 text-white"
                          : accessibilityMode === "deaf"
                          ? "bg-yellow-400 text-black"
                          : "bg-gray-600 text-white"
                      }`}
                    >
                      {msg.content}
                    </div>
                  </div>
                ))}
                {chatLoading && (
                  <div className="text-center text-gray-400">
                    {language === "en"
                      ? "Sealik is typing..."
                      : "ሲሊክ በመጻፍ ላይ..."}
                  </div>
                )}
              </div>

              <form onSubmit={handleSendMessage} className="flex gap-2">
                <input
                  type="text"
                  value={currentMessage}
                  onChange={(e) => setCurrentMessage(e.target.value)}
                  placeholder={
                    language === "en"
                      ? "Type your message..."
                      : "መልእክትዎን ይጻፉ..."
                  }
                  className={`flex-1 p-2 rounded-lg ${
                    accessibilityMode === "deaf"
                      ? "bg-black text-yellow-400 border-2 border-yellow-400"
                      : "bg-gray-700 text-white border border-gray-600"
                  }`}
                />
                <button
                  type="submit"
                  disabled={chatLoading}
                  className={`px-4 py-2 rounded-lg ${
                    chatLoading
                      ? "opacity-50 cursor-not-allowed"
                      : accessibilityMode === "deaf"
                      ? "bg-yellow-400 text-black hover:bg-yellow-500"
                      : "bg-blue-500 text-white hover:bg-blue-600"
                  }`}
                >
                  {chatLoading
                    ? language === "en"
                      ? "Sending..."
                      : "በመላክ ላይ..."
                    : language === "en"
                    ? "Send"
                    : "ላክ"}
                </button>
              </form>
            </div>
          </div>
        </div>
      </main>

      <footer className="fixed bottom-0 w-full bg-gray-900 border-t border-gray-800 p-2">
        <div className="max-w-7xl mx-auto flex justify-between items-center text-sm text-gray-400">
          <div className="flex items-center space-x-2">
            <span
              className={`h-2 w-2 rounded-full ${
                navigator.onLine ? "bg-green-500" : "bg-red-500"
              }`}
            ></span>
            <span>{navigator.onLine ? "Online" : "Offline"}</span>
          </div>
          <div className="flex items-center space-x-2">
            <span>🔊 {accessibilityMode}</span>
            <span>🌍 {language.toUpperCase()}</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default MainComponent;